# This file is actually initializing blueprint per api version
from aac.tsdos.treasury.hong_kong_liquidity_backend_api.hk import ns as ns_hk
from flask import Blueprint, current_app
from flask_restx import Api

blueprint = Blueprint("api_1_0", __name__)

# Initializing Api with blueprint and custom swagger document endpoint
api = Api(blueprint, doc=current_app.config["API_DOCS_URL"], catch_all_404s=True)

api.namespaces.clear()
api.add_namespace(ns_hk)

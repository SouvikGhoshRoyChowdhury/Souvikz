from typing import Dict, NamedTuple
from datetime import datetime
from typing_extensions import TypedDict
from dataclasses import dataclass, field, asdict


class LiquidityIdentifier(NamedTuple):
    client_number: int
    opposite_party_code: str
    exchange_code: str

    def __repr__(self):
        return f"(client={self.client_number}, ctp={self.opposite_party_code}, exc={self.exchange_code})"


@dataclass
class LiquidityDateCurrency:
    inflow: float = 0.0
    outflow: float = 0.0
    equity_in_total: float = 0.0
    equity_in: Dict[LiquidityIdentifier, float] = field(default_factory=dict)
    equity_out_total: float = 0.0
    equity_out: Dict[LiquidityIdentifier, float] = field(default_factory=dict)
    etf_in_total: float = 0.0
    etf_in: Dict[LiquidityIdentifier, float] = field(default_factory=dict)
    etf_out_total: float = 0.0
    etf_out: Dict[LiquidityIdentifier, float] = field(default_factory=dict)
    dvp_in_total: float = 0.0
    dvp_in: Dict[LiquidityIdentifier, float] = field(default_factory=dict)
    dvp_out_total: float = 0.0
    dvp_out: Dict[LiquidityIdentifier, float] = field(default_factory=dict)


@dataclass
class LiquidityDate:
    hkd: LiquidityDateCurrency = field(default_factory=LiquidityDateCurrency)
    usd: LiquidityDateCurrency = field(default_factory=LiquidityDateCurrency)
    cnh: LiquidityDateCurrency = field(default_factory=LiquidityDateCurrency)

    def __repr__(self):
        return f"{asdict(self)}"


LiquidityData = Dict[datetime, LiquidityDate]

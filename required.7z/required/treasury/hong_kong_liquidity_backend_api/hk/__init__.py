from flask_restx import Namespace

ns = Namespace("HongKong", path="/")

from aac.tsdos.treasury.hong_kong_liquidity_backend_api.hk.v1 import views # noqa

from datetime import datetime

import requests
from aac.tsdos.sf_common.common_functions import env_detect
from aac.tsdos.sf_common.util import Logger
from aac.tsdos.treasury.hong_kong_liquidity_backend_api.authentication import (
    authentication_required,
    handle_cors_request)
from aac.tsdos.treasury.hong_kong_liquidity_backend_api.constants import http_status_code
from aac.tsdos.treasury.hong_kong_liquidity_backend_api.hk import ns
from aac.tsdos.treasury.hong_kong_liquidity_backend_api.hk.hk_liquidity import format_data_by_settlement_date
from flask import Response, request
from flask_restx import Api, Resource


def abort_if_report_doesnt_exist(settlement_date, response_data):
    """

    @param settlement_date: settlement date coming from frontend use to filter
    @param response_data: response coming from the api
    @return: for empty results returns with proper message
    """
    if (
        len(response_data["data"]["unsettledEquityInflow"]) == 0
        and len(response_data["data"]["unsettledEquityOutflow"]) == 0
        and len(response_data["data"]["otherDVPInflow"]) == 0
        and len(response_data["data"]["otherDVPOutflow"]) == 0
        and len(response_data["data"]["micsEtfInflow"]) == 0
        and len(response_data["data"]["micsEtfOutflow"]) == 0
    ):
        ns.abort(
            http_status_code.HTTP_404_NOT_FOUND,
            f"No Reports Found Here for settlement date {settlement_date}",
        )
        return f"No Reports Found Here for settlement date {settlement_date}"


@ns.route(
    "/settlements/<settlement_date>", methods=["GET", "OPTIONS"], strict_slashes=False
)
@ns.param("settlement_date", "The filter to get Reports")
@ns.param("currency", "The filter to get Reports")
class SettlementDetails(Resource):
    """
    To fetch settlement details against many filters
    """

    # To authenticate against different environments and handle cors use below decorators comment
    # out if authentication not required
    @authentication_required
    @handle_cors_request
    def get(self):
        """
        :return: Get Reports For Settlements Filtered By Particular Date
        """
        settlement_date = request.args.get('settlement_date', None)
        currency = request.args.get('currency', None)

        # detecting environment to run code
        run_env = env_detect()
        if run_env not in ("DEV", "SIT", "UAT", "PROD"):
            raise EnvironmentError(
                f"EXE-ERROR-002: Environment {run_env} not recognized."
            )

        # getting response from api
        try:
            response_data = format_data_by_settlement_date(
                datetime.strptime(settlement_date, "%Y-%m-%d"), currency)
            # abort_if_report_doesnt_exist(settlement_date_object, response_data)
            if (
                    response_data["data"]["unsettledEquityInflow"] == "null"
                    and response_data["data"]["unsettledEquityOutflow"] == "null"
                    and response_data["data"]["otherDVPInflow"] == "null"
                    and response_data["data"]["otherDVPOutflow"] == "null"
                    and response_data["data"]["micsEtfInflow"] == "null"
                    and response_data["data"]["micsEtfOutflow"] == "null"
            ):
                return f"No Reports Found Here for settlement date {settlement_date} and currency {currency}"
            else:
                return response_data, http_status_code.HTTP_200_OK
        except Exception as e:
            return e

import json
import sys
from datetime import date
from typing import List

import pandas as pd
from aac.tsdos.sf_common.util import Logger
from aac.tsdos.sf_data_caller import pythonODBCImpala as pODBC


class DataGatherer:
    """
    This is the parent class to call methods from python odbc impala file
    to get different reports data
    """

    def __init__(self, env: str, day: date, log: Logger):
        """
        :param env: the environment the program run's on
        :param day: the day the program runs for
        :param log: the log to write log statements to
        """
        self.env = env
        self.day = day
        self.log = log

        self.log.debug("Data Gatherer object initiated")

    def _retrieve_connection(self):
        """
        The function that retrieves data and turns it into a collection of data entry objects.
        """
        podbc_instance = pODBC.DatahubConnectionService(
            env=self.env, day=self.day, log=self.log
        )
        return podbc_instance

    def unsettled_equity_inflow_data(self):
        """
        It is to generate json output from get_inflow_amount_unsettled_equity()
        :param:
        :return: json list and total
        """
        inflow_amount_unsettled_equity = (
            self._retrieve_connection().get_inflow_amount_unsettled_equity()
        )

        inflow_amount_unsettled_equity_df = pd.DataFrame(inflow_amount_unsettled_equity)
        total_inflow_amount_unsettled_equity = inflow_amount_unsettled_equity_df[
            "amount"
        ].sum()

        return inflow_amount_unsettled_equity, total_inflow_amount_unsettled_equity

    def unsettled_equity_outflow_data(self):
        """
        It is to generate json output from get_outflow_amount_unsettled_equity()
        :param:
        :return: json list and total
        """
        outflow_amount_unsettled_equity = (
            self._retrieve_connection().get_outflow_amount_unsettled_equity()
        )
        outflow_amount_unsettled_equity_df = pd.DataFrame(
            outflow_amount_unsettled_equity
        )
        total_outflow_amount_unsettled_equity = outflow_amount_unsettled_equity_df[
            "amount"
        ].sum()
        return outflow_amount_unsettled_equity, total_outflow_amount_unsettled_equity

    def other_dvps_inflow_data(self):
        """
        It is to generate json output from get_inflow_amount_other_dvp()
        :param:
        :return: json list and total
        """
        inflow_amount_other_dvps = (
            self._retrieve_connection().get_inflow_amount_other_dvp()
        )
        inflow_amount_other_dvps_df = pd.DataFrame(inflow_amount_other_dvps)
        total_inflow_amount_other_dvps = inflow_amount_other_dvps_df["amount"].sum()
        return inflow_amount_other_dvps, total_inflow_amount_other_dvps

    def other_dvps_outflow_data(self):
        """
        It is to generate json output from get_outflow_amount_other_dvp()
        :param:
        :return: json list and total
        """
        outflow_amount_other_dvps = (
            self._retrieve_connection().get_outflow_amount_other_dvp()
        )
        outflow_amount_other_dvps_df = pd.DataFrame(outflow_amount_other_dvps)
        total_outflow_amount_other_dvps = outflow_amount_other_dvps_df["amount"].sum()
        return outflow_amount_other_dvps, total_outflow_amount_other_dvps

    def mics_etf_inflow_data(self):
        """
        It is to generate json output from get_inflow_amount_mics_etf()
        :param:
        :return: json list and total
        """
        inflow_amount_mics_etf = (
            self._retrieve_connection().get_inflow_amount_mics_etf()
        )
        inflow_amount_mics_etf_df = pd.DataFrame(inflow_amount_mics_etf)
        total_inflow_amount_mics_etf = inflow_amount_mics_etf_df["amount"].sum()
        return inflow_amount_mics_etf, total_inflow_amount_mics_etf

    def mics_etf_outflow_data(self):
        """
        It is to generate json output from get_outflow_amount_mics_etf()
        :param:
        :return: json list and total
        """
        outflow_amount_mics_etf = (
            self._retrieve_connection().get_outflow_amount_mics_etf()
        )
        outflow_amount_mics_etf_df = pd.DataFrame(outflow_amount_mics_etf)
        total_outflow_amount_mics_etf = outflow_amount_mics_etf_df["amount"].sum()
        return outflow_amount_mics_etf, total_outflow_amount_mics_etf

    def prepare_metadata_and_output(self):
        """
        It is to generate metadata and output
        :param:
        :return: details
        """
        Totalinflow = (
            int(self.unsettled_equity_inflow_data()[1])
            + int(self.other_dvps_inflow_data()[1])
            + int(self.mics_etf_inflow_data()[1])
        )
        Totaloutflow = (
            int(self.unsettled_equity_outflow_data()[1])
            + int(self.other_dvps_outflow_data()[1])
            + int(self.mics_etf_outflow_data()[1])
        )
        return {
            "data": {
                "transactionDate": "null",
                "settlementDate": self.day.strftime("%Y-%m-%d"),
                "totalInflow": Totalinflow,
                "totalOutflow": Totaloutflow,
                "totalInFlowSummary": 0,
                "totalOutFlowSummary": 0,
                "etfCreations": [],
                "efCreationsGroupedByDS": [],
                "etfCreationsTotal": 0,
                "etfCreationsTotalSummary": 0,
                "etfRedemptions": [],
                "etfRedemptionsGroupedByDS": [],
                "etfRedemptionsTotal": 0,
                "etfRedemptionsTotalSummary": 0,
                "unsettledEquityInflow": self.unsettled_equity_inflow_data()[0],
                "unsettledEquityInflowTotal": self.unsettled_equity_inflow_data()[1],
                "unsettledEquityOutflow": self.unsettled_equity_outflow_data()[0],
                "unsettledEquityOutflowTotal": self.unsettled_equity_outflow_data()[1],
                "unsettledEquityInFlowGroupedSummary": [],
                "unsettledEquityOutFlowGroupedSummary": [],
                "unsettledEquityOutflowNettedTotal": 0,
                "unsettledEquityInflowNettedTotal": 0,
                "nettedDVPInflowTotalSummary": 0,
                "nettedDVPOutflowTotalSummary": 0,
                "otherDVPInflow": self.other_dvps_inflow_data()[0],
                "otherDVPInflowTotal": self.other_dvps_inflow_data()[1],
                "otherDVPOutflow": self.other_dvps_outflow_data()[0],
                "otherDVPOutflowTotal": self.other_dvps_outflow_data()[1],
                "micsEtfDetailsViewInflow": [],
                "micsEtfDetailsViewOutflow": [],
                "micsEtfInflow": self.mics_etf_inflow_data()[0],
                "micsEtfInflowSubtotal": self.mics_etf_inflow_data()[1],
                "micsEtfOutflow": self.mics_etf_outflow_data()[0],
                "micsEtfOutflowSubtotal": self.mics_etf_outflow_data()[1],
            }
        }

import json
import os
from datetime import date

from aac.tsdos.sf_common.util import Logger

application_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cache_location = os.path.dirname(application_path)


class DataGatherer:
    """
    A class to gather data from in memory cache
    """

    def __init__(self, env: str, day: date, log: Logger):
        """
        :param env: the environment the program run's on
        :param day: the day the program runs for
        :param log: the log to write log statements to
        """
        self.env = env
        self.day = day
        self.log = log

        self.log.debug("Data Gatherer Start Fetching Data From Cache")

    def _fetch_content_from_cache(self):
        """
        It is to fetch content from cache
        :param: file name
        :return: json object
        """
        file_path = os.path.join(cache_location, "in_memory", "hk_cached_data.json")
        with open(file_path, "r") as file:
            json_object = json.load(file)

        return json_object

    def format_data_by_settlement_date(self):
        """
        This method is to format data filtered by settlement date
        @return: return data expected by frontend
        """

        settlement_date = self.day.strftime("%Y-%m-%d")
        full_data = self._fetch_content_from_cache()
        (
            unsettledEquityInflowTotal,
            otherDVPInflowTotal,
            micsEtfInflowSubtotal,
            unsettledEquityOutflowTotal,
            otherDVPOutflowTotal,
            micsEtfOutflowSubtotal,
        ) = (0, 0, 0, 0, 0, 0)
        (
            unsettledEquityInflow,
            unsettledEquityOutflow,
            otherDVPInflow,
            otherDVPOutflow,
            micsEtfInflow,
            micsEtfOutflow,
        ) = (None, None, None, None, None, None)

        for items in full_data:
            if (
                items["settlement_date"] == settlement_date
                and items["product"] == "Unsettled Equity In Flow"
            ):
                for i in items["data"]:
                    i["product"] = "Unsettled Equity"
                unsettledEquityInflow = items["data"]
                unsettledEquityInflowTotal = sum(
                    d.get("amount", 0) for d in unsettledEquityInflow
                )

            elif (
                items["settlement_date"] == settlement_date
                and items["product"] == "Unsettled Equity Out Flow"
            ):
                for i in items["data"]:
                    i["product"] = "Unsettled Equity"
                unsettledEquityOutflow = items["data"]
                unsettledEquityOutflowTotal = sum(
                    d.get("amount", 0) for d in unsettledEquityOutflow
                )

            elif (
                items["settlement_date"] == settlement_date
                and items["product"] == "Other DVP In Flow"
            ):
                for i in items["data"]:
                    i["product"] = "Other DVP"
                otherDVPInflow = items["data"]
                otherDVPInflowTotal = sum(d.get("amount", 0) for d in otherDVPInflow)

            elif (
                items["settlement_date"] == settlement_date
                and items["product"] == "Other DVP Out Flow"
            ):
                for i in items["data"]:
                    i["product"] = "Other DVP"
                otherDVPOutflow = items["data"]
                otherDVPOutflowTotal = sum(d.get("amount", 0) for d in otherDVPOutflow)

            elif (
                items["settlement_date"] == settlement_date
                and items["product"] == "Mics ETF In Flow"
            ):
                for i in items["data"]:
                    i["product"] = "Mics ETF"
                micsEtfInflow = items["data"]
                micsEtfInflowSubtotal = sum(d.get("amount", 0) for d in micsEtfInflow)

            elif (
                items["settlement_date"] == settlement_date
                and items["product"] == "Mics ETF Out Flow"
            ):
                for i in items["data"]:
                    i["product"] = "Mics ETF"
                micsEtfOutflow = items["data"]
                micsEtfOutflowSubtotal = sum(d.get("amount", 0) for d in micsEtfOutflow)

        Totalinflow = (
            unsettledEquityInflowTotal + otherDVPInflowTotal + micsEtfInflowSubtotal
        )
        Totaloutflow = (
            unsettledEquityOutflowTotal + otherDVPOutflowTotal + micsEtfOutflowSubtotal
        )

        etfRedemptionsTotal,etfCreationsTotal = 0,0
        etfCreationsTotalSummary = micsEtfOutflowSubtotal + etfCreationsTotal
        etfRedemptionsTotalSummary = micsEtfInflowSubtotal + etfRedemptionsTotal

        nettedDVPInflowTotalSummary,nettedDVPOutflowTotalSummary = 0,0
        otherDVPTotal = otherDVPInflowTotal + otherDVPOutflowTotal
        if (otherDVPTotal > 0) :
            nettedDVPInflowTotalSummary = otherDVPTotal
        else:
            nettedDVPOutflowTotalSummary = otherDVPTotal

        unsettledEquityInflowNettedTotal,unsettledEquityOutflowNettedTotal =0,0
        unsettledTotal = unsettledEquityInflowTotal + unsettledEquityOutflowTotal
        if (unsettledTotal > 0):
            unsettledEquityInflowNettedTotal = unsettledTotal
        else:
            unsettledEquityOutflowNettedTotal= unsettledTotal

        totalInflowSummary = nettedDVPInflowTotalSummary + unsettledEquityInflowNettedTotal + etfRedemptionsTotalSummary
        totalOutflowSummary = nettedDVPOutflowTotalSummary + unsettledEquityOutflowNettedTotal + etfCreationsTotalSummary
        data = {
            "data": {
                "transactionDate": "null",
                "settlementDate": settlement_date,
                "totalInflow": Totalinflow,
                "totalOutflow": Totaloutflow,
                "totalInflowSummary": totalInflowSummary,
                "totalOutflowSummary": totalOutflowSummary,
                "etfCreations": [],
                "efCreationsGroupedByDS": [],
                "etfCreationsTotal": etfCreationsTotal,
                "etfCreationsTotalSummary": micsEtfOutflowSubtotal + etfCreationsTotal,
                "etfRedemptions": [],
                "etfRedemptionsGroupedByDS": [],
                "etfRedemptionsTotal": etfRedemptionsTotal,
                "etfRedemptionsTotalSummary": micsEtfInflowSubtotal + etfRedemptionsTotal,
                "unsettledEquityInflow": unsettledEquityInflow,
                "unsettledEquityInflowTotal": unsettledEquityInflowTotal,
                "unsettledEquityOutflow": unsettledEquityOutflow,
                "unsettledEquityOutflowTotal": unsettledEquityOutflowTotal,
                "unsettledEquityInFlowGroupedSummary": [],
                "unsettledEquityOutFlowGroupedSummary": [],
                "unsettledEquityOutflowNettedTotal": unsettledEquityOutflowNettedTotal,
                "unsettledEquityInflowNettedTotal": unsettledEquityInflowNettedTotal,
                "nettedDVPInflowTotalSummary": nettedDVPInflowTotalSummary,
                "nettedDVPOutflowTotalSummary": nettedDVPOutflowTotalSummary,
                "otherDVPInflow": otherDVPInflow,
                "otherDVPInflowTotal": otherDVPInflowTotal,
                "otherDVPOutflow": otherDVPOutflow,
                "otherDVPOutflowTotal": otherDVPOutflowTotal,
                "micsEtfInflow": micsEtfInflow,
                "micsEtfInflowSubtotal": micsEtfInflowSubtotal,
                "micsEtfOutflow": micsEtfOutflow,
                "micsEtfOutflowSubtotal": micsEtfOutflowSubtotal,
            }
        }
        return data
   

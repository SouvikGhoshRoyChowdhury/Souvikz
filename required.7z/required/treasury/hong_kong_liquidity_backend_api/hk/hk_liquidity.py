import threading
import confluent_kafka
import multiprocessing.connection
from typing import Optional, List, Union, Literal, Dict
from datetime import datetime
import re

from aac.tsdos.treasury.hong_kong_liquidity_backend_api.hk.hk_liquidity_typing import (
    LiquidityIdentifier,
    LiquidityDateCurrency,
    LiquidityDate,
    LiquidityData
)
from aac.tsdos.sf_common.util import Logger
from aac.tsdos.sf_common.common_functions import env_detect
from aac.tsdos.sf_data_caller import pythonODBCImpala as pODBC


if env_detect() == "PROD":
    BOOTSTRAP_SERVERS = 'gbslixaacpchc04.windmill.local,gbslixaacpchc05.windmill.local,' \
                        'gbslixaacpchc06.windmill.local,gbslixaacpchc07.windmill.local'  # Cloudera kafka
else:
    # Note: unlike on PROD, server 06 and 07 are used for disaster recovery, not general UAT functionality.
    BOOTSTRAP_SERVERS = 'gbslixaacuchc04.windmill.local,gbslixaacuchc05.windmill.local'  # Cloudera kafka
# BOOTSTRAP_SERVERS = 'SASL_SSL://lkc-nv1g0v-4xm1q.eu-central-1.aws.glb.confluent.cloud:9092'

TOPIC_HKL = "GRIP_ConTransactionJson"
DEFAULT_PORT = 4499


Category = Union[Literal['ETF'], Literal['DVP'], Literal['equity']]
Direction = Union[Literal['in'], Literal['out']]
Currency = Union[Literal['hkd'], Literal['usd'], Literal['cnh']]


class HKLiquidity(threading.Thread):
    def __init__(self, env: str, data_date: datetime, log: Logger):
        super(HKLiquidity, self).__init__()
        self.env = env
        self.data_date = data_date
        self.log = log
        self.data: LiquidityData = {}

        # These variables are assigned during the run function
        self.reply_thread = None
        self.kafka_thread = None

    def run(self) -> None:
        # Load EoD data.
        self.log.debug("Loading End of Day data")
        self._load_eod_data()

        self.reply_thread = HKLiquidityReply(self.env, self.data_date, self.log, self)
        self.reply_thread.start()
        self.kafka_thread = HKLiquidityKafka(self.env, self.data_date, self.log, self)
        self.kafka_thread.start()

    def _load_eod_data(self):
        podbc = pODBC.DatahubConnectionService(self.env, self.data_date, self.log)
        hk_eod_positions = podbc.get_hk_unsettled_positions()

        for hk_eod_position in hk_eod_positions:
            opposite_party = hk_eod_position['opposite_party']
            settlement_date = hk_eod_position['settlement_date']
            currency: Currency = hk_eod_position['currency_code'].lower()  # noqa
            identifier = LiquidityIdentifier(
                client_number=hk_eod_position['client_number'], opposite_party_code=opposite_party,
                exchange_code=hk_eod_position['exchange'])
            quantity = hk_eod_position['quantity']

            # Category
            if 'ETF' in opposite_party:
                category: Category = "ETF"
            elif 'DVP' in opposite_party or opposite_party == 'OTC':
                category: Category = "DVP"
            else:
                category: Category = "equity"

            # Direction
            if hk_eod_position['buy_sell_code'] == 'S':
                direction: Direction = 'in'
            else:
                direction: Direction = 'out'

            self.update_position(
                settlement_date=settlement_date, currency=currency, identifier=identifier,
                direction=direction, category=category, quantity=quantity)

    def update_position(
            self,
            settlement_date: datetime,
            currency: Currency,
            identifier: LiquidityIdentifier,
            direction: Direction,
            category: Category,
            quantity: float
    ) -> None:
        # If trade is for a date that has no data, creates data for that date
        if settlement_date not in self.data:
            self.data[settlement_date] = LiquidityDate()

        date_currency_subset: LiquidityDateCurrency = getattr(self.data[settlement_date], currency)

        # Increases the relevant numbers and get the relevant position dict
        if direction == "in":
            date_currency_subset.inflow += quantity
            if category == "ETF":
                date_currency_subset.etf_in_total += quantity
                position_dict = date_currency_subset.etf_in
            elif category == "DVP":
                date_currency_subset.dvp_in_total += quantity
                position_dict = date_currency_subset.dvp_in
            else:  # category 'equity'
                date_currency_subset.equity_in_total += quantity
                position_dict = date_currency_subset.equity_in
        else:  # direction 'out'
            date_currency_subset.outflow += quantity
            if category == "ETF":
                date_currency_subset.etf_out_total += quantity
                position_dict = date_currency_subset.etf_out
            elif category == "DVP":
                date_currency_subset.dvp_out_total += quantity
                position_dict = date_currency_subset.dvp_out
            else:  # category 'equity'
                date_currency_subset.equity_out_total += quantity
                position_dict = date_currency_subset.equity_out

        # Add the trade to the relevant list
        if identifier not in position_dict:
            position_dict[identifier] = 0.0
        position_dict[identifier] += quantity


class HKLiquidityReply(threading.Thread):
    def __init__(self, env: str, data_date: datetime, log: Logger, parent: HKLiquidity):
        super(HKLiquidityReply, self).__init__()
        self.env = env
        self.data_date = data_date
        self.log = log
        self.parent = parent

        self.running = None
        self.port = DEFAULT_PORT
        address = ('localhost', self.port)
        self.listener = multiprocessing.connection.Listener(address)

    def run(self) -> None:
        """
        While running, the Request Thread will continually receive messages, and read them one-by-one. Every message
        must be a dictionary with the "type" attribute, which is used to differentiate between different types of data
        requests.
        """
        self.running = True
        while self.running:
            try:
                conn = self.listener.accept()
                message = conn.recv()
                try:
                    if message['type'] == "date_currency":
                        reply = self.reply_for_date_currency(message['datetime'], message['currency'])
                    elif message['type'] == "shutdown":
                        self.running = False
                        reply = "Shut down complete"
                    else:
                        reply = f"Function {message['type']} not available"
                except Exception as e:
                    self.log.error(
                        f'HKL-ERROR-006: Data Caller encountered error {e} while replying to request {message}.')
                    reply = e
                conn.send(reply)
                conn.close()
            except ConnectionResetError or EOFError:
                self.log.warn(f"Request Thread encountered connection reset error while running.")

        # shutdown
        self.listener.close()

    @staticmethod
    def translate_positions(positions: Dict[LiquidityIdentifier, float], product: Currency, settlement_date: datetime):
        position_dicts = []
        for identifier, quantity in positions.items():
            position_dicts.append({
                'amount': quantity,
                'exchange': identifier.exchange_code,
                'issuer': identifier.client_number,
                'oppositeParty': identifier.opposite_party_code,
                'product': product,
                'settlementDate': settlement_date})
        return position_dicts

    def reply_for_date_currency(self, settlement_date: datetime, currency: Currency):
        if settlement_date not in self.data:
            self.data[settlement_date] = LiquidityDate()
        cd: LiquidityDateCurrency = getattr(self.data[settlement_date], currency)

        return {
            "data": {
                'settlementDate': settlement_date,

                'totalInflow': cd.inflow,
                'totalOutflow': cd.outflow,
                'totalInflowSummary': cd.inflow - cd.outflow if cd.inflow > cd.outflow else 0.0,
                'totalOutflowSummary': cd.outflow - cd.inflow if cd.outflow > cd.inflow else 0.0,

                'micsEtfInflow': self.translate_positions(cd.etf_in, currency, settlement_date),
                'micsEtfInflowSubtotal': cd.etf_in_total,

                'micsEtfOutflow': self.translate_positions(cd.etf_out, currency, settlement_date),
                'micsEtfOutflowSubtotal': cd.etf_out_total,

                'otherDVPInflow': self.translate_positions(cd.dvp_in, currency, settlement_date),
                'otherDVPInflowTotal': cd.dvp_in_total,
                'nettedDVPInflowTotalSummary':
                    cd.dvp_in_total - cd.dvp_out_total if cd.dvp_in_total > cd.dvp_out_total else 0.0,

                'otherDVPOutflow': self.translate_positions(cd.dvp_out, currency, settlement_date),
                'otherDVPOutflowTotal': cd.dvp_out_total,
                'nettedDVPOutflowTotalSummary':
                    cd.dvp_out_total - cd.dvp_in_total if cd.dvp_out_total > cd.dvp_in_total else 0.0,

                'unsettledEquityInflow': self.translate_positions(cd.equity_in, currency, settlement_date),
                'unsettledEquityInflowTotal': cd.equity_in_total,
                'unsettledEquityInflowNettedTotal':
                    cd.equity_in_total - cd.equity_out_total if cd.equity_in_total > cd.equity_out_total else 0.0,

                'unsettledEquityOutflow': self.translate_positions(cd.equity_out, currency, settlement_date),
                'unsettledEquityOutflowTotal': cd.equity_out_total,
                'unsettledEquityOutflowNettedTotal':
                    cd.equity_out_total - cd.equity_in_total if cd.equity_out_total > cd.equity_in_total else 0.0,

                'unsettledEquityInFlowGroupedSummary': None,  # Currently Unused
                'unsettledEquityOutFlowGroupedSummary': None,  # Currently unused
                'transactionDate': None,  # Unused

                'etfCreations': None,  # Helios, not available yet
                'etfCreationsGroupedByDS': None,  # Helios, not available yet
                'etfCreationsTotal': None,  # Helios, not available yet
                'etfCreationsTotalSummary': None,  # Helios, not available yet
                'etfRedemptions': None,  # Helios, not available yet
                'etfRedemptionsGroupedByDS': None,  # Helios, not available yet
                'etfRedemptionsTotal': None,  # Helios, not available yet
                'etfRedemptionsTotalSummary': None,  # Helios, not available yet
            }
        }

    @property
    def data(self) -> LiquidityData:
        return self.parent.data


class HKLiquidityKafka(threading.Thread):
    topics = [TOPIC_HKL]

    def __init__(self, env: str, data_date: datetime, log: Logger, parent: HKLiquidity):
        super(HKLiquidityKafka, self).__init__()
        self.env = env
        self.data_date = data_date
        self.log = log
        self.parent = parent

        # These values are set during start-up process
        self.consumer: Optional[confluent_kafka.Consumer] = None
        self.start_timestamp = None
        self.exit_flag: Optional[threading.Event] = None

        pattern = r"({\\\"CanTransaction\\\":.*?SourceMessageSequenceGroup\\\":\\\"MICSAP\|FCH\|(STRANS|UTRANS)\|" \
                  r".*?\\\".*?\\\"CanMovementInstrument)"
        self.regex = re.compile(pattern, re.DOTALL)

        field_pattern = r"(\"TransactionType\":\"[A-Z ]{5,20}\")|" \
                        r"(\"ClientLevel2\":\"[0-9]{1,6}\")|" \
                        r"(\"SettlementDate\":\"[0-9-]{10}\")|" \
                        r"(\"BuySellIndicator\":\"[BS]{1}\")|" \
                        r"(\"TradeCurrency\":\"[A-Za-z]{3}\")|" \
                        r"(\"PlaceOfTrade\":\"[A-Z ]{2,10}\")|" \
                        r"(\"Counterparty\":\{\"PartyID\":\"[0-9A-Z ]{3,10}\")|" \
                        r"(\"Primary\":\{\"Value\":\"[0-9.]{1,16}\")"
        self.regex_fields = re.compile(field_pattern, re.DOTALL)

        self.handled_ccys = {"USD", "HKD", "CNH"}

        # Warning variables
        self.startup_catchup_complete = False
        self.warn_limit_seconds = 120
        self.error_limit_seconds = 360
        self.last_receive_time: Optional[float] = None
        self.message_timing_warning_active = False
        self.message_timing_error_active = False

    def run(self) -> None:
        # Start up consumer.
        self.log.debug("Starting Kafka consumer")
        self.consumer = self._start_consumer()
        self.start_timestamp = self.get_kafka_timestamp(datetime.now())
        self.set_consumer_to_timestamp(self.consumer, self.start_timestamp)

        # General message-handling loop
        self.log.debug("Starting kafka handling")
        self.exit_flag = threading.Event()
        while not self.exit_flag.wait(timeout=0.0001):
            message = self.consumer.poll(timeout=0.1)
            if message is not None:
                if not self.check_timestamp(message):
                    continue
                self.handle_message(message)

    def _start_consumer(self) -> confluent_kafka.Consumer:
        """
        Starts up and returns the kafka consumer for the Hong Kong liquidity cache
        :return: The kafka consumer
        """
        # conf = {
        #     'group.id': f'tsdos_hkl_group_{datetime.now().strftime("%Y%m%d_%H%M")}',
        #     # 'ssl.endpoint.identification.algorithm': 'https',
        #     # 'sasl.jaas.config': 'org.apache.kafka.common.security.plain.PlainLoginModule required username="{{ CLUSTER_API_KEY }}" password="{{ CLUSTER_API_SECRET }}";',
        #     # 'security.protocol': 'sasl_ssl',
        #     'sasl.mechanism': 'GSSAPI',
        #     'sasl.kerberos.service.name': '447881',
        #     # 'sasl.username': 'CLUSTER_API_KEY',
        #     # 'sasl.password': 'CLUSTER_API_SECRET',
        #     'bootstrap.servers': BOOTSTRAP_SERVERS,
        #     'session.timeout.ms': 60000,
        #     'enable.auto.commit': False,
        #     'auto.offset.reset': 'earliest'}
        conf = {
            'group.id': f'tsdos_hkl_group_{datetime.now().strftime("%Y%m%d_%H%M")}',
            'bootstrap.servers': BOOTSTRAP_SERVERS,
            'session.timeout.ms': 60000,
            'enable.auto.commit': False,
            'auto.offset.reset': 'earliest'}
        consumer = confluent_kafka.Consumer(conf)

        self.log.debug("subscribing to the following topics: " + str(self.topics))
        consumer.subscribe(self.topics)
        self.log.debug("Subscription successful, trying to poll to get assignments")
        consumer.poll(timeout=10)  # a single poll is necessary for subscriptions to get assigned.

        # Raise errors if no assignment is present for a topic
        self.log.debug("Polled assignment message, validating assignment...")
        self._validate_topic_assignment(consumer, self.topics)
        self.log.debug("Assignment Successful")

        return consumer

    @staticmethod
    def _validate_topic_assignment(consumer: confluent_kafka.Consumer, topics: List[str]) -> None:
        """
        Raises an error if the given consumer does not have assignments for each of the given topics. Used to check if
        consumer was successfully instantiated.
        :param consumer: the given consumer.
        :param topics: the list of topics to check for.
        """
        topic_partitions = consumer.assignment()
        assigned_topic_set = {topic_partition.topic for topic_partition in topic_partitions}
        if len(assigned_topic_set) != len(topics):
            missing_topics = set()
            for topic in topics:
                if topic not in assigned_topic_set:
                    missing_topics.add(topic)

            raise RuntimeError(f"No assignments could be made for the following topics: {missing_topics}")

    @staticmethod
    def get_kafka_timestamp(run_time: datetime) -> int:
        """
        Get the kafka timestamp (regular timestamp times 1000) for start of day of the given datetime
        :param run_time: The given datetime
        :return: The kafka timestamp
        """
        comparison_datetime = datetime(run_time.year, run_time.month, run_time.day)
        start_timestamp = int(datetime.timestamp(comparison_datetime) * 1000)
        return start_timestamp

    @staticmethod
    def set_consumer_to_timestamp(consumer: confluent_kafka.Consumer, timestamp: int) -> None:
        """
        Sets the given consumer to the given timestamp
        :param consumer: The given consumer
        :param timestamp: The timestamp to set the consumer to
        """
        # Sets the offset per partition
        topic_partitions: List[confluent_kafka.TopicPartition] = consumer.assignment()
        for topic_partition in topic_partitions:
            topic_partition.offset = timestamp

        # Seeks to the given offset per partition
        partition_offsets: List[confluent_kafka.TopicPartition] = consumer.offsets_for_times(topic_partitions)
        for topic_partition in partition_offsets:
            consumer.seek(topic_partition)

    def check_timestamp(self, message) -> bool:
        # Weird timestamp types
        message_timestamp_type, message_timestamp = message.timestamp()
        if message_timestamp_type == confluent_kafka.TIMESTAMP_NOT_AVAILABLE:
            self.log.warn(f"Encountered Kafka message with unavailable timestamp.")
            return False
        elif message_timestamp < 0:
            self.log.warn(f"Encountered Kafka message with invalid timestamp '{message_timestamp}'.")
            return False
        elif message_timestamp_type == confluent_kafka.TIMESTAMP_LOG_APPEND_TIME:
            self.log.warn(f"Encountered Kafka message with log append timestamp.")

        # Outdated Messages
        if message_timestamp < self.start_timestamp:
            return False

        # Warnings for startup and stuff
        receive_now = datetime.now()
        receive_time = datetime.timestamp(receive_now)
        self.handle_message_time_alerts(
            receive_time=receive_time, send_time=(message.timestamp()[1] / 1000))

        return True

    def handle_message_time_alerts(self, receive_time: float, send_time: float):
        diff = receive_time - send_time

        if not self.startup_catchup_complete:
            if diff < self.warn_limit_seconds:
                self.startup_catchup_complete = True
                self.log.debug(
                    f"Difference between kafka messages being sent and kafka messages being received "
                    f"has fallen to {diff} seconds. Topic is no longer in start-up state.")

            if self.last_receive_time is None:
                self.last_receive_time = receive_time
            elif self.last_receive_time + 60 < receive_time:
                self.startup_catchup_complete = True
                self.log.debug(
                    f"No message has been received for more than one minute. Topic is no "
                    f"longer in start-up state.")

            self.last_receive_time = receive_time
        elif diff > self.error_limit_seconds:
            if not self.message_timing_error_active:
                self.message_timing_error_active = True
                self.message_timing_warning_active = False
                self.log.debug(
                    f"MAJOR: Difference between kafka messages being sent and kafka messages being received is "
                    f"at {diff} seconds")
        elif diff > self.warn_limit_seconds:
            if not self.message_timing_warning_active:
                self.message_timing_error_active = False
                self.message_timing_warning_active = True
                self.log.debug(
                    f"MEDIUM: Difference between kafka messages being sent and kafka messages being received is at "
                    f"{diff} seconds")
        elif self.message_timing_error_active or self.message_timing_warning_active:
            self.message_timing_warning_active = False
            self.message_timing_error_active = False
            self.log.debug(
                f"Difference between kafka messages being sent and kafka messages being received has fallen to {diff} "
                f"seconds. Kafka thread no longer in critical state.")

    def handle_message(self, message):
        message_string: str = message.value().decode('utf-8')
        blocks = self.regex.findall(message_string)

        for block in blocks:
            field_blocks = self.regex_fields.findall(block[0])
            transaction_type = field_blocks[0][0][19:-1]
            if transaction_type == "TRADE":
                direction: Direction = "in"
            elif transaction_type == "SETTLEMENT":
                direction: Direction = "out"
            else:
                continue
            client_number = int(field_blocks[1][1][16:-1])
            settlement_date = field_blocks[2][2][18:-1]
            buy_sell = field_blocks[3][3][20:-1]
            currency = field_blocks[4][4][17:-1]
            if currency not in self.handled_ccys:
                continue
            exchange = field_blocks[5][5][16:-1]
            counterparty = field_blocks[6][6][27:-1]
            value = float(field_blocks[7][7][20:-1])
            if 'ETF' in counterparty:
                category: Category = "ETF"
            elif 'DVP' in counterparty or counterparty == 'OTC':
                category: Category = "DVP"
            else:
                category: Category = "equity"

            value = -value if buy_sell == "S" else value

            identifier = LiquidityIdentifier(
                client_number=client_number, opposite_party_code=counterparty,
                exchange_code=exchange)

            self.parent.update_position(
                settlement_date=settlement_date, currency=currency, identifier=identifier,
                direction=direction, category=category, quantity=value)


def format_data_by_settlement_date(data_date: datetime, currency: str):
    message = {
        'type': 'date_currency',
        'datetime': data_date,
        'currency': currency}

    client = multiprocessing.connection.Client(('localhost', DEFAULT_PORT))
    client.send(message)
    reply = client.recv()
    client.close()

    return reply


def main():
    run_env = env_detect()
    if run_env not in ("DEV", "SIT", "UAT", "PROD"):
        raise EnvironmentError(f"EXE-ERROR-002: Environment {run_env} not recognized.")
    run_log = Logger('tsdos.treasury', run_env)

    hk_liquidity_cache = HKLiquidity(run_env, datetime.now(), run_log)
    hk_liquidity_cache.start()


if __name__ == "__main__":
    main()

from flask import Flask
from aac.tsdos.sf_data_caller.live_data_caller_api import (
    tsdos_api,
    api_log,
)

# Setting up root url for the entire service for hong kong liquidity api
ROOT_URL = "/service/treasury/hk-liquidity"


def create_app(config_name):
    """

    @param config_name: taking config name as per environment from config file
    @return: application object
    """
    from aac.tsdos.treasury.hong_kong_liquidity_backend_api.config import app_config

    app = Flask(__name__)
    app.config.from_object(app_config[config_name])
    app.config["APPLICATION_ROOT"] = ROOT_URL

    with app.app_context():
        from aac.tsdos.treasury.hong_kong_liquidity_backend_api.api_v1 import blueprint as api

        app.register_blueprint(api, url_prefix=ROOT_URL + "/api/v1.0")
    return app

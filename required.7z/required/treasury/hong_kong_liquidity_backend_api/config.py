import os

PROJECT_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Config:
    """Parent configuration class."""

    DEBUG = False
    TESTING = False
    # Declare a variable HOST to pick value from environmental variable
    # if not take the default
    HOST = os.getenv("APP_HOST", "0.0.0.0")
    # Declare a variable POST to pick value from environmental variable
    # if not take the default
    PORT = os.getenv("APP_PORT", "8350")
    # Setting this variable ensure that flask restx doc is enabled and
    # available at the url
    API_DOCS_URL = "/doc/"


class DevelopmentConfig(Config):
    """Configurations for Development."""

    DEBUG = True


class SitConfig(Config):
    """Configurations for Testing, with a separate test database."""

    TESTING = True
    DEBUG = True
    HOST = "10.248.148.185"
    PORT = "5000"


class UatConfig(Config):
    """Configurations for Staging."""

    DEBUG = True
    HOST = "10.248.168.208"
    PORT = "5000"


class ProductionConfig(Config):
    """Configurations for Production."""

    # Setting this variable to false disables the docs on production
    DEBUG = False
    API_DOCS_URL = False


app_config = {
    "development": DevelopmentConfig,
    "sit": SitConfig,
    "uat": UatConfig,
    "production": ProductionConfig,
}

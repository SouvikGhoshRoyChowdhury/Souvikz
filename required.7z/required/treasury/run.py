from aac.tsdos.treasury.wsgi import app
from aac.tsdos.treasury.hong_kong_liquidity_backend_api.hk.hk_liquidity import main as hk_liquidity_main

if __name__ == "__main__":
    # uncomment this to test against uat
    # app.run(debug=True, host='10.248.168.208', port=5001)
    app.run(debug=True, host='0.0.0.0', port=5000)

    # Starts Hong Kong Liquidity cache
    hk_liquidity_main()

# This is the python script calling cache.py to generate cache and dump it in a file
import datetime

from aac.tsdos.sf_common.common_functions import env_detect
from aac.tsdos.sf_common.util import Logger
from aac.tsdos.treasury.in_memory.cache import DataGatherer

run_env = env_detect()
if run_env not in ("DEV", "SIT", "UAT", "PROD"):
    raise EnvironmentError(f"EXE-ERROR-002: Environment {run_env} not recognized.")
print(run_env)
run_log = Logger("tsdos.hkcache", run_env)

data_gatherer = DataGatherer(env=run_env, day=datetime.date.today(), log=run_log)

response_data = data_gatherer.prepare_metadata_and_output()
print(response_data)
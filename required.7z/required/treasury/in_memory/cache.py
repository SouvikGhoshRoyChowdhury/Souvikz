import json
import os
import sys
from datetime import date
from functools import reduce
from typing import List

import pandas as pd
from aac.tsdos.sf_common.util import Logger
from aac.tsdos.sf_data_caller import pythonODBCImpala as pODBC

this_folder = os.path.dirname(__file__)



class DataGatherer:
    """
    This is Cache Logic Class which is responsible to retreive data from datalake
    and to be executed by job schedular at certain time
    """

    def __init__(self, env: str, day: date, log: Logger):
        """
        :param env: the environment the program run's on
        :param day: the day the program runs for
        :param log: the log to write log statements to
        """
        self.env = env
        self.day = day
        self.log = log

        self.log.debug("Data Gatherer object initiated")

    def _retrieve_connection(self):
        """
        The function that retrieves data and turns it into a collection of data entry objects.
        """
        podbc_instance = pODBC.DatahubConnectionService(
            env=self.env, day=self.day, log=self.log
        )
        return podbc_instance

    def unsettled_equity_inflow_data(self):
        """
        It is to get all data from datalake for unsettled equity incoming flow
        :param:
        :return: dataframe containing data grouped by settlement date
        """
        inflow_amount_unsettled_equity = (
            self._retrieve_connection().get_inflow_amount_unsettled_equity()
        )
        inflow_amount_unsettled_equity_df = pd.DataFrame(inflow_amount_unsettled_equity)

        return inflow_amount_unsettled_equity_df

    def unsettled_equity_outflow_data(self):
        """
        It is to get all data from datalake for unsettled equity out flow
        :param:
        :return: dataframe containing data grouped by settlement date
        """
        outflow_amount_unsettled_equity = (
            self._retrieve_connection().get_outflow_amount_unsettled_equity()
        )
        outflow_amount_unsettled_equity_df = pd.DataFrame(
            outflow_amount_unsettled_equity
        )

        return outflow_amount_unsettled_equity_df

    def other_dvps_inflow_data(self):
        """
        It is to get all data from datalake for other dvps inflow data
        :param:
        :return: dataframe containing data grouped by settlement date
        """
        inflow_amount_other_dvps = (
            self._retrieve_connection().get_inflow_amount_other_dvp()
        )
        inflow_amount_other_dvps_df = pd.DataFrame(inflow_amount_other_dvps)

        return inflow_amount_other_dvps_df

    def other_dvps_outflow_data(self):
        """
        It is to get all data from datalake for other dvps out flow data
        :param:
        :return: dataframe containing data grouped by settlement date
        """
        outflow_amount_other_dvps = (
            self._retrieve_connection().get_outflow_amount_other_dvp()
        )
        outflow_amount_other_dvps_df = pd.DataFrame(outflow_amount_other_dvps)

        return outflow_amount_other_dvps_df

    def mics_etf_inflow_data(self):
        """
        It is to get all data from datalake for mics etf inflow data
        :param:
        :return: dataframe containing data grouped by settlement date
        """
        inflow_amount_mics_etf = (
            self._retrieve_connection().get_inflow_amount_mics_etf()
        )
        inflow_amount_mics_etf_df = pd.DataFrame(inflow_amount_mics_etf)

        return inflow_amount_mics_etf_df

    def mics_etf_outflow_data(self):
        """
        It is to get all data from datalake for mics etf out flow data
        :param:
        :return: dataframe containing data grouped by settlement date
        """
        outflow_amount_mics_etf = (
            self._retrieve_connection().get_outflow_amount_mics_etf()
        )
        outflow_amount_mics_etf_df = pd.DataFrame(outflow_amount_mics_etf)

        return outflow_amount_mics_etf_df

    def prepare_metadata_and_output(self):
        """
        It is to generate metadata and output and write to a json file
        :param:
        :return: details
        """

        dataframes = [
            self.unsettled_equity_inflow_data(),
            self.unsettled_equity_outflow_data(),
            self.other_dvps_inflow_data(),
            self.other_dvps_outflow_data(),
            self.mics_etf_inflow_data(),
            self.mics_etf_outflow_data(),
        ]
        final_df = pd.concat(dataframes).fillna("none")

        final_df_group_by_product_and_settlement_date_list = []
        final_df_group_by_product_and_settlement_date = final_df.groupby(
            ["settlementDate", "product"]
        )
        for each_data in final_df_group_by_product_and_settlement_date:
            # print(each_data)
            final_df_group_by_product_and_settlement_date_list.append(
                {
                    "settlement_date": each_data[0][0],
                    "product": each_data[0][1],
                    "data": each_data[1].to_dict("records"),
                }
            )

        data = final_df_group_by_product_and_settlement_date_list
        with open(os.path.join(this_folder, "hk_cached_data.json"), "w") as file:
            file.write(json.dumps(data, indent=4))
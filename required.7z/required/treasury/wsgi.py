import os

from hong_kong_liquidity_backend_api.app import create_app
from werkzeug.middleware.proxy_fix import ProxyFix

# Getting the value from environmental variable based on where application is going to deploy
config_name = os.getenv("APP_SETTINGS", "development")
app = create_app(config_name)


# You only need ProxyFix if your app is deployed behind an ELB.
# It adds the `Forwarded` headers
app.wsgi_app = ProxyFix(app.wsgi_app)

import datetime
import json
import os.path

import pandas as pd

from aac.tsdos.secfin_script.data_gatherer import DataGatherer
from aac.tsdos.sf_common.common_functions import env_detect, get_previous_business_days
from aac.tsdos.sf_common.util import Logger


def process_synthetics_data(
    soi_list_file_name: str, bloomberg_data_file_name: str
) -> any:
    """
    This function is to process incoming soi list and bloomberg data to generate processes synthetics file
    @param soi_list_file_name: input soi list file absolute path inside quote
    @param bloomberg_data_file_name: input bloomberg list file absolute path inside quote
    @return: output synthetics csv file
    """

    # Activating the respective environment
    run_env = env_detect()
    if run_env not in ("DEV", "SIT", "UAT", "PROD"):
        raise EnvironmentError(f"EXE-ERROR-002: Environment {run_env} not recognized.")
    print(run_env)

    # Activating the logger to handle log meesages
    run_log = Logger("tsdos.synthetics", run_env)

    # Read the requested data from SOIList
    soi_data_found = True
    with open(soi_list_file_name, "r") as fs:
        try:
            soi_json_object = json.load(fs)
            print(f"SOI list has {len(soi_json_object)} rows")
            run_log.info(f"SOI list has {len(soi_json_object)} rows")
        except Exception as e:
            soi_data_found = False
            error = f"no data present in soi list {e}"
            # print(error)
            # run_log.info(error)

    # Reading the Bloomberg Data File
    bloomberg_data_found = True
    with open(bloomberg_data_file_name, "r") as fs:
        try:
            bloomberg_json_object = json.load(fs)
            print(f"Bloomberg file has {len(bloomberg_json_object)} rows")
            run_log.info(f"Bloomberg file has {len(bloomberg_json_object)} rows")
        except Exception as e:
            bloomberg_data_found = False
            error = f"no data present in bloomberg file {e}"
            # print(error)
            # run_log.info(error)

    # To check whether soi list and bloomberg file both or each one of them is empty
    if not soi_data_found or not bloomberg_data_found:
        run_log.info(f"Exiting program for reason {error}")
        raise SystemExit(error)
    elif not soi_data_found and not bloomberg_data_found:
        run_log.info("no input data found")
        raise SystemExit("no input data found")

    # Initializing data gatherer with present date
    data_gatherer = DataGatherer(
        env=run_env, day=datetime.date(2023, 3, 10), log=run_log
    )

    # Getting data from datalake based on ISIN,Exchange_Uid and Country Code and converting country code 'GB' to 'UK' where it present
    response_data = []
    for item in soi_json_object:
        if "error" not in item:
            if item["cty_uid"] == "GB":
                country_code = "UK"
                response_data.append(
                    data_gatherer.get_data_markit_eqtyearly(
                        isin=item["ISIN"],
                        mic_code=item["exch_uid"],
                        country_code=country_code,
                    )
                )
            else:
                response_data.append(
                    data_gatherer.get_data_markit_eqtyearly(
                        isin=item["ISIN"],
                        mic_code=item["exch_uid"],
                        country_code=item["cty_uid"],
                    )
                )

    # Converting SOIList into dataframe
    soi_dataframe = pd.DataFrame(response_data)

    # Renaming the columns in data frame to display it in output file
    soi_dataframe.rename(
        columns={
            "AVERAGE": "AVAILABILITY AVG 10D",
            "COUNTRY_CODE": "COUNTRY CODE",
            "MIC_CODE": "MIC CODE",
        },
        inplace=True,
    )

    print("******************this is soi list dataframe******************")
    print(soi_dataframe)
    run_log.info(f"processed soi list dataframe")

    # Converting Bloomberg file into dataframe
    bloomberg_dataframe = pd.DataFrame(bloomberg_json_object)
    bloomberg_dataframe.rename(
        columns={
            "SECURITIES": "ISIN",
            "BBG_CODE": "BBG CODE",
            "EQY_SH_OUT": "OUTSTANDING SHARES",
            "PX_VOLUME_1D": "VOLUME",
            "MIC_CODE": "MIC CODE",
        },
        inplace=True,
    )

    # Format OUTSTANDING SHARES values as per requirement
    bloomberg_dataframe["OUTSTANDING SHARES"] = pd.to_numeric(
        bloomberg_dataframe["OUTSTANDING SHARES"]
    )
    bloomberg_dataframe["OUTSTANDING SHARES"] = (
        bloomberg_dataframe["OUTSTANDING SHARES"]
        .multiply(1000000)
        .map("{:,.0f}".format)
        .str.replace(",", "")
    )

    print("******************this is bloomberg file dataframe******************")
    print(bloomberg_dataframe)
    run_log.info(f"processed bloomberg list dataframe ")

    # Merge SOI List file with Bloomberg File
    soi_dataframe.drop_duplicates(subset=["ISIN", "MIC CODE"], inplace=True)
    soi_bloomberg_joined_dataframe = pd.merge(
        soi_dataframe, bloomberg_dataframe, on=["ISIN", "MIC CODE"]
    )

    # Prepare output file
    bloomberg_and_soi_list_coulmns_in_order = [
        "ISIN",
        "BBG CODE",
        "COUNTRY CODE",
        "MIC CODE",
        "VOLUME",
        "AVAILABILITY",
        "OUTSTANDING SHARES",
        "RATE",
        "VOLUME_AVG_5D",
        "VOLUME_AVG_10D",
        "VOLUME_AVG_30D",
        "AVAILABILITY AVG 10D",
    ]
    soi_bloomberg_joined_dataframe = soi_bloomberg_joined_dataframe.reindex(
        columns=bloomberg_and_soi_list_coulmns_in_order
    )
    print(
        "******************this is output file without bloomberg data but with columns******************"
    )
    print(soi_bloomberg_joined_dataframe)
    run_log.info(f"merged soi list dataframe with bloomberg list dataframe")

    # Arranging location to save output file
    parent_directory = os.path.dirname(os.path.abspath((__file__)))
    output_location = os.path.join(
        parent_directory, "output_files", "output_soi_bloomberg_joined.csv"
    )
    soi_bloomberg_joined_dataframe.to_csv(output_location, sep=";", index=False)
    run_log.info(f"successfully converted merged dataframe into csv")
    return f"Please check output folder for generated file"


if __name__ == "__main__":
    """
    Main function change the input files for test and call the function
    """
    soi_list_file_name = "input_files/test_soi.json"
    bloomberg_data_file_name = "input_files/test_bloomberg.json"
    process_synthetics_data(soi_list_file_name, bloomberg_data_file_name)

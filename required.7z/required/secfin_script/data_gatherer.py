import os
from datetime import date


from aac.tsdos.sf_data_caller import pythonODBCImpala as pODBC
from aac.tsdos.sf_common.util import Logger

this_folder = os.path.dirname(__file__)


class DataGatherer:
    """
    This is data gatherer class to query synthetics data from data lake
    """

    def __init__(self, env: str, day: date, log: Logger):
        """
        :param env: the environment the program run's on
        :param day: the day the program runs for
        :param log: the log to write log statements to
        """
        self.env = env
        self.day = day
        self.log = log

        self.log.debug("Data Gatherer object initiated")

    def _retrieve_connection(self):
        """
        The function that retrieves data and turns it into a collection of data entry objects.
        """
        podbc_instance = pODBC.DatahubConnectionService(
            env=self.env, day=self.day, log=self.log
        )
        return podbc_instance

    def get_data_markit_eqtyearly(self, isin, mic_code, country_code):
        """
        It is to get active_available_quantity, tradable_fee from datalake
        :param:
        :return: json data
        """
        get_markit_eqtyearly_data = self._retrieve_connection().get_query_markit_early(
            isin, mic_code, country_code
        )
        return get_markit_eqtyearly_data

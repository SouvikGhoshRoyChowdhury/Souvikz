import requests
# import httpx
import io
import os
from datetime import datetime
# from model.validation import ValidationError
# from httpx import Response
import json

async def get_weather_latlon(lat: float, lon: float) -> dict:
    url = f"https://www.7timer.info/bin/api.pl?lon={float(lon)})&lat={float(lat)}&product=civil&output=json"
    response = requests.get(url,proxies = {'https':'10.249.191.93:8080'}, verify = False)
    # async with httpx.AsyncClient() as client:
    #     resp: Response = await client.get(url)
    #     if resp.status_code != 200:
    #         raise ValidationError(resp.text, status_code=resp.status_code)
    data = response.json()
    return data
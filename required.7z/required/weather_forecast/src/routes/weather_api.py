import weather_forecast.src.model.data_fetcher as model
from fastapi import APIRouter, Depends, Query
from datetime import datetime,timezone,timedelta

router = APIRouter()

@router.get(
    "/api/7timer-latlon/",
    tags=['Weather Forecast']
)
async def get_weather_latlon(
    lat: float = Query(
        ...,
        title="Latitude",
        description="Query string for the weather to search based on Latitude and Longitude",
    ),
    lon: float = Query(
        ...,
        title="Longitude",
        description="Query string for the weather to search based on Latitude and Longitude",
    )
):
    response = await model.get_weather_latlon(lat, lon)
    now_utc = datetime.utcnow().replace(tzinfo=timezone.utc)
    print(now_utc.strftime("%Y%m%d%H"))
    next_48_hours_utc = (datetime.utcnow().replace(tzinfo=timezone.utc) + timedelta(hours=48))
    print(next_48_hours_utc.strftime("%Y%m%d%H"))
    init_time= response["init"]
    init_time_utc = datetime.strptime(init_time,"%Y%m%d%H")
    total_records = len(response["dataseries"])
    outputs=[]
    start_period_utc = init_time_utc
    for data in response["dataseries"]:
        end_period_utc = start_period_utc + timedelta(hours=3)
        if end_period_utc < next_48_hours_utc:
            outputs.append({"start_period_utc":start_period_utc.strftime("%Y%m%d%H"),
                            "end_period_utc":end_period_utc.strftime("%Y%m%d%H"),
                            "cloud_cover":data["cloudcover"],
                            "temparature":data["temp2m"]})
            start_period_utc = end_period_utc

    return outputs
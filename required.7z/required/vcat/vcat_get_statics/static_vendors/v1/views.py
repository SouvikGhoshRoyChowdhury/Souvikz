import json
import os
from datetime import datetime
import requests
from aac.tsdos.sf_common.common_functions import env_detect
from aac.tsdos.sf_common.util import Logger
from aac.tsdos.vcat.vcat_get_statics.authentication import (
    authentication_required, handle_cors_request)
from aac.tsdos.vcat.vcat_get_statics.constants import \
    http_status_code
from aac.tsdos.vcat.vcat_get_statics.static_vendors import ns
from flask import Response, request
from flask_restx import Api, Resource



this_folder = os.path.dirname(__file__)

with open("H:/python_code/sf_trading_analytics/aac/tsdos/vcat/in_memory/sample_vendors.json", "r") as file:
    response_content = json.loads(file.read())



@ns.route(
    "/vendors", methods=["GET", "OPTIONS"], strict_slashes=False
)
class VendorsList(Resource):
    """
    To get list of vendors
    """
    @ns.doc("list vendors")
    # To authenticate against different environments and handle cors use below decorators comment
    # out if authentication not required
    @authentication_required
    @handle_cors_request
    def get(self):
        """
        List all vendors
        """
        return response_content, http_status_code.HTTP_200_OK

@ns.route("/vendors/<int:id>")
@ns.doc(responses={http_status_code.HTTP_404_NOT_FOUND: "Vendor not found"}, params={"id": "The Vendor ID"})
class VendorFilter(Resource):
    """
    To filter a vendor by id
    """
    @ns.doc(description="id should be integer")
    @authentication_required
    @handle_cors_request
    def get(self,id):
        """Fetch a given resource"""
        for item in response_content['data']:
            if item["id"] == id:
                return item,http_status_code.HTTP_200_OK
        else :
            ns.abort(http_status_code.HTTP_404_NOT_FOUND, "Vendor {} doesn't exist".format(id))


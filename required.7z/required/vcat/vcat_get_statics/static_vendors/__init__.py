from flask_restx import Namespace

ns = Namespace("VendorsStatic", path="/")

from aac.tsdos.vcat.vcat_get_statics.static_vendors.v1 import views # noqa

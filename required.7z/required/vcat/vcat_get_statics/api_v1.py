# This file is actually initializing blueprint per api version
from aac.tsdos.vcat.vcat_get_statics.static_vendors import ns as ns_vendors
from flask import Blueprint, current_app
from flask_restx import Api

blueprint = Blueprint("api_1_0", __name__)

# Initializing Api with blueprint and custom swagger document endpoint
api = Api(blueprint, doc=current_app.config["API_DOCS_URL"], catch_all_404s=True)

api.namespaces.clear()
api.add_namespace(ns_vendors)

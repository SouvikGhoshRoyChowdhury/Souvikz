from functools import wraps

import requests
from aac.tsdos.sf_common.common_functions import env_detect
from aac.tsdos.sf_common.util import Logger
from aac.tsdos.treasury.hong_kong_liquidity_backend_api.constants import \
    http_status_code
from flask import Response, jsonify, request

TOKEN_VALIDATION = (
    "https://cp-gateway-wizard-portal-prod.apps.ocp-eu.windmill.local/api/validate/"
)
TOKEN_VALIDATION_UAT = (
    "https://cp-gateway-wizard-portal-uat.apps.ocp-eu.windmill.local/api/validate/"
)

api_log = Logger("tsdos.treasury", env_detect())

# Decorator for authenticate a request
def authentication_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if request.method == "OPTIONS":
            return func(*args, **kwargs)

        run_env = env_detect()
        if run_env not in ("SIT", "UAT", "PROD"):
            print(
                f"Environment {run_env} is not needed to be authenticate or authorized."
            )
            return func(*args, **kwargs)

        iv_user = request.headers.get("iv-user")
        wp_authorization = request.headers.get("wp-authorization")
        api_log.debug(f"Received request from {iv_user}.")
        verify = "/etc/ssl/certs/ca-bundle.crt"
        token_api_url = TOKEN_VALIDATION if run_env == "PROD" else TOKEN_VALIDATION_UAT

        token_reply = requests.get(
            url=token_api_url,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "cache-control": "no-cache",
                "iv-user": iv_user,
                "wp-authorization": wp_authorization,
            },
            verify=verify,
        )
        token_reply_json: dict = token_reply.json()
        token_status_code = token_reply_json["status"]
        token_message = token_reply_json.get("message")
        token_data = token_reply_json.get("data")

        if token_status_code != http_status_code.HTTP_200_OK:
            return (
                jsonify(dict(message="Forbidden")),
                http_status_code.HTTP_403_FORBIDDEN,
            )

        return func(*args, **kwargs)

    return wrapper


# Decorator to handle cross origin resource sharing request i.e OPTIONS mainly
def handle_cors_request(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if request.method == "OPTIONS":
            api_log.debug("Replying to pre-flight request")
            preflight_response = Response()
            preflight_response.headers.add("Access-Control-Allow-Origin", "*")
            preflight_response.headers.add("Access-Control-Allow-Headers", "*")
            preflight_response.headers.add("Access-Control-Allow-Methods", "*")
            return preflight_response
        return func(*args, **kwargs)

    return wrapper

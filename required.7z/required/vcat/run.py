from aac.tsdos.vcat.wsgi import app

if __name__ == "__main__":
    # uncomment this to test against uat
    # app.run(debug=True, host='10.248.168.208', port=5001)
    app.run(debug=True,host='0.0.0.0', port=5002)

import json
import sys
import pandas as pd
from datetime import date
from typing import List

from aac.tsdos.sf_common.util import Logger
from aac.tsdos.sf_data_caller import pythonODBCImpala as pODBC
from aac.tsdos.sf_data_caller.pythonODBCImpala import SharkAPIFeedingTuple


class JsonConverter:
    """
    This is the parent class to convert pyodbc object in json
    """

    def __init__(self, env: str, day: date, log: Logger):
        """
        :param env: the environment the program run's on
        :param day: the day the program runs for
        :param log: the log to write log statements to
        """
        self.env = env
        self.day = day
        self.log = log

        self.log.debug( "Json Converter object initiated")


    def _retrieve_connection(self):
        """
        The function that retrieves data and turns it into a collection of data entry objects.
        """
        podbc_instance = pODBC.DatahubConnectionService(env=self.env, day=self.day, log=self.log)
        return podbc_instance

    def _generate_json(self) :
        """
        It is to generate json output from get_early_equity_market_rates()
        :param: pythonOBDCImpala Connection object
        :return: json string
        """
        json_output = []

        try:
            qresults = self._retrieve_connection().get_early_equity_market_rates()
            if len(qresults) == 0:
                raise Exception(f"No data from datahub for the date {self.day},Please see the log for more information")
                self.log.error(f"No data from datahub for the date {self.day},Please see the log for more information")
                sys.exit(1)
            else:
                # making namedtuple into dictionaries
                for result in qresults:
                    json_output.append(result._asdict())
        except Exception as e:
            print(f'it is likely to be ecaused by {e},kindly check logs for more')
            self.log.error(f'it is likely to be ecaused by {e},kindly check logs for more')
            import traceback
            print(traceback.print_exc())
            raise SystemExit(1)


        # building dataframe form json
        result_df = pd.DataFrame(json_output)

        # fill None value with zero
        result_df["RebateRate"] = result_df["RebateRate"].fillna(0)

        # apply bps logic as per business requirement
        result_df["RebateRate"] = result_df["RebateRate"].apply(
            lambda x: 50 if (50 - x) >= 19 else (x + 20 if (50 - x) < 19 and x < 1000 else x + 100))

        # making tradable fee into percentage
        result_df["RebateRate"] = result_df["RebateRate"].apply(lambda x: format(x / 100, '.5f'))

        # filter out for zone code like AU JP SG HK

        zone_list_to_filter_out = ["AU","JP","SG","HK"]
        result_df = result_df.query('ZoneCode in @zone_list_to_filter_out')

        return result_df.to_dict('records')


import datetime
import holidays
import sys

from lxml import etree
import pandas as pd
import requests
import xmltodict
import json
from requests import Session
from requests.auth import HTTPBasicAuth
from zeep import Client, Settings
from zeep.plugins import HistoryPlugin
from zeep.transports import Transport
from zeep.exceptions import Fault

from aac.tsdos.sf_common.common_functions import env_detect,get_future_business_days,get_present_and_next_business_day_after_holidays
from aac.tsdos.sf_common.util import Logger
from aac.tsdos.shark_automation.data_gatherer import JsonConverter

holiday_apac = holidays.JP() + holidays.HK() + holidays.AU()+ holidays.SG()

def feed_market_rate_shark():
    """
    Driver code to populate shark market rates into broadridge api
    """

    # setting session variables including proxy
    session = Session()
    # TODO
    session.verify = False
    session.proxies = {'https': 'proxy.windmill.local:8080'}
    transport = Transport(session=session, timeout=20)
    history = HistoryPlugin()
    settings = Settings(strict=False, xml_huge_tree=True)

    # Soap api endpoint i.e wsdl where we will make request
    wsdl = "https://test-anetics.broadridge.com/abnamro/web/MarketRates.asmx?WSDL"

    # Original code
    # detecting environment to run code
    run_env = env_detect()
    if run_env not in ("DEV", "SIT", "UAT", "PROD"):
        raise EnvironmentError(f"EXE-ERROR-002: Environment {run_env} not recognized.")
    print(run_env)

    # setting up logger instance with the correct environment
    run_log = Logger("tsdos.soap", run_env)

    # Initialize the clinet object
    try:
        print("trying to connect zeep client")
        run_log.info("trying to connect zeep client")
        client = Client(
            wsdl=wsdl, settings=settings, transport=transport, plugins=[history]
        )
    except Fault as error:
        print(f"not able to connect zeep client due to {error}")
        run_log.info(f"not able to connect zeep client due to {error}")
        raise Exception("please check proxies first")

    # Fetch data form data_gatherer
    rateitems = JsonConverter(
        env=run_env, day=datetime.date.today(), log=run_log
    )._generate_json()

    # Getting total number of rateitems and preparing chunks
    total_length = len(rateitems)
    chunk_size = 400
    print(f"size of requests for today is equals to {total_length}")
    run_log.info(f"size of requests for today is equals to {total_length}")

    # payload template which needs to be filled based on data
    payload = {
        "credentials": "sys.marketrates|Walnut-54",
        "termDate": get_future_business_days(2,holiday_list=holiday_apac).strftime("%m-%d-%Y"),
        "rateItems": None,
    }

    # If total items is greater then the limit then it will divide in further chunks
    if total_length > chunk_size:
        rateitem_chunks = [
            rateitems[item : item + chunk_size]
            for item in range(0, total_length, chunk_size)
        ]

        for parts in rateitem_chunks:
            payload["rateItems"] = {"RateItem": parts}
            try:
                response = client.service.ListSet(**payload)
                print(
                    f"succesfully posted data in broadridge api from datahub with {response}"
                )
                run_log.info(
                    "succesfully posted data in broadridge api from datahub with response : ",
                    response,
                )

            except Fault as error:
                print(f"Zeep Error: {error}")
                run_log.error(f"Zeep Error: {error}")
    else:
        payload["rateItems"] = {"RateItem": rateitems}
        try:
            response = client.service.ListSet(**payload)
            print(
                f"succesfully posted data in broadridge api from datahub with {response}"
            )
            run_log.info(
                "succesfully posted data in broadridge api from datahub", response
            )

        except Fault as error:
            print(f"Zeep Error: {error}")
            run_log.error(f"Zeep Error: {error}")

    # to print request and reponse sent received respectively
    requests_sent_and_received_list=[]
    for hist in [history.last_sent, history.last_received]:
        beauty_strings = etree.tostring(hist["envelope"], encoding="unicode", pretty_print=True)
        requests_sent_and_received_list.append(beauty_strings)

    run_log.info(f'output',requests_sent_and_received_list)
    return requests_sent_and_received_list

if __name__ == "__main__":
    feed_market_rate_shark()


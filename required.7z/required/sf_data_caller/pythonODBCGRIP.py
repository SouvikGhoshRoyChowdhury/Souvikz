import os
import configparser
import json  # FIXME remove after SBTR-2056 is on PROD
import pyodbc
from typing import List, Tuple
# import zeep
# from zeep.wsse.username import UsernameToken
# from zeep.wsse.signature import Signature
# from zeep.wsse import utils
from datetime import datetime, timedelta

from aac.tsdos.sf_common.util import Logger

this_dir = os.path.dirname(__file__)  # FIXME remove after SBTR-2056 is on PROD


# TODO certificate in soap header. will get authentication and certification data in future email.
#  switch over data handling to xml handling.
#  Pagination is implemented, can be increased up to 20000. Don't try to go in the high thousands, might break the
#  system. Total page numbers


# class UsernameTokenTimestamp:
#     def __init__(self, username, password=None):
#         self.username = username
#         self.password = password
#
#     def apply(self, envelope, headers):
#         security = utils.get_security_header(envelope)
#
#         created = datetime.now()
#         expired = created + timedelta(seconds=5 * 60)
#
#         token = utils.WSSE.UsernameToken()
#         token.extend([
#             utils.WSSE.Username(self.username),
#             utils.WSSE.Password(self.password),
#             utils.WSSE.Nonce('43d74dda16a061874d9ff27f2b40e017'),
#             utils.WSSE.Created(utils.get_timestamp(created)),
#         ])
#
#         timestamp = utils.WSU('Timestamp')
#         timestamp.append(utils.WSU('Created', utils.get_timestamp(created)))
#         timestamp.append(utils.WSU('Expires', utils.get_timestamp(expired)))
#
#         security.append(timestamp)
#         security.append(token)
#
#
#         headers['Content-Type'] = 'application/soap+xml;charset=UTF-8'
#
#         return envelope, headers
#
#     def verify(self, envelope):
#         pass


config = configparser.ConfigParser()
config.read(os.path.join(os.path.dirname(__file__), '..', 'sf_config', 'sf_data_caller_config', 'env.cfg'))


class GRIPConnectionService:
    """
    This class provides the service used to establish a connection with GRIP
    :var
    env - the database environment to access
    date - the date for which to access information
    connection - the impala connection used to request data
    """

    def __init__(self, env: str, log: Logger) -> None:
        self.log = log
        self.env = env

        # user_name_token = UsernameTokenTimestamp("shared-nonprod-voyager-v2", "devsup")
        # signature = Signature(os.path.join(this_dir, 'intermediate.p12'), os.path.join(this_dir, 'intermediate.p12'))
        # client = zeep.Client(
        #     wsdl='https://gripuatwebservice.metis.prd:58528/voya-be-crossreference-ws/SearchCrossReferenceWebService?wsdl',
        #     wsse=[user_name_token, signature],
        #
        # )

        """Connecting to Impala Big Data hub."""
        old_config = config['old_config ' + self.env]['enabled'] == "True"
        if not old_config:  # TODO remove once GRIP can be connected to from anywhere
            self.connection = self.create_connection()
            self.log.debug('GRIP connection open')

    def create_connection(self) -> pyodbc.Connection:
        """
        Creates an impala connection
        :param
        config - the configuration information for establishing a connection.
        :return
        connection - the created impala connection
        """
        try:
            connection = pyodbc.connect(config["GRIP " + self.env]['src'], autocommit=True)
            return connection
        except pyodbc.Error as e:
            self.log.error("POG-ERROR-001 " + 'GRIP connection error %s', e)

    def _run_query(self, query: str) -> List[pyodbc.Row]:
        """
        Executes the given sql query and returns the result
        :param query: the given query
        :return: the result of the query
        """
        cursor = self.connection.cursor()
        cursor.execute(query)
        return cursor.fetchall()

    def get_grip_mics_to_4s(self) -> List[Tuple[str, str, str, str, str]]:
        """
        Requests a list of settled OR positions on MICS
        :return:
        result - the result of the SQL query
        """
        old_config = config['old_config ' + self.env]['enabled'] == "True"
        if old_config:   # FIXME remove after SBTR-2056 is on PROD
            local_file_name = os.path.join(this_dir, "mics_to_4s.json")
            with open(local_file_name, encoding='utf-8') as f:
                result = json.load(f)
        else:
            sql = '''
                SELECT
                    SOURCE_CODE,
                    TARGET_CODE
                FROM
                    VOYR_RFGS_OWN.TB_WM_CROSSREFERENCES
                WHERE
                    SOURCE_SYSTEM = 'MICSCE' AND
                     TARGET_SYSTEM = '4SIGHT'
            '''
            crossref = self._run_query(sql)
            result = []
            for row in crossref:
                mics: List[str] = row[0].split('|')
                fours: List[str] = row[1].split('|')
                if len(mics) == 2 and len(fours) == 3:
                    result.append((mics[0], mics[1], fours[0], fours[1], fours[2]))
        return result

    def get_grip_4s_to_mics(self) -> List[Tuple[str, str, str, str, str]]:
        """
        Requests a list of settled OR positions on MICS
        :return:
        result - the result of the SQL query
        """
        old_config = config['old_config ' + self.env]['enabled'] == "True"
        if old_config:   # FIXME remove after SBTR-2056 is on PROD
            local_file_name = os.path.join(this_dir, "4s_to_mics.json")
            with open(local_file_name, encoding='utf-8') as f:
                result = json.load(f)
        else:
            sql = '''
                SELECT
                    SOURCE_CODE,
                    TARGET_CODE
                FROM
                    VOYR_RFGS_OWN.TB_WM_CROSSREFERENCES
                WHERE
                    SOURCE_SYSTEM = '4SIGHT' AND
                    TARGET_SYSTEM = 'MICSCE'
            '''
            crossref = self._run_query(sql)
            result = []
            for row in crossref:
                fours: List[str] = row[0].split('|')
                mics: List[str] = row[1].split('|')
                if len(mics) == 2 and len(fours) == 3:
                    result.append((mics[0], mics[1], fours[0], fours[1], fours[2]))
        return result

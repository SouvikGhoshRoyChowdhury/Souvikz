import time
from datetime import datetime


from aac.tsdos.sf_data_caller.live_data_caller_api import tsdos_api
# Extend the API
from aac.tsdos.sf_inventory_ladder import ladder  # noqa
from aac.tsdos.sf_execution.mddr import mddr_api  # noqa
from aac.tsdos.ops import api  # noqa
from aac.tsdos.secfin import api  # noqa


def run_api():
    tsdos_api.run(host='0.0.0.0')
    while True:
        current_time = datetime.now()
        if current_time.hour >= 20:
            break
        else:
            time.sleep(5)

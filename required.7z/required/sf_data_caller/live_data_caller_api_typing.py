from typing import TypedDict, Optional, List


class LDCAPIConfigOption(TypedDict):
    name: str
    value: str
    description: str


class LDCAPIConfigSection(TypedDict):
    name: str
    option: List[LDCAPIConfigOption]


class LDCAPIConfigPayload(TypedDict):
    config_section: List[LDCAPIConfigSection]


class LDCAPIConfig(TypedDict):
    okay: bool
    message: Optional[str]
    data: LDCAPIConfigPayload

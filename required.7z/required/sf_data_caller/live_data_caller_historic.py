import live_data_caller
import os
from datetime import datetime
import time

from aac.tsdos.sf_common.common_functions import env_detect
from aac.tsdos.sf_common.util import Logger
from aac.tsdos.sf_execution.mddr.mddr_data_gatherer import MDDRDataGatherer
from aac.tsdos.sf_data_caller import pythonODBCGRIP


def historic_balancer_run(day):
    env = env_detect()
    original_grip_config = pythonODBCGRIP.config
    pythonODBCGRIP.config = {'old_config DEV': {'enabled': "True"}}

    historic_data_caller = live_data_caller.LiveDataCaller(env, day, is_live=False)
    historic_data_caller.start()
    while not historic_data_caller.running:
        time.sleep(1)
    cp_limits_folderpath = os.path.dirname(os.path.realpath(__file__))
    cp_limits_filename = 'mddr_cp_limits.json'
    run_cp_limits_source_file = os.path.join(cp_limits_folderpath, cp_limits_filename)
    mddr_object = MDDRDataGatherer(log=Logger('tsdos.mdd', env), limits_source_file=run_cp_limits_source_file, custom_data_caller=historic_data_caller, run_date=datetime(year=2022, month=2, day=22))
    print(mddr_object.generate_mddr_oversight())
    # balancer_object = BalancerExecutor(custom_data_caller=historic_data_caller)
    # day_str = day.strftime("%Y-%m-%d")
    # balancer_object.balancer_execution(env=env, day=day_str, projected_days=3, country=None, isin=None)
    #
    # historic_data_caller.shutdown()
    # sys.exit(0)
    live_data_caller.shutdown(historic_data_caller)
    while not historic_data_caller.shutdown_complete:
        time.sleep(0.1)
    pythonODBCGRIP.config = original_grip_config


if __name__ == "__main__":
    historic_balancer_run(datetime(year=2022, month=2, day=22, hour=9, minute=14, second=59))

import sys
import os
import threading
import csv
import json
import time
import shutil
import traceback
from collections import defaultdict, OrderedDict
import configparser
import multiprocessing.connection
from typing import Union, List, Dict, Set, Any, NamedTuple, Optional, Tuple
from typing_extensions import TypedDict
from datetime import datetime, timedelta
import confluent_kafka
from confluent_kafka import Message
# from inventory_processing import InventoryDict
import argparse
from traceback import print_exc

from aac.tsdos.sf_funger import funger
from aac.tsdos.sf_common.util import Logger
from aac.tsdos.sf_common.sanity_check import sanity_check
from aac.tsdos.sf_common.common_functions import (
    env_detect,
    convert_to_python,
    convert_to_bool,
    previous_business_day,
)
from aac.tsdos.sf_data_caller import inventory_processing
from aac.tsdos.sf_data_caller import pythonODBCImpala as pODBC
from aac.tsdos.sf_data_caller import pythonODBCGRIP as pODBC_GRIP
from aac.tsdos.sf_inventory_manager import inventory_manager
from aac.tsdos.sf_inventory_manager import transactions
from aac.tsdos.sf_inventory_manager.transactions import (
    DepotAccountID,
    DepotAccountInfo,
    TransactionDictOR,
    SFContract,
    ORTransaction,
)
from aac.tsdos.sf_refdata.instruments import Instruments, Instrument
from aac.tsdos.sf_refdata.currency_data import CurrencyData
from aac.tsdos.sf_refdata.clients import Clients
from aac.tsdos.sf_refdata.mnemonics import Mnemonics
from aac.tsdos.sf_refdata.market_indexes import MarketIndexes
from aac.tsdos.sf_refdata.reference_rates import ReferenceRates

file_dir = os.path.dirname(__file__)

# Kafka servers
# All four kafka streams can run on each of these servers. There are multiple servers for load balancing.
# if
if env_detect() == "PROD":
    bootstrap_servers = 'gbslixaacpchc04.windmill.local,gbslixaacpchc05.windmill.local,' \
                        'gbslixaacpchc06.windmill.local,gbslixaacpchc07.windmill.local'  # Cloudera kafka
else:
    # Note: unlike on PROD, server 06 and 07 are used for disaster recovery, not general UAT functionality.
    bootstrap_servers = 'gbslixaacuchc04.windmill.local,gbslixaacuchc05.windmill.local'  # Cloudera kafka


active_live_data_caller: Optional['LiveDataCaller'] = None

kafka_sbl = '4Sight_SBLTradeUpdate'
kafka_4s = '4Sight_CollateralTradeUpdate'
kafka_grip = 'GRIP_ConTransactionJson'  # FCA -  Amsterdam, FCH - Hong Kong, FCJ, FCS

config = configparser.ConfigParser()
config.read(os.path.join(file_dir, '..', 'sf_config', 'sf_data_caller_config', 'data_caller.cfg'))

EQUIVALENT_ISIN_FILE = os.path.join(file_dir, config['equivalent_isin']['file_location'])


class ThreadAddress(NamedTuple):
    name: str
    port: int


class CacheDict(TypedDict, total=False):
    cache: Union[Mnemonics, Instruments, MarketIndexes, CurrencyData, Clients]
    name: str
    refresh_rate: Optional[timedelta]
    last_update_time: datetime


class EodTransactionDict(TransactionDictOR):
    quantity_long_prim_prod: Optional[float]
    quantity_short_prim_prod: Optional[float]


class OtherPartyDict(TypedDict):
    code: str
    entity: str


class SecurityDict(TypedDict):
    market_code: str
    isin: str


class SettlementInfo(TypedDict):
    depot: str
    account: str
    date: str


class CcyDict(TypedDict):
    code: str


class CalcMarketValueDict(TypedDict):
    amount: float
    ccy: CcyDict


class PendingReturnDict(TypedDict):
    ref: str
    value_date: str
    trade_date: str
    quantity: float
    recall: bool


class TransactionUser(TypedDict):
    id: str


class TransactionDictSBL(TypedDict, total=False):
    # pending_return is optional
    ref: str
    trade_type: str
    value_date: str
    quantity: float
    status: str
    trade_date: str
    book: OtherPartyDict
    counterparty: OtherPartyDict
    fee_rate: str  # tests give int, live_data_caller.py gives str
    security: SecurityDict
    settlement: SettlementInfo
    termed_date: str  # tests give None results, live_data_caller.py: str
    collateral_margin: float
    calc_market_value: CalcMarketValueDict
    pending_return: List[PendingReturnDict]
    user: TransactionUser


class TransactionDictCollateral(TypedDict):
    ref: str
    trade_type: str
    value_date: str
    quantity: float
    status: str
    trade_date: str
    book: OtherPartyDict
    counterparty: OtherPartyDict
    security: SecurityDict
    settlement: SettlementInfo
    calc_market_value: CalcMarketValueDict
    user: TransactionUser


class RequestDictRefdata(TypedDict):
    type: str
    cache: str


class RequestDictStatic(TypedDict):
    type: str
    cache: str


class RequestDictTransaction(TypedDict):
    type: str
    isins: Optional[List[str]]
    clients: Optional[List[int]]
    counterparties: Optional[List[Tuple[str, str]]]


class RequestDictExternalBorrows(TypedDict):
    type: str
    isin: Optional[List[str]]
    countries: Optional[List[str]]


class RequestDictIsinsPerCountry(TypedDict):
    type: str
    countries: Optional[List[str]]


class RequestDictAggregateInventory(TypedDict):
    type: str
    projected_days: int
    view: inventory_processing.ViewDict
    aggregate_order: List[str]
    position_aggregation: str
    funge: bool
    isin: Optional[List[str]]
    client: Optional[List[int]]
    counterparty: Optional[List[Tuple[str, str]]]
    report_generation: bool
    report_folder: Optional[str]


class SmallestAggregationDict(TypedDict):
    quantityOR: float
    quantitySF: float
    total_longs: float
    total_shorts: float
    total_external_borrows: float
    total_external_borrow_fees: float
    total_pledges: float
    value_per_asset: float


AggregateInventoryDict = Dict[Union[str, int, tuple], Union["AggregateInventoryDict", SmallestAggregationDict]]
# key can be: isin, market, country, settlement_depot, settlement_account, date, status, client, depot, safe_keeping,
# account_type, account, subaccount, trade_type, counterparty, or mnemonic


class MessageDict(TypedDict):
    type: str
    report_folder: str
    isin: str


class LiveDataCaller(threading.Thread):
    """
    The Live Data Caller serves as a central data hub for our programs. It pre-loads all the data we need, and keeps
    it up to date using kafka streams and periodic reference data updates.
    """
    default_starting_port = int(config['ports']['starting_port'])
    default_address = ('localhost', default_starting_port - 1)

    def __init__(
            self, env: str, day: datetime, is_live=True, custom_address=tuple(['localhost', 4500])
    ) -> None:
        super(LiveDataCaller, self).__init__()
        self.env = env

        try:
            self.log = Logger('tsdos.ldc', env=env)
            self.log.debug('Logging activated')

            self.startup_complete = False
            self.shutdown_complete = False

            if is_live:
                self.address = self.default_address
                self.next_port = self.default_starting_port
            else:
                self.address = custom_address
                self.next_port = self.address[1] + 1
            self.available_ports = []
            self.listener = multiprocessing.connection.Listener(self.address)

            # Thread lists
            self.request_threads: List[RequestThread] = []
            self.kafka_threads: List[KafkaThread] = []

            # Kafka diagnostic variables
            self.kafka_outdated_count = defaultdict(int)
            self.kafka_outdated_dates = defaultdict(set)
            self.kafka_message_counter = defaultdict(int)
            self.kafka_transaction_counter = defaultdict(lambda: defaultdict(int))
            self.kafka_last_messages = defaultdict(list)
            self.kafka_last_message_time = defaultdict(int)  # Timestamp that message was sent.

            self.kafka_last_message_handle_times = defaultdict(list)  # for calculating rolling average
            self.kafka_message_send_handle_diff = defaultdict(float)  # time between timestamp and handle time

            if is_live:
                if day.date() != datetime.now().date():
                    self.log.error(f"LDC-ERROR-008: Cannot initiate a data caller with live data for past dates. Given "
                                   f"date is {day}")
                    raise ValueError("Cannot initiate a data caller with live data for past dates. Restart the live"
                                     "data caller with live value set to False.")

                global active_live_data_caller
                if active_live_data_caller is None:
                    active_live_data_caller = self
                else:
                    self.log.error(f"LDC-ERROR-009: A live instance of the data caller ({active_live_data_caller}) is "
                                   f"already running.")
                    raise RuntimeError("A live instance of the data caller is already running.")

            self.config = configparser.ConfigParser()
            self.config.read(os.path.join(file_dir, '..', 'sf_config', 'sf_data_caller_config', 'data_caller.cfg'))

            self.env_config = configparser.ConfigParser()
            self.env_config.read(os.path.join(file_dir, '..', 'sf_config', 'sf_data_caller_config', 'env.cfg'))
            self.use_prd_clone = convert_to_bool(self.env_config["IMPALA " + self.env]['use_prd_alternatives'])
            self.accept_empty_results = convert_to_bool(self.env_config["IMPALA " + self.env]['accept_empty_results'])

            self.day = day
            self.eod_data_day = previous_business_day(self.day)
            self.live = is_live

            self.running = False
            self.api_process: Optional[multiprocessing.Process] = None
            self.inventory_manager: Optional[inventory_manager.InventoryManager] = None
            self.inventory_processor: Optional[inventory_processing.InventoryProcessor] = None

            self.fungers: Optional[funger.Funger] = None

            self.refdata_mnemonics = None
            self.refdata_instruments = None
            self.refdata_market_indexes = None
            self.refdata_currencies = None
            self.refdata_clients = None
            self.refdata_reference_rates = None

        except Exception as e:
            print_exc()
            self.log.error(f"LDC-ERROR-012: Encountered error {e} during Live Data Caller start-up. Live Data Caller is "
                           f"shutting down.")
            self.shutdown()

    def run(self) -> None:
        try:
            self._initiate_reference_caches()
            self._initiate_static_caches()
            self._initiate_transaction_caches()
            self.inventory_processor = inventory_processing.InventoryProcessor(
                self.log, self.inventory_manager, self.refdata_mnemonics, self.fungers, self.day)

            from aac.tsdos.sf_data_caller.live_data_caller_api_init import run_api  # note: outside import block due to import loop
            self.api_process = multiprocessing.Process(target=run_api)  # TODO move to after _start_threads?
            self.api_process.start()

            self.log.debug("Starting threads")

            self._start_threads()

            self.running = True
            self.log.debug("Live data caller successfully instantiated, now answering data requests.")
            while self.running:
                try:
                    self.answer_port_request()
                except KeyboardInterrupt:
                    break
        except Exception as e:
            self.log.error(f"LDC-ERROR-011: Encountered error {e} during Live Data Caller runtime. Live Data Caller is "
                           f"shutting down.")
            print_exc()
        finally:
            self.shutdown()

    def shutdown(self) -> None:
        # Hasattr functions are necessary for cases wherein the live data caller crashed during start-up. This will
        # call the shutdown function, so that the ports utilized by the live data caller will still be freed up.
        if hasattr(self, 'api_process') and self.api_process is not None:
            self.api_process.terminate()
        if hasattr(self, 'listener'):
            self.listener.close()
        if hasattr(self, 'request_threads'):
            for thread in self.request_threads:
                address: Tuple[str, int] = ('localhost', thread.port)
                client = multiprocessing.connection.Client(address)
                client.send({"type": "shutdown"})
                client.recv()
                client.close()

        if hasattr(self, 'kafka_threads'):
            for thread in self.kafka_threads:
                thread.consumer.close()
                thread.exit_flag.set()

        # Waiting for all threads to shut down
        time.sleep(0.5)

        if hasattr(self, 'live'):
            if self.live:
                global active_live_data_caller
                active_live_data_caller = None

        self.log.debug("data caller successfully shut down.")
        self.shutdown_complete = True
        sys.exit(0)

    def answer_port_request(self) -> None:
        """
        Answers a request for a port for an available request thread. Also replies to echo and shutdown commands.
        """
        conn: multiprocessing.connection.Connection = self.listener.accept()
        try:
            message: str = conn.recv()
            if message == "port_request":
                if len(self.available_ports) == 0:
                    self.add_request_thread()
                port = self.available_ports.pop(0)

                conn.send(port)
            elif message == "shutdown":
                conn.send("shutting_down")
                self.running = False
            elif message == "echo":
                conn.send("echo")
        except (ConnectionAbortedError, EOFError, ConnectionResetError) as e:
            self.log.warn(f"Live data caller encountered {e} while answering port requests.")
        conn.close()

    def clear_port(self, port: int) -> None:
        """Adds the given port to the available ports."""
        if port not in self.available_ports:
            self.available_ports.append(port)

    def calculate_missing_dates(self) -> int:
        _podbc = pODBC.DatahubConnectionService(self.env, self.eod_data_day, self.log)
        latest_position_date = _podbc.get_latest_position_date()
        diff = datetime.date(self.day) - latest_position_date
        return diff.days - 1

    """===========================|=========|=========|============|=========|=========|================================
    ==============================|=========|=========|=REF CACHES=|=========|=========|================================
    ==============================|=========|=========|============|=========|=========|============================="""
    def _initiate_reference_caches(self) -> None:
        """
        Initiates the various reference caches. A single attribute (references_caches) stores these caches, with the
        keys being the names of these caches, and the values being dictionaries containing the actual cache, the name
        and the refresh rate.
        """
        self.refdata_mnemonics = Mnemonics(self.env, self.eod_data_day, self.log)
        self.refdata_instruments = Instruments(self.env, self.eod_data_day, self.log)
        self.refdata_market_indexes = MarketIndexes(self.env, self.eod_data_day, self.log)
        self.refdata_currencies = CurrencyData(self.env, self.eod_data_day, self.log)
        self.refdata_clients = Clients(self.env, self.eod_data_day, self.log)
        self.refdata_reference_rates = ReferenceRates(self.env, previous_business_day(self.eod_data_day), self.log)

        self.log.debug(f"All reference caches successfully initialized.")

    """==========================|=========|=========|==============|=========|=========|===============================
    =============================|=========|=========|=OTHER CACHES=|=========|=========|===============================
    =============================|=========|=========|==============|=========|=========|============================"""
    def _initiate_static_caches(self) -> None:
        """
        Initiates the various Static caches (non-updating caches drawn from sources other than the database)
        """
        self._initiate_market_country_dictionary()
        self._initiate_known_countries()
        self._initiate_isins_per_country()
        self._initiate_settlement_depot_account_dict()
        self._initiate_equivalent_isins_dict()
        self._initiate_fungers()
        self.log.debug(f"All static caches successfully initialized.")

    def _initiate_market_country_dictionary(self) -> None:
        """
        Initiates a dictionary that matches markets with their corresponding countries. Keys are market codes,
        values are country codes.
        """
        self.market_country_dictionary: Dict[str, str] = self.refdata_instruments.generate_market_country_dictionary()
        self.log.debug(f"Market Country Dictionary loaded with {len(self.market_country_dictionary)} markets")
        if len(self.market_country_dictionary) == 0 and not self.accept_empty_results:
            self._throw_loading_error("market country dictionary")

    def _initiate_known_countries(self) -> None:
        """
        Initiates a set consisting of all known country codes.
        """
        self.known_countries: Set[str] = set()
        for country in self.market_country_dictionary.values():
            if country not in self.known_countries:
                self.known_countries.add(country)
        self.log.debug(f"Known Countries list initiated. {len(self.known_countries)} countries known.")

    def _initiate_isins_per_country(self) -> None:
        """
        Initiates a dictionary of which countries have which isins active in them. Keys are country codes, values
        are sets of isins.
        """
        self.isins_per_country: Dict[str, Set[str]] = {}
        _podbc = pODBC.DatahubConnectionService(self.env, self.eod_data_day, self.log)
        isin_countries = _podbc.get_isins_for_countries_all()
        for isin_country_pair in isin_countries:
            isin = isin_country_pair.isin
            country = isin_country_pair.country
            if country not in self.isins_per_country:
                self.isins_per_country[country] = set()
            self.isins_per_country[country].add(isin)
        self.log.debug(f"Isins per country initiated.")
        if self.isins_per_country == {} and not self.accept_empty_results:
            self._throw_loading_error("isins per country")

    def _initiate_settlement_depot_account_dict(self) -> None:
        """
        Initiates a dictionary used to translate Depot IDs and Account Ids into market countries, depots and accounts.
        Keys are tuples consisting of depot id and account id, values are dicts consisting of country codes, depot
        names and account names.
        """
        self.settlement_depot_account_dict: Dict[DepotAccountID, DepotAccountInfo] = {}
        connection = pODBC_GRIP.GRIPConnectionService(self.env, self.log)
        rows = connection.get_grip_4s_to_mics()
        rows += connection.get_grip_mics_to_4s()
        for row in rows:
            self.settlement_depot_account_dict[DepotAccountID(row[0], row[1])] = {
                "market_country": row[2], "depot": row[3], "account": row[4]}
        self.log.debug(f"Settlement depot account initiated.")
        if self.settlement_depot_account_dict == {} and not self.accept_empty_results:
            self._throw_loading_error("Depot/Account conversion")

    def _initiate_equivalent_isins_dict(self) -> None:
        """
        Initiate a dictionary that identifies "equivalent isins" (isins that cover the exact same underlying property).
        Dictionary key is the isin str and value is the equivalent isin str.
        """
        self.equivalent_isins_dict: Dict[str, str] = {}
        if not os.path.exists(EQUIVALENT_ISIN_FILE):
            self._throw_loading_error("Equivalent ISINs")
        with open(EQUIVALENT_ISIN_FILE) as csv_file:
            reader = csv.reader(csv_file, delimiter='\t')
            for row in reader:
                self.equivalent_isins_dict[row[0]] = row[1]
                self.equivalent_isins_dict[row[1]] = row[0]
        self.log.debug(f"Equivalent isins dict initiated.")

    def _initiate_fungers(self) -> None:
        """
        Retrieves new funger rules, initiates a cache for fungers.
        """
        if self.env in ["UAT", "PROD"]:
            try:
                if self.env == "UAT":
                    env_folder = "uat"
                else:
                    env_folder = "prd"

                rule_folder = os.path.join(os.sep, "share", env_folder, "refdata", "imt", "sfgim", "polling")
                if not os.path.exists(rule_folder):
                    raise RuntimeError("IMT polling folder does not exist.")
                reverse_alphabetized_rules = sorted(os.listdir(rule_folder), reverse=True)
                if len(reverse_alphabetized_rules) == 0:
                    raise RuntimeError("No rules present in IMT polling folder")
                latest_rules = reverse_alphabetized_rules[0]
                current_date = datetime.strftime(self.day, "%Y%m%d")
                latest_date = datetime.strftime(self.day - timedelta(days=1), "%Y%m%d")
                if not (
                        latest_rules.startswith(f"FungibleRules__{latest_date}") or
                        latest_rules.startswith(f"FungibleRules__{current_date}")):
                    raise RuntimeError(f"No rules present in polling for EOD {current_date} or {latest_date}")

                # Copy files to done and funger folder
                latest_path = os.path.join(rule_folder, latest_rules)
                done_path = os.path.join(os.sep, "share", env_folder, "refdata", "imt", "sfgim", "done", latest_rules)
                target_path = os.path.join(os.sep, "opt", "sfgim", "aac", "tsdos", "sf_funger", "market_rules.json")
                if os.path.exists(target_path):
                    os.remove(target_path)
                shutil.copyfile(latest_path, target_path)
                os.rename(latest_path, done_path)
                self.log.info("Successfully updated funger rules")
            except Exception as e:
                self.log.error(f"Runtime Initialization Error: {e}")

        self.fungers = funger.Funger(self.equivalent_isins_dict, self.log)
        self.log.debug(f"fungers object initiated.")

    """=======================|=========|=========|====================|=========|=========|============================
    ==========================|=========|=========|=TRANSACTION CACHES=|=========|=========|============================
    ==========================|=========|=========|====================|=========|=========|========================="""
    def _initiate_transaction_caches(self) -> None:
        """
        Initiates an inventory manager object, and then loads all appropriate transactions into it.
        """
        self.inventory_manager = inventory_manager.InventoryManager(self.day, self.market_country_dictionary)
        self._initiate_transaction_cache_settled()
        self._initiate_transaction_cache_pending()
        self._initiate_transaction_cache_sbl()
        self._initiate_transaction_cache_collateral()
        self.log.debug(f"Transaction cache successfully initialized and loaded.")

    def _initiate_transaction_cache_settled(self) -> None:
        """
        Retrieves the settled OR transactions from the database and loads them into the inventory manager.
        """
        def _create_transaction_dict_settled(eod_transaction_tuple: pODBC.MicsSettledEntry) -> EodTransactionDict:
            """
            Turns the tuple returned from the database call into a dictionary with named attributes.
            :param eod_transaction_tuple: The given tuple.
            :return eod_transaction_dict: The dictionary represented by that tuple
            """
            eod_transaction_dict: EodTransactionDict = {
                'isin': eod_transaction_tuple.isin,
                'settlement_date': eod_transaction_tuple.last_movement_date,
                'currency_code': eod_transaction_tuple.currency_code_price,
                'depot_id': eod_transaction_tuple.depot_id,
                'safe_keeping_id': eod_transaction_tuple.safe_keeping_id,
                'product_group_code': eod_transaction_tuple.product_group_code,
                'client_number': eod_transaction_tuple.client_number,
                'account_type': eod_transaction_tuple.account_type,
                'account_number': eod_transaction_tuple.account_number,
                'subaccount_number': eod_transaction_tuple.subaccount_number,
                'quantity_long_prim_prod': eod_transaction_tuple.quantity_long_prim_prod,
                'quantity_short_prim_prod': eod_transaction_tuple.quantity_short_prim_prod,
                'status': "SETTLED",
                'transaction_value': eod_transaction_tuple.transaction_value
            }
            return eod_transaction_dict

        def _translate_settled_to_pending_format(settled_dic: EodTransactionDict) -> List[TransactionDictOR]:
            """
            As the End-of-day files for the settled and pending OR transactions have a slightly different structure,
            this function was used to translate the settled dictionary to the format of the pending dictionary. Settles
            Longs and Shorts are translated into Buys and Sells respectively. Because a settled position can
            include both Long and Short positions, this function is structured so that it can translate a settled
            position into two pending positions (both a buy and a sell)
            :param settled_dic: The dictionary representing a settled position

            :return returnable: The translated
            """
            returnable: List[TransactionDictOR] = []
            reformatted = {}

            """These variables have special properties, so cannot be simply be transferred from the settled structure to
            the pending structure"""
            skipped_variables = ['quantity_long_prim_prod', 'quantity_short_prim_prod']

            """Copies variables"""
            for dict_key in settled_dic:
                if dict_key not in skipped_variables:
                    reformatted[dict_key] = settled_dic.get(dict_key)

            """Handles the special variables"""
            if settled_dic['quantity_long_prim_prod'] != 0:
                reformatted_buy = {
                    **reformatted, 'buy_sell_code': 'B', 'quantity': settled_dic['quantity_long_prim_prod']}
                returnable.append(reformatted_buy)
            if settled_dic['quantity_short_prim_prod'] != 0:
                reformatted_sell = {
                    **reformatted, 'buy_sell_code': 'S', 'quantity': settled_dic['quantity_short_prim_prod']}
                returnable.append(reformatted_sell)
            return returnable

        _podbc = pODBC.DatahubConnectionService(self.env, self.eod_data_day, self.log)
        mics_s_qresult = _podbc.get_mics_settled_all()
        if not mics_s_qresult and not self.accept_empty_results:
            self._throw_loading_error("settled OR")
        for transaction in mics_s_qresult:
            settled_dict = _create_transaction_dict_settled(transaction)
            transaction_dicts = _translate_settled_to_pending_format(settled_dict)
            for transaction_dict in transaction_dicts:
                self.add_or_transaction(transaction_dict, settlement=False, intraday=False)

        self.log.debug(f"Settled MICS EOD transactions successfully initiated.")

    def _initiate_transaction_cache_pending(self) -> None:
        """
        Retrieves the pending OR transactions from the database and loads them into the inventory manager.
        """
        def _create_transaction_dict_pending(eod_transaction_tuple: pODBC.MicsPendingEntry) -> TransactionDictOR:
            """
            Turns the tuple returned from the database call into a dictionary with named attributes.
            :param eod_transaction_tuple: The given tuple.
            :return eod_transaction_dict: The dictionary represented by that tuple
            """
            eod_transaction_dict: TransactionDictOR = {
                'isin': eod_transaction_tuple.isin,
                'settlement_date': eod_transaction_tuple.settlement_date,
                'currency_code': eod_transaction_tuple.currency_code,
                'quantity': eod_transaction_tuple.quantity,
                'buy_sell_code': eod_transaction_tuple.buy_sell_code,
                'depot_id': eod_transaction_tuple.depot_id,
                'safe_keeping_id': eod_transaction_tuple.safe_keeping_id,
                'product_group_code': eod_transaction_tuple.product_group_code,
                'client_number': eod_transaction_tuple.client_number,
                'account_type': eod_transaction_tuple.account_type,
                'account_number': eod_transaction_tuple.account_number,
                'subaccount_number': eod_transaction_tuple.subaccount_number,
                'status': "PENDING",
                'transaction_value': eod_transaction_tuple.transaction_value
            }
            return eod_transaction_dict

        _podbc = pODBC.DatahubConnectionService(self.env, self.eod_data_day, self.log)
        mics_p_qresult = _podbc.get_mics_pending_all()
        if not mics_p_qresult and not self.accept_empty_results:
            self._throw_loading_error("pending OR")
        for transaction in mics_p_qresult:
            transaction_dict = _create_transaction_dict_pending(transaction)
            self.add_or_transaction(transaction_dict, settlement=False, intraday=False)
        self.log.debug(f"Pending MICS EOD transactions successfully initiated.")

    @staticmethod
    def _create_transaction_dict_sbl(eod_transaction_tuple: pODBC.FoursSBLEntry) -> TransactionDictSBL:
        """
        Turns the tuple returned from the database call into a dictionary with named attributes.
        :param eod_transaction_tuple: The given tuple.
        :return eod_transaction_dict: The dictionary represented by that tuple
        """
        eod_transaction_dict: TransactionDictSBL = {
            'ref': eod_transaction_tuple.ref,
            'trade_type': eod_transaction_tuple.trade_type,
            'value_date': eod_transaction_tuple.value_date,
            'quantity': eod_transaction_tuple.quantity,
            'status': eod_transaction_tuple.status,
            'trade_date': eod_transaction_tuple.trade_date,
            'book': {'code': eod_transaction_tuple.book_code, 'entity': eod_transaction_tuple.book_entity},
            'counterparty': {'code': eod_transaction_tuple.counterparty_code,
                             'entity': eod_transaction_tuple.counterparty_entity},
            'fee': {'rate': eod_transaction_tuple.fee_rate},
            'security': {'market_code': eod_transaction_tuple.market_code, 'isin': eod_transaction_tuple.isin},
            'settlement': {'depot': eod_transaction_tuple.settlement_depot,
                           'account': eod_transaction_tuple.settlement_account,
                           'date': eod_transaction_tuple.settlement_date},
            'termed_date': eod_transaction_tuple.termed_date,
            'collateral_margin': eod_transaction_tuple.collateral_margin,
            'calc_market_value': {
                "amount": eod_transaction_tuple.transaction_value,
                "ccy": {"code": eod_transaction_tuple.ccy_code}},
            "user": {"id": eod_transaction_tuple.trader_id}
        }
        return eod_transaction_dict

    def _initiate_transaction_cache_sbl(self) -> None:
        """
        Retrieves the sbl transactions from the database and loads them into the inventory manager.
        """

        sbl_transactions_dicts: List[TransactionDictSBL] = []
        ref_dict: Dict[str, TransactionDictSBL] = {}

        _podbc = pODBC.DatahubConnectionService(self.env, self.eod_data_day, self.log)
        sbl_qresult = _podbc.get_4s_sbl_all()
        sbl_pending_qresult = _podbc.get_4s_pending_sbl_returns_all()
        for transaction_data in sbl_qresult:
            transaction_dict = self._create_transaction_dict_sbl(transaction_data)

            ref_dict[transaction_dict['ref']] = transaction_dict
            sbl_transactions_dicts.append(transaction_dict)
        for pending_return_data in sbl_pending_qresult:
            parent_ref = pending_return_data.ref
            pending_return = {
                'ref': pending_return_data.return_ref, 'quantity': pending_return_data.quantity,
                'value_date': pending_return_data.value_date, 'recall': pending_return_data.recall,
                'trade_date': pending_return_data.trade_date}

            if ref_dict[parent_ref].get('pending_return') is None:
                ref_dict[parent_ref]['pending_return'] = []
            ref_dict[parent_ref]['pending_return'].append(pending_return)
        for sbl_transactions_dict in sbl_transactions_dicts:
            self.add_sf_contract(sbl_transactions_dict)
        if len(sbl_transactions_dicts) == 0 and not self.accept_empty_results:
            self._throw_loading_error("SBL transactions")
        self.log.debug(f"SBL EOD transactions successfully initiated. "
                       f"{len(sbl_transactions_dicts)} transactions loaded.")

    @staticmethod
    def _create_transaction_dict_collateral(eod_transaction_tuple: pODBC.FoursCollateralEntry) -> \
            TransactionDictCollateral:
        """
        Turns the tuple returned from the database call into a dictionary with named attributes.
        :param eod_transaction_tuple: The given tuple.
        :return eod_transaction_dict: The dictionary represented by that tuple
        """
        eod_transaction_dict: TransactionDictCollateral = {
            'ref': eod_transaction_tuple.ref,
            'trade_type': eod_transaction_tuple.trade_type,
            'value_date': eod_transaction_tuple.value_date,
            'quantity': eod_transaction_tuple.quantity,
            'status': eod_transaction_tuple.status,
            'trade_date': eod_transaction_tuple.trade_date,
            'book': {'code': eod_transaction_tuple.book_code, 'entity': eod_transaction_tuple.book_entity},
            'counterparty': {'code': eod_transaction_tuple.counterparty_code,
                             'entity': eod_transaction_tuple.counterparty_entity},
            'security': {'market_code': eod_transaction_tuple.market_code, 'isin': eod_transaction_tuple.isin},
            'settlement': {'depot': eod_transaction_tuple.settlement_depot,
                           'account': eod_transaction_tuple.settlement_account,
                           'date': eod_transaction_tuple.settlement_date},
            'calc_market_value': {
                "amount": eod_transaction_tuple.transaction_value,
                "ccy": {"code": eod_transaction_tuple.ccy_code}},
            "user": {"id": eod_transaction_tuple.trader_id}
        }
        return eod_transaction_dict

    def _initiate_transaction_cache_collateral(self) -> None:
        """
        Retrieves the collateral transactions from the database and loads them into the inventory manager.
        """
        collateral_transactions_dicts: List[TransactionDictCollateral] = []

        _podbc = pODBC.DatahubConnectionService(self.env, self.eod_data_day, self.log)
        collateral_qresult = _podbc.get_4s_collateral_all()
        for transaction_data in collateral_qresult:
            transaction_dict = self._create_transaction_dict_collateral(transaction_data)
            collateral_transactions_dicts.append(transaction_dict)
        for collateral_transactions_dict in collateral_transactions_dicts:
            self.add_sf_contract(collateral_transactions_dict)

        if len(collateral_transactions_dicts) == 0 and not self.accept_empty_results:
            self._throw_loading_error("collateral transactions")
        self.log.debug(f"Collateral EOD transactions successfully initiated. "
                       f"{len(collateral_transactions_dicts)} transactions loaded")

    def add_or_transaction(self, transaction_dict: TransactionDictOR, settlement=False, intraday=False) -> None:
        """
        Takes the dictionary for initiating an OR Transaction, instantiates the ORTransaction object, and adds it
        to the inventory manager. If the transaction is indicated to be a settlement, it will also remove or reduce
        the prior pending transaction as appropriate.
        :param transaction_dict: The dictionary containing the initializing values for the transaction
        :param settlement: Whether this transaction is a settlement.
        :param intraday: Whether this is an intraday transaction.
        """
        transaction = transactions.ORTransaction(
            transaction_dict,
            refdata_mnemonics=self.refdata_mnemonics,
            refdata_instruments=self.refdata_instruments,
            refdata_currencies=self.refdata_currencies,
            settlement_depot_account_dict=self.settlement_depot_account_dict,
            intraday=intraday)
        self.inventory_manager.add_transaction(transaction)
        if settlement:
            self.inventory_manager.remove_pending(transaction)

    def add_sf_contract(
            self, transaction_dict: Union[TransactionDictSBL, TransactionDictCollateral], intraday=False
    ) -> None:
        """
        Takes the dictionary for initiating an SF Contract, splits off its projected returns into distinct transactions,
        then adds the original transaction and all of the projected transactions to the inventory manager.
        :param transaction_dict: The dictionary containing the initializing values for the transaction
        :param intraday: Whether this is an intraday transaction.
        """
        contract = transactions.SFContract(
            transaction_dict,
            refdata_mnemonics=self.refdata_mnemonics,
            refdata_instruments=self.refdata_instruments,
            refdata_currencies=self.refdata_currencies,
            day=self.day,
            intraday=intraday)
        split_transaction = contract.split_projected_returns(
            refdata_mnemonics=self.refdata_mnemonics,
            refdata_instruments=self.refdata_instruments,
            refdata_currencies=self.refdata_currencies,
            day=self.day,
            intraday=intraday)

        partial_returns = False
        for contract in split_transaction:
            if contract.is_partial_return_settlement:
                partial_returns = True

        for contract in split_transaction:
            # Partial settlements are added twice, once with SETTLED status, once with PENDING. We're only looking at
            # the PENDING, where the quantity is the amount that remains.
            if contract.is_partial_settlement:
                if contract.status == "PENDING":
                    self.add_partial_settlement(contract)
            elif contract.is_partial_return_settlement:
                self.add_partial_settlement(contract, is_return=True)
            elif not partial_returns or contract.trade_type in {'BORROW RETURN', 'LOAN RETURN'}:
                self.inventory_manager.add_transaction(contract)

    def add_partial_settlement(self, contract: transactions.SFContract, is_return=False):
        base_ref = contract.ref.replace('-', '')
        self.log.debug(f"Adding partial settlement of {contract.quantity} for contract {base_ref}")
        original_transaction = self.inventory_manager.get_sf_transaction(ref_id=base_ref, isin=contract.isin)

        # Calculate proportion
        diff = original_transaction.quantity - contract.quantity
        proportion_settled = (contract.quantity / original_transaction.quantity)

        # Update values on the settlement
        original_transaction.quantity = contract.quantity
        original_transaction.value *= proportion_settled
        original_transaction.eur_value *= proportion_settled

        if is_return and diff != 0.0:
            # Also update parent transaction.
            base_ref = base_ref.split('/')[0]
            original_transaction = self.inventory_manager.get_sf_transaction(ref_id=base_ref, isin=contract.isin)

            new_quantity = original_transaction.quantity - diff
            proportion_settled = (new_quantity / original_transaction.quantity)

            # Update values on the settlement
            original_transaction.quantity = contract.quantity
            original_transaction.value *= proportion_settled
            original_transaction.eur_value *= proportion_settled

    """=============================|=========|=========|=========|=========|=========|=================================
    ================================|=========|=========|=THREADS=|=========|=========|=================================
    ================================|=========|=========|=========|=========|=========|=============================="""
    def _start_threads(self) -> None:
        """
        This function is part of the start-up process of the Live Data Caller, instantiating one instance of the various
        threads that are part of the program's functionality. If more threads are needed, the individual functions for
        each thread can be called.
        The type of threads that are instantiated depend on whether or not LiveDataCaller.live is set to True. If it is,
        it will instantiate a thread for answering requests, a thread for periodically refreshing reference data, and
        a thread for reading into the live kafka stream and updating positions accordingly.
        if LiveDataCaller.live is set to False, only the request reply thread will be instantiated.
        """
        self.add_request_thread()
        if self.live:
            self.add_kafka_thread()
        else:
            self.load_kafka_data()  # TODO get data in?

    def add_request_thread(self) -> None:
        """
        Adds and starts a single new request-handling thread.
        """
        new_request_thread = RequestThread(self, self.next_port)
        self.request_threads.append(new_request_thread)
        new_request_thread.start()
        self.next_port += 1
        self.log.debug(f"Request Thread instantiated. Current count at {len(self.request_threads)}")

    def add_kafka_thread(self) -> None:
        """
        Adds and starts a single new kafka thread.
        """
        if not self.live:
            self.log.error('LDC-ERROR-002: Cannot instantiate a kafka thread for a non-live data caller')
            return
        new_kafka_thread = KafkaThread(self)
        self.kafka_threads.append(new_kafka_thread)
        new_kafka_thread.start()
        self.log.debug(f"Kafka Thread instantiated. Current count at {len(self.kafka_threads)}")

    def _throw_loading_error(self, source: str):
        try:
            self.log.error(f"LDC-ERROR-007: The Live Data Caller could not initialize one of its data sources: "
                           f"{source}")
            raise ValueError(f"The Live Data Caller could not initialize one of its data sources: {source}. This "
                             f"could indicate an unstable or incomplete database, or an issue with the connection.")
        finally:
            self.shutdown()

    def load_kafka_data(self) -> None:
        _podbc = pODBC.DatahubConnectionService(self.env, self.eod_data_day, self.log)

        # SBL
        kafka_sbl_qresult = _podbc.get_kafka_sbl_all()
        kafka_sbl_pending_qresult = _podbc.get_kafka_pending_sbl_returns_all()
        sbl_transactions_dicts: List[TransactionDictSBL] = []
        ref_dict: Dict[str, TransactionDictSBL] = {}
        for transaction_data in kafka_sbl_qresult:
            transaction_dict_sbl = self._create_transaction_dict_sbl(transaction_data)
            ref_dict[transaction_dict_sbl['ref']] = transaction_dict_sbl
            sbl_transactions_dicts.append(transaction_dict_sbl)
        for pending_return_data in kafka_sbl_pending_qresult:
            parent_ref = pending_return_data.ref
            pending_return = {
                'ref': pending_return_data.return_ref, 'quantity': pending_return_data.quantity,
                'value_date': pending_return_data.value_date, 'recall': pending_return_data.recall
            }
            if ref_dict[parent_ref].get('pending_return') is None:
                ref_dict[parent_ref]['pending_return'] = []
            ref_dict[parent_ref]['pending_return'].append(pending_return)
        for sbl_transactions_dict in sbl_transactions_dicts:
            self.add_sf_contract(sbl_transactions_dict)

        # Collateral
        kafka_collateral_qresult = _podbc.get_kafka_collateral_all()
        collateral_transactions_dicts: List[TransactionDictCollateral] = []
        for transaction_data in kafka_collateral_qresult:
            transaction_dict_coll = self._create_transaction_dict_collateral(transaction_data)
            collateral_transactions_dicts.append(transaction_dict_coll)
        for collateral_transactions_dict in collateral_transactions_dicts:
            self.add_sf_contract(collateral_transactions_dict)

        # MICS
        kafka_con = _podbc.get_kafka_con_transaction()
        for transaction_data in kafka_con:
            if transaction_data[4] > 0:
                buy_sell_code = "B"
                quantity = transaction_data[4]
            else:
                buy_sell_code = "S"
                quantity = transaction_data[5]
            if transaction_data[12] == "TRADE":
                status = "PENDING"
            else:
                status = "SETTLED"

            transaction_dict_or: TransactionDictOR = {
                'isin': transaction_data[0], 'settlement_date': transaction_data[1],
                'currency_code': transaction_data[3],
                'quantity': quantity, 'buy_sell_code': buy_sell_code, 'depot_id': transaction_data[6],
                'safe_keeping_id': transaction_data[7], 'product_group_code': "ST",
                'client_number': transaction_data[8], 'account_type': transaction_data[11],
                'account_number': transaction_data[9], 'subaccount_number': transaction_data[10],
                'status': status,
                'transaction_value': transaction_data[2]}

            or_transaction = transactions.ORTransaction(
                transaction_dict_or,
                refdata_mnemonics=self.refdata_mnemonics,
                refdata_instruments=self.refdata_instruments,
                refdata_currencies=self.refdata_currencies,
                settlement_depot_account_dict=self.settlement_depot_account_dict, intraday=True)

            self.inventory_manager.add_transaction(or_transaction)
            if transaction_data[12] == "SETTLEMENT":
                # Removes equivalent pending items.
                self.inventory_manager.remove_pending(or_transaction)


"""===============================|=========|=========|=========|=========|=========|===================================
==================================|=========|=========|=THREADS=|=========|=========|===================================
==================================|=========|=========|=========|=========|=========|================================"""


class KafkaThread(threading.Thread):
    """
    Kafka Threads consume the information from kafka streams to maintain a live inventory. Because of the volume of
    kafka messages, multiple kafka will likely be required to run concurrently.
    """
    daemon = True
    topics = [kafka_sbl, kafka_4s, kafka_grip]

    def __init__(self, parent_data_caller: LiveDataCaller) -> None:
        super(KafkaThread, self).__init__()
        self.data_caller = parent_data_caller
        self.data_caller.log.debug("Instantiating kafka thread")
        self.consumer = self.start_up_consumer()

        self.exit_flag = threading.Event()

        # Seeking to starting timestamp
        self.start_timestamp = self.get_start_timestamp()
        self.set_consumer_to_timestamp(self.consumer, self.start_timestamp)

        # Initiate messaging alerting variables
        self.warn_limit_seconds = 180  # TODO configurable
        self.error_limit_seconds = 300  # TODO configurable
        self.message_timing_warning_active = False
        self.message_timing_error_active = False

        #
        self.startup_catchup_topics = {topic: True for topic in self.topics}
        self.startup_catchup_complete = False
        self.startup_last_message_receive = {topic: None for topic in self.topics}

    def start_up_consumer(self) -> confluent_kafka.Consumer:
        conf = {
            'group.id': f'tsdos_ldc_group_{datetime.now().strftime("%Y%m%d_%H%M")}',
            'bootstrap.servers': bootstrap_servers,
            'session.timeout.ms': 60000,
            'enable.auto.commit': False,
            'auto.offset.reset': 'earliest'}
        consumer = confluent_kafka.Consumer(conf)

        self.data_caller.log.debug("subscribing to the following topics: " + str(self.topics))
        consumer.subscribe(self.topics)
        self.data_caller.log.debug("Subscription successful, trying to poll to get assignments")
        consumer.poll(timeout=10)  # a single poll is necessary for subscriptions to get assigned.
        self.data_caller.log.debug("Polled assignment message, validating assignment...")

        # Raise errors if no assignment is present for a topic
        self._validate_topic_assignment(consumer, self.topics)
        self.data_caller.log.debug("Assignment Successful")

        self.log_oldest_available_timestamp(consumer)
        return consumer

    @staticmethod
    def _validate_topic_assignment(consumer: confluent_kafka.Consumer, topics: List[str]):
        topic_partitions = consumer.assignment()
        assigned_topic_set = {topic_partition.topic for topic_partition in topic_partitions}
        if len(assigned_topic_set) != len(topics):
            missing_topics = set()
            for topic in topics:
                if topic not in assigned_topic_set:
                    missing_topics.add(topic)

            raise RuntimeError(f"No assignments could be made for the following topics: {missing_topics}")

    @staticmethod
    def set_consumer_to_timestamp(consumer: confluent_kafka.Consumer, timestamp: int) -> None:
        topic_partitions: List[confluent_kafka.TopicPartition] = consumer.assignment()

        for topic_partition in topic_partitions:
            topic_partition.offset = timestamp

        partition_offsets: List[confluent_kafka.TopicPartition] = consumer.offsets_for_times(topic_partitions)
        for topic_partition in partition_offsets:
            consumer.seek(topic_partition)

    def run(self) -> None:
        self.data_caller.log.debug("Starting Kafka polling.")

        # General message-handling loop
        while not self.exit_flag.wait(timeout=0.0001):
            # if self.data_caller.env in ["UAT", "PROD"]:
            #     self.manual_intraday_read()   # TODO TEMP TESTING FUNCTION REMOVE
            message = self.consumer.poll(timeout=0.1)
            if message is not None:
                self.handle_message(message)

        # Shutdown
        if self in self.data_caller.kafka_threads:
            self.data_caller.kafka_threads.remove(self)

    def handle_message(self, message: Message) -> None:
        receive_now = datetime.now()
        receive_time = datetime.timestamp(receive_now)
        receive_minute = self.time_to_minute_string(receive_now)

        # Handles alerts and errors based off messaging
        self.handle_message_time_alerts(
            receive_time=receive_time, send_time=(message.timestamp()[1] / 1000), topic=message.topic())

        # Handles the message
        self.handle_message_contents(self.start_timestamp, message, receive_minute)

    def get_start_timestamp(self) -> int:
        missing_days = self.data_caller.calculate_missing_dates()
        self.data_caller.log.debug(f"Missing days: {missing_days}")
        comparison_datetime = datetime(self.data_caller.day.year, self.data_caller.day.month, self.data_caller.day.day)
        comparison_datetime -= timedelta(days=missing_days)  # TODO at what time is EoD?
        self.data_caller.log.debug(f"Comparison datetime: {comparison_datetime}")
        start_timestamp = int(datetime.timestamp(comparison_datetime) * 1000)
        return start_timestamp

    def log_oldest_available_timestamp(self, consumer: confluent_kafka.Consumer):
        """
        This checks and logs what the oldest available message is. This has no practical effects for the program,
        but is vital for debugging if something goes wrong
        """
        self.data_caller.log.debug("Checking for oldest available message on the Kafka Stream...")
        self.set_consumer_to_timestamp(consumer, confluent_kafka.OFFSET_BEGINNING)
        oldest_message = consumer.poll(timeout=60)
        if oldest_message is None and self.data_caller.env == "PROD":
            error_message = "LDC-ERROR-013: No Messages are available in the Kafka stream. Since this is the PROD " \
                            "environment, this is considered a fatal error."
            self.data_caller.log.error(error_message)
            raise RuntimeError(error_message)
        elif oldest_message is None:
            self.data_caller.log.warn(
                "No messages are available in the Kafka stream. Since this is a testing environment, this " 
                "is not considered a fatal error.")
            self.startup_catchup_topics = {topic: False for topic in self.topics}
            self.startup_catchup_complete = True
        else:
            message_timestamp_type, message_timestamp = oldest_message.timestamp()
            oldest_available_timestamp = message_timestamp
            self.data_caller.log.debug(f"The oldest available timestamp on Kafka is {oldest_available_timestamp}.")

    def handle_message_time_alerts(self, receive_time: float, send_time: float, topic: str):
        diff = receive_time - send_time

        if not self.startup_catchup_complete:
            if diff < self.warn_limit_seconds and self.startup_catchup_topics[topic]:
                self.startup_catchup_topics[topic] = False
                self.data_caller.log.debug(
                    f"Difference between kafka messages being sent and kafka messages being received on topic "
                    f"'{topic}' has fallen to {diff} seconds. Topic is no longer in start-up state.")

            for topic, last_receive_time in self.startup_last_message_receive.items():
                # If no message is received for a full minute, it's presumed that there are no recent messages on the
                # topic, so it's marked as having caught up.
                if last_receive_time is None:
                    self.startup_last_message_receive[topic] = receive_time
                elif self.startup_catchup_topics[topic]:
                    if last_receive_time + 60 < receive_time:
                        self.startup_catchup_topics[topic] = False
                        self.data_caller.log.debug(
                            f"No message has been received on topic '{topic}' for more than one minute. Topic is no "
                            f"longer in start-up state.")

            if True not in self.startup_catchup_topics.values():
                # Catchup is completed if all topics have caught up
                self.startup_catchup_complete = True
                self.data_caller.log.debug(
                    f"All topics are no longer in start-up state. Time alerting has been enabled.")

            self.startup_last_message_receive[topic] = receive_time
        elif diff > self.error_limit_seconds:
            if not self.message_timing_error_active:
                self.message_timing_error_active = True
                self.message_timing_warning_active = False
                self.data_caller.log.error(
                    f"LDC-ERROR-014: Difference between kafka messages being sent and kafka messages being received is "
                    f"at {diff} seconds")
        elif diff > self.warn_limit_seconds:
            if not self.message_timing_warning_active:
                self.message_timing_error_active = False
                self.message_timing_warning_active = True
                self.data_caller.log.warn(
                    f"WARNING: Difference between kafka messages being sent and kafka messages being received is at "
                    f"{diff} seconds")
        elif self.message_timing_error_active or self.message_timing_warning_active:
            self.message_timing_warning_active = False
            self.message_timing_error_active = False
            self.data_caller.log.debug(
                f"Difference between kafka messages being sent and kafka messages being received has fallen to {diff} "
                f"seconds. Kafka thread no longer in critical state.")

    def manual_intraday_read(self):
        """"
        TODO This is a testing function, added to test intraday additions to the ladder.
        """
        def replace_date(date_str):
            t_split = date_str.split("+")
            if t_split[0] == "T" and len(t_split) == 1:
                reply_date = datetime.today()
            elif t_split[0] == "T" and len(t_split) == 2:
                reply_date = datetime.today() + timedelta(days=int(t_split[1]))
            else:
                reply_date = datetime.strptime(date_str, "%Y%m%d")
            return reply_date

        while len(os.listdir(os.path.join(file_dir, 'polling'))) > 0:
            json_file_name = os.listdir(os.path.join(file_dir, 'polling'))[0]
            json_file_path = os.path.join(file_dir, 'polling', json_file_name)

            with open(json_file_path) as json_file:
                transaction_str = json_file.read()
                transaction_dicts = json.loads(transaction_str)

            for transaction_dict in transaction_dicts:
                if transaction_dict.get('trade_type'):
                    transaction_dict['value_date'] = replace_date(transaction_dict['value_date']).strftime("%Y%m%d")
                    transaction_dict['termed_date'] = replace_date(transaction_dict['termed_date']).strftime("%Y%m%d")
                    self.data_caller.add_sf_contract(transaction_dict, intraday=True)
                elif transaction_dict.get("buy_sell_code"):
                    transaction_dict['settlement_date'] = replace_date(transaction_dict['settlement_date'])
                    is_settlement = transaction_dict['transaction_type'] == "SETTLEMENT"
                    self.data_caller.add_or_transaction(transaction_dict, intraday=True, settlement=is_settlement)

            file_path, file_name = os.path.split(json_file_path)
            new_path_name = os.path.join(os.path.split(file_path)[0], "done", file_name)
            shutil.move(json_file_path, new_path_name)
            time.sleep(0.2)

    def handle_message_contents(self, comparison_date: float, message: Message, receive_minute: str) -> None:
        """
        Interprets a single message received over the Kafka stream
        :param comparison_date: The starting timestamp of the data caller's date. Used to see whether a transaction is
        from that day.
        :param receive_minute: Minute message was received, in string form, for logging purposes.
        :param message: The message to be interpreted.
        :return:
        """
        message_timestamp_type, message_timestamp = message.timestamp()
        if message_timestamp_type == confluent_kafka.TIMESTAMP_NOT_AVAILABLE:
            self.data_caller.log.warn(f"Encountered Kafka message with unavailable timestamp on '{message.topic()}'.")
            return
        elif message_timestamp < 0:
            self.data_caller.log.warn(f"Encountered Kafka message with invalid timestamp '{message_timestamp}' on "
                                      f"'{message.topic()}'.")
            return
        elif message_timestamp_type == confluent_kafka.TIMESTAMP_LOG_APPEND_TIME:
            self.data_caller.log.warn(f"Encountered Kafka message with log append timestamp.")

        message_topic = message.topic()

        if comparison_date > message_timestamp:
            self.data_caller.kafka_outdated_count[message_topic] += 1

            message_date_obj = datetime.fromtimestamp(message_timestamp / 1000)
            self.data_caller.kafka_outdated_dates[message_topic].add(message_date_obj.strftime("%Y%m%d"))
            return
        else:
            self.data_caller.kafka_message_counter[message_topic] += 1
            message_value = message.value()

            if message_timestamp > self.data_caller.kafka_last_message_time[message_topic]:
                self.data_caller.kafka_last_message_time[message_topic] = message_timestamp
            if len(self.data_caller.kafka_last_messages[message_topic]) > 4:  # TODO make configurable
                self.data_caller.kafka_last_messages[message_topic].pop(0)
            self.data_caller.kafka_last_messages[message_topic].append(message_value)
            try:
                if message_topic == kafka_grip:
                    self._parse_grip_transaction(message_value, receive_minute)
                else:
                    values = self._extract_sbl_message_values(message_value)
                    for value in values:
                        self.data_caller.kafka_transaction_counter[receive_minute][message_topic] += 1
                        self.data_caller.add_sf_contract(value, intraday=True)
            except Exception as e:
                self.data_caller.log.error(f'LDC-ERROR-004 Error encountered during consumption of kafka stream: {e}')

    def _parse_grip_transaction(self, message_str: str, receive_minute: str) -> None:
        """
        Parses the value of a single GRIP message received over the KAFKA stream, turning it into OR transactions.
        :param message_str: A string containing a kafka message, which describes one or more OR transactions
        :param receive_minute: Minute message was received, in string form, for logging purposes.
        """
        message: dict = eval(message_str)
        for con_transaction in message['v:MsgConTransaction']['Body']['ConTransaction']:
            region = con_transaction['CanTransaction']['vMessageIDs']['SourceMessageSequenceGroup']
            self.data_caller.kafka_transaction_counter[receive_minute][region] += 1
            try:
                transaction_type = con_transaction['CanTransaction'].get('TransactionType')

                or_transaction = None
                if transaction_type == "TRADE":
                    or_transaction = self._grip_message_to_transaction(con_transaction, status="PENDING")
                elif transaction_type == "SETTLEMENT":
                    or_transaction = self._grip_message_to_transaction(con_transaction, status="SETTLED")

                if or_transaction:
                    self.data_caller.inventory_manager.add_transaction(or_transaction)
                    if transaction_type == "SETTLEMENT":
                        # Removes equivalent pending items.
                        self.data_caller.inventory_manager.remove_pending(or_transaction)

            except Exception as e:
                self.data_caller.log.error(
                    f'LDC-ERROR-005 - Error encountered during handling of Kafka Con message: {e}')

    def _grip_message_to_transaction(
            self, con_transaction: dict, status: str
    ) -> Optional[transactions.ORTransaction]:
        """Finds ISIN or escapes"""
        if (
                con_transaction['CanTransaction']['Investment'].get('GlobalInstrumentID') and
                con_transaction['CanTransaction']['Investment']['GlobalInstrumentID']['InstrumentIDType'] == "ISIN"
        ):
            isin = con_transaction['CanTransaction']['Investment']['GlobalInstrumentID']['InstrumentIDValue']
        else:
            return

        """Finds settlement date"""
        settlement_date = datetime.strptime(con_transaction['CanTransaction']['ContractualSettlementDate'], "%Y-%m-%d")

        """Finds value currency code and value"""
        transaction_value = con_transaction['CanTrade']['TradeValue']['Primary']['Value']
        currency_code = con_transaction['CanTrade']['TradeValue']['Primary']['Currency']

        """Finds quantity and buy_sell_code or continues"""
        if con_transaction['CanTransaction'].get('QuantityLong') is not None:
            quantity = float(con_transaction['CanTransaction']['QuantityLong'])
            buy_sell_code = "B"
        elif con_transaction['CanTransaction'].get('QuantityShort') is not None:
            quantity = float(con_transaction['CanTransaction']['QuantityShort'])
            buy_sell_code = "S"
        else:
            return

        """Depot ID and Safe Keeping ID"""
        depot_id = con_transaction['CanTransaction']["Party"]['PlaceOfSafekeeping']['PartyID']
        safe_keeping_id = con_transaction['CanTransaction']["Party"]['PlaceOfSafekeeping']['PartyCountry']

        """Product Group Code"""
        product_group_code = "ST"

        """Client"""
        client_number = int(con_transaction['CanTransaction']['ClientAccInfo']['ClientLevel1'])
        account_type: str = con_transaction['CanTransaction']['ClientAccInfo']['ClientLevel2']
        account_number = int(con_transaction['CanTransaction']['ClientAccInfo']['ClientLevel3'])
        subaccount_number = int(con_transaction['CanTransaction']['ClientAccInfo']['Account'])

        """Creates a settled transaction of the appropriate amount."""
        transaction_dict: TransactionDictOR = {
            'isin': isin, 'settlement_date': settlement_date, 'currency_code': currency_code,
            'quantity': quantity, 'buy_sell_code': buy_sell_code, 'depot_id': depot_id,
            'safe_keeping_id': safe_keeping_id, 'product_group_code': product_group_code,
            'client_number': client_number, 'account_type': account_type, 'account_number': account_number,
            'subaccount_number': subaccount_number, 'status': status,
            'transaction_value': transaction_value
        }
        or_transaction = transactions.ORTransaction(
            transaction_dict,
            refdata_mnemonics=self.data_caller.refdata_mnemonics,
            refdata_instruments=self.data_caller.refdata_instruments,
            refdata_currencies=self.data_caller.refdata_currencies,
            settlement_depot_account_dict=self.data_caller.settlement_depot_account_dict,
            intraday=True)
        return or_transaction

    @staticmethod
    def _extract_sbl_message_values(message_value: bytes) -> List[TransactionDictSBL]:
        """
        Extracts the values from a given SBL message value sent over the KAFKA stream.
        :param message_value: the given message value
        :return: A list of dicts, representing the values that make up SBL transactions.
        """
        values = []

        message_packet: str = message_value.decode("utf-8")
        components = message_packet.split("\n")
        for component in components:
            component.replace('\'', '\"')
            value = convert_to_python(json.loads(component))
            values.append(value)
        return values

    @staticmethod
    def time_to_minute_string(input_time: datetime) -> str:
        return "{:0>2}-{:0>2}-{:0>2} {:0>2}:{:0>2}".format(
                input_time.year, input_time.month, input_time.day, input_time.hour, input_time.minute)


class RequestThread(threading.Thread):
    """
    Request Threads reply to requests for the LiveDataCaller's data.
    """
    daemon = True

    def __init__(self, parent_data_caller: LiveDataCaller, port: int) -> None:
        """
        :param parent_data_caller: The parent data caller object
        :param port: The port through which this thread receives requests for data
        """
        super(RequestThread, self).__init__()

        self.running = False
        self.data_caller: LiveDataCaller = parent_data_caller
        self.data_caller.log.debug("Instantiating request thread")

        self.port = port
        address = ('localhost', port)
        self.listener = multiprocessing.connection.Listener(address)

    def run(self) -> None:
        """
        While running, the Request Thread will continually receive messages, and read them one-by-one. Every message
        must be a dictionary with the "type" attribute, which is used to differentiate between different types of data
        requests.
        """
        self.running = True
        while self.running:
            try:
                self.data_caller.clear_port(self.port)
                conn = self.listener.accept()
                message = conn.recv()
                try:
                    if message['type'] == "refdata":
                        reply = self._reply_to_refdata_request(message)
                    elif message['type'] == "static":
                        reply = self._reply_to_static_request(message)
                    elif message['type'] == "transactions":
                        reply = self._reply_to_transaction_request(message)
                    elif message['type'] == "external_borrows":
                        reply = self._reply_to_external_borrows_request(message)
                    elif message['type'] == "isins_per_country":
                        reply = self._reply_to_isins_per_country_request(message)
                    elif message['type'] == "aggregate_inventory":
                        reply = self._reply_to_aggregate_inventory_request(message)
                    elif message['type'] == "generate_report":
                        reply = self._reply_to_report_request(message)
                    elif message['type'] == "kafka_diagnostics":
                        reply = self._reply_to_kafka_diagnosis_request()
                    elif message['type'] == "add_instrument":
                        reply = self._reply_to_instrument_addition_request(message)
                    elif message['type'] == "shutdown":
                        self.running = False
                        reply = "Shut down complete"
                    else:
                        reply = f"Function {message['type']} not available"
                except Exception as e:
                    self.data_caller.log.error(
                        f'LDC-ERROR-006: Data Caller encountered error {e} while replying to request {message}.')
                    reply = e
                conn.send(reply)
                conn.close()
            except ConnectionResetError or EOFError:
                self.data_caller.log.warn(f"Request Thread encountered connection reset error while running.")

        # shutdown
        self.listener.close()
        if self in self.data_caller.request_threads:
            self.data_caller.request_threads.remove(self)

    def _reply_to_refdata_request(self, message: RequestDictRefdata) -> \
            Union[Instruments, CurrencyData, Mnemonics, Clients, MarketIndexes]:
        """
        Generating a reply to a request for reference information.
        :param message: The message to which is being replied. Must contain a 'cache' key that identifies the name of
        the desired reference data cache.
        :return reply: the requested refdata cache
        """
        if message['cache'] == 'instruments':
            reply = self.data_caller.refdata_instruments
        elif message['cache'] == 'mnemonics':
            reply = self.data_caller.refdata_mnemonics
        elif message['cache'] == 'market_indexes':
            reply = self.data_caller.refdata_market_indexes
        elif message['cache'] == 'currencies':
            reply = self.data_caller.refdata_currencies
        elif message['cache'] == 'clients':
            reply = self.data_caller.refdata_clients
        elif message['cache'] == 'ref_rates':
            reply = self.data_caller.refdata_reference_rates
        else:
            raise RuntimeError(f'{message["cache"]} is not a recognized form of refdata cache')
        return reply

    def _reply_to_static_request(self, message: RequestDictStatic) -> Union[Dict[str, str], Set[str], str]:
        """
        Generating a reply to a request for static data.
        :param message: The message to which is being replied. Must contain a 'cache' key that identifies the name of
        the desired reference cache.
        :return reply: the requested static cache
        """
        if message['cache'] == "known_countries":
            reply = self.data_caller.known_countries
        elif message['cache'] == "equivalent_isins_dict":
            reply = self.data_caller.equivalent_isins_dict
        else:
            reply = "Cache not found"
        return reply

    def _reply_to_transaction_request(self, message: RequestDictTransaction) -> List[Union[ORTransaction, SFContract]]:
        """
        Generating a reply to a request for a list of transactions.
        :param message: The request. Must contain an 'isins' key that identifies a list of isins for which to retrieve
        transactions and a 'clients' list that identifies a list of clients for which to retrieve the transactions.
        One of these must have a value of None, while the other must not..
        :return reply: the requested list of transactions
        """
        isins = message['isins']
        clients = message['clients']
        counterparties = message['counterparties']
        if isins is not None:
            isin_transactions = []
            for isin in isins:
                isin_transactions += self.data_caller.inventory_manager.get_transactions(isin=isin)
            reply = isin_transactions
        elif clients is not None:
            client_transactions = []
            for client in clients:
                client_transactions += self.data_caller.inventory_manager.get_transactions(client=client)
            reply = client_transactions
        elif counterparties is not None:
            counterparty_transactions = []
            for counterparty in counterparties:
                counterparty_transactions += self.data_caller.inventory_manager.get_transactions(
                    counterparty=counterparty)
            reply = counterparty_transactions
        else:
            reply = ValueError("Error: Cannot retrieve transactions unless at least one isin or client is passed "
                               "along.")
        return reply

    def _reply_to_external_borrows_request(self, message: RequestDictExternalBorrows) -> List[SFContract]:
        """
        Generating a reply to a request for a list of external initial_sbl_contract.
        :param message: The request. Must contain an 'isin' key that identifies a list of isins for to retrieve
        external initial_sbl_contract, and a 'countries' key which identifies a list that will be used to filter the
        external initial_sbl_contract.
        :return reply: the requested list of external initial_sbl_contract
        """
        isin = message['isin']
        countries = message['countries']
        reply = self.data_caller.inventory_manager.get_external_borrows(isin=isin, countries=countries)
        return reply

    def _reply_to_isins_per_country_request(self, message: RequestDictIsinsPerCountry) -> List[str]:
        """
        Generating a reply to a request for a list of isins active in certain countries.
        :param message: The request. must contain a 'countries' key that identifies the list of countries for which to
        retrieve isins.
        :return reply: the requested list of isins active in the specified countries
        """
        countries = message['countries']
        isin_set = OrderedDict()  # Used to replicate ordered set
        for country in countries:
            if self.data_caller.isins_per_country.get(country) is not None:
                for isin in self.data_caller.isins_per_country[country]:
                    isin_set[isin] = None
        reply = list(isin_set.keys())
        return reply

    def _reply_to_aggregate_inventory_request(self, message: RequestDictAggregateInventory) -> AggregateInventoryDict:
        """
        Generating a reply to a request for a list of isins active in certain countries.
        :param message: The request. Must contain 'projected_days', 'view', 'aggregate_order', 'position_aggregation',
        'funge', 'isin', 'client', 'market', 'country', 'report_generation' and 'report_folder' keys that identify the
        various values to pass along to the functions.
        :return reply: returns the requested aggregate inventory
        """
        projected_days = message['projected_days']

        view = message['view']
        aggregate_order = message['aggregate_order']
        funge = message['funge']
        isin = message['isin']
        counterparty = message['counterparty']
        client = message['client']

        reply = self.data_caller.inventory_processor.get_aggregate_inventory(
            projected_days=projected_days, view=view, aggregate_order=aggregate_order, funge=funge, isin=isin,
            counterparty=counterparty, client=client)

        return reply

    def _reply_to_report_request(self, message: MessageDict) -> str:
        """
        Generating a report following a request for this
        :param message: The request. Must contain a report_folder key that identifies the folder to which to output
        the report, and an 'isin' key for which to output the data.
        :return reply: returns a confirmation that the report has been generated
        """
        output_folder = message['report_folder']

        if not os.path.exists(os.path.abspath(os.path.join(output_folder, "input"))):
            os.mkdir(os.path.abspath(os.path.join(output_folder, "input")))

        """Copy market rules"""
        origin = os.path.abspath(os.path.join(file_dir, "..", "sf_funger", "market_rules.json"))
        target = os.path.abspath(os.path.join(output_folder, "input", "market_rules.json"))
        shutil.copyfile(origin, target)

        """Copy client data"""
        origin = os.path.abspath(os.path.join(file_dir, "..", "sf_common", "Client - Holding.csv"))
        target = os.path.abspath(os.path.join(output_folder, "input", "Client - Holding.csv"))
        shutil.copyfile(origin, target)

        if self.data_caller.settlement_depot_account_dict is not None:
            grip = []
            for key in self.data_caller.settlement_depot_account_dict:
                value = self.data_caller.settlement_depot_account_dict[key]
                grip.append({
                    "depot_id": key[0],
                    "safekeep": key[1],
                    "market_country": value["market_country"],
                    "depot": value["depot"],
                    "account": value["account"]
                })
            target = os.path.join(output_folder, "input", "grip_source.json")
            with open(target, "w") as json_file:
                json.dump(grip, json_file)

        reply = "Report Generated"
        return reply

    def _reply_to_kafka_diagnosis_request(self) -> Dict[str, dict]:
        """
        Provides information on the current state of the kafka streams.
        :return reply: A dictionary describing the information on the current state of the kafka stream.
        """
        reply = {
            'outdated_message_count': dict(self.data_caller.kafka_outdated_count),
            'outdated_dates': dict(self.data_caller.kafka_outdated_dates),
            'message_count': dict(self.data_caller.kafka_message_counter),
            'transaction_count': {x: dict(y) for x, y in self.data_caller.kafka_transaction_counter.items()},
            'last_timestamp': dict(self.data_caller.kafka_last_message_time),
            'last_messages': dict(self.data_caller.kafka_last_messages)
        }
        return reply

    def _reply_to_instrument_addition_request(self, message) -> str:
        new_instrument = message['instrument']

        self.data_caller.reference_caches['instruments']['cache']._populate_instrument_data(  # noqa temp code
                        new_instrument)

        return "instrument added"


"""==============================|=========|=========|===========|=========|=========|==================================
=================================|=========|=========|=INTERFACE=|=========|=========|==================================
=================================|=========|=========|===========|=========|=========|==============================="""


def get_refdata_instrs(target_address=LiveDataCaller.default_address) -> Instruments:
    """
    Requests the current reference data for instruments.
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return: The current reference data for instruments.
    """
    return _request_data({'type': 'refdata', 'cache': 'instruments'}, target_address)


def get_refdata_mnemonics(target_address=LiveDataCaller.default_address) -> Mnemonics:
    """
    Requests the current reference data for mnemonics.
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return: The current reference data for mnemonics.
    """
    return _request_data({'type': 'refdata', 'cache': 'mnemonics'}, target_address)


def get_refdata_clients(target_address=LiveDataCaller.default_address) -> Clients:
    """
    Requests the current reference data for clients.
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return: The current reference data for clients.
    """
    return _request_data({'type': 'refdata', 'cache': 'clients'}, target_address)


def get_refdata_market_indexes(target_address=LiveDataCaller.default_address) -> MarketIndexes:
    """
    Requests the current reference data for market indexes.
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return: The current reference data for market indexes.
    """
    return _request_data({'type': 'refdata', 'cache': 'market_indexes'}, target_address)


def get_refdata_currencies(target_address=LiveDataCaller.default_address) -> CurrencyData:
    """
    Requests the current reference data for currencies.
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return: The current reference data for currencies.
    """
    return _request_data({'type': 'refdata', 'cache': 'currencies'}, target_address)


def get_refdata_ref_rates(target_address=LiveDataCaller.default_address) -> ReferenceRates:
    """
    Requests the current reference data for currencies.
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return: The current reference data for currencies.
    """
    return _request_data({'type': 'refdata', 'cache': 'ref_rates'}, target_address)


def get_all_countries(target_address=LiveDataCaller.default_address) -> Set[str]:
    """
    Request the set of all known countries.
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return: the set of all known countries.
    """
    return _request_data({'type': 'static', 'cache': "known_countries"}, target_address)


def get_transactions(
        isin: Optional[Union[str, List[str]]] = None, client: Optional[Union[int, List[int]]] = None,
        counterparty: Optional[Union[Tuple[str, str], List[Tuple[str, str]]]] = None,
        target_address=LiveDataCaller.default_address
) -> List[Union[SFContract, ORTransaction]]:
    """
    Requests the list of transactions for either the given isin/list of isins, the given client/list of clients, or the
    given counterparty/list of counterparties. Can only select for one of these per request.
    :param isin: the given isin or list of isins
    :param client: the given client or list of clients
    :param counterparty: the given counterparty or list of counterparties
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return: The list of transactions for the given isin/list of isins or the given client/list of clients
    """
    if isin is not None and type(isin) is not list:
        isin = [isin]
    if client is not None and type(client) is not list:
        client = [client]
    if counterparty is not None and type(counterparty) is not list:
        counterparty = [counterparty]
    return _request_data({'type': 'transactions', 'isins': isin, 'clients': client, 'counterparties': counterparty},
                         target_address)


def get_external_borrows(
        isin: Optional[Union[str, List[str]]], countries: List[str],
        target_address=LiveDataCaller.default_address
) -> List[SFContract]:
    """
    Retrieves the external borrow for the given ISIN, in the given list of countries
    :param isin: the given ISIN
    :param countries: the given list of countries
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return external_borrows: The list of external initial_sbl_contract for the given ISIN"""
    if isin is not None and type(isin) is not list:
        isin = [isin]
    return _request_data({'type': 'external_borrows', 'isin': isin, 'countries': countries}, target_address)


def get_isins_for_country(country: Union[str, List[str]], target_address=LiveDataCaller.default_address) -> List[str]:
    """
    Requests a list of isins active in the given country or list of countries.
    :param country: The given country or list of countries.
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return: The list of isins active in the given country or list of countries
    """
    if type(country) is not list:
        country = [country]
    return _request_data({'type': 'isins_per_country', 'countries': country}, target_address)


def get_equivalent_isins_dict(target_address=LiveDataCaller.default_address) -> Dict[str, str]:
    """
    Requests a dictionary of "equivalent isins". These are distinct ISIN identifications that point to the exact same
    underlying product, so which can be used to cover one another. Keys are the original isins, values are the
    equivalent isins.
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return: Returns the the dictionary representing equivalent isins.
    """
    return _request_data({'type': 'static', 'cache': 'equivalent_isins_dict'}, target_address)


def get_kafka_diagnostics(target_address=LiveDataCaller.default_address) -> Dict[str, dict]:
    """
    Requests a dictionary of kafka diagnostics data.
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return: Returns a dictionary of kafka diagnostics data.
    """
    return _request_data({"type": "kafka_diagnostics"}, target_address)


def get_aggregate_inventory(
        projected_days: int,
        view: inventory_processing.ViewDict,
        aggregate_order: List[str],
        position_aggregation: str = "depot_account",  # TODO deprecate
        funge: bool = False,
        isin: Optional[Union[str, List[str]]] = None,
        client: Optional[Union[int, List[int]]] = None,
        counterparty: Optional[Union[Tuple[str, str], List[Tuple[str, str]]]] = None,
        report_generation: bool = False,  # TODO deprecate?
        report_folder: Optional[str] = None,  # TODO deprecate?
        target_address=LiveDataCaller.default_address
) -> AggregateInventoryDict:
    """
    Requests an inventory aggregated by the specified aggregation measure
    :param projected_days: The number of days for which to return projected inventories
    :param view: A dictionary used to specify further restrictions and filtering on the retrieved inventory. The
    'default' view takes the form of {"flags": []}.
    :param aggregate_order: A list representing the order of variables on which to aggregate the inventory. The
    aggregated inventory will have a depth equal to the length of the aggregate_order list, with each level
    representing a variable specified in aggregate_order.
    :param position_aggregation: aggregating the positions on depot_account or market_country_code
    :param funge: A boolean whether to funge the inventory. Funging requires the last two values in aggregate order
    to be 'isin' and 'country', otherwise it is not applicable.
    :param isin: a list containing the ISINs for which to get the inventory
    :param client: a list containing the client IDs for which to get the inventory
    :param counterparty: a list containing the counterparty IDs for which to get the inventory
    :param report_generation: a boolean on whether to generate a report in addition to the regular output. The report
    contains the contents of the data_caller at the time of running (except for instruments, which is reduced to
    only the relevant ISINs), as well as the inventory generated by this function.
    :param report_folder: The folder to which to output the report
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return: aggregate_inventory: An array of dictionaries, each representing a position.
    """
    if isin is not None and type(isin) is not list:
        isin = [isin]
    if client is not None and type(client) is not list:
        client = [client]
    if counterparty is not None and type(counterparty) is not list:
        counterparty = [counterparty]
    inv = _request_data({'type': 'aggregate_inventory', 'projected_days': projected_days, 'view': view,
                         'aggregate_order': aggregate_order, 'position_aggregation': position_aggregation,
                         'funge': funge, 'isin': isin, 'client': client, 'counterparty': counterparty,
                         'report_generation': report_generation, 'report_folder': report_folder},
                        target_address)
    return inv


def generate_report(report_folder: str, isin: Optional[Union[str, List[str]]] = None,
                    target_address=LiveDataCaller.default_address) -> None:
    """
    Requesting the data caller to write-to-file a copy of the current reference and static data. Limits the data to the
    given isin if one is provided.
    :param report_folder: The folder to which to the write the report files
    :param isin: Limits the data to the given isin(s) if one or more is provided
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    """
    if isin is not None and type(isin) is not list:
        isin = [isin]
    _request_data({'type': 'generate_report', 'report_folder': report_folder, 'isin': isin}, target_address)


def add_instrument(new_instrument: Instrument, target_address=LiveDataCaller.default_address):
    """
    Adds the given instrument to the data caller.
    :param new_instrument: The instrument to be added.
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return:
    """
    _request_data({'type': 'add_instrument', 'instrument': new_instrument}, target_address)


def is_running() -> bool:
    """
    Returns True if the Live Data Caller has an instance running."""
    live_data_caller_running = False

    try:
        address = LiveDataCaller.default_address
        client = multiprocessing.connection.Client(address)
        client.send("echo")
        reply = client.recv()
        if reply == "echo":
            live_data_caller_running = True
    except Exception as e:
        print(f"live_data_caller has run into exception {e} and will now attempt to shut down.")
        live_data_caller_running = False

    return live_data_caller_running


def _request_data(message: Dict, target_address=LiveDataCaller.default_address) -> Any:
    """
    This function serves as the bridge between the API functions and the Live Data Caller. It places the given message
    on the pipeline of an available request thread, and waits for the thread to provide a reply to that message,
    returning it.
    :param message: The given message.
    :param target_address: The address for the Live Data Caller. Default value is the the standard address for the live
    data caller.
    :return: The reply to the given message.
    """
    request_port = None
    while request_port is None:
        address = target_address
        client = multiprocessing.connection.Client(address)
        try:
            client.send("port_request")
            request_port = client.recv()
        except (ConnectionRefusedError, ConnectionError, EOFError):
            request_port = None
        client.close()

    reply = None
    while reply is None:
        address = ('localhost', request_port)
        client = multiprocessing.connection.Client(address)
        client.send(message)
        reply = client.recv()
        client.close()

    if issubclass(type(reply), Exception):
        raise RuntimeError(f"Live Data Caller encountered error {reply} while replying to request {message}")

    return reply


def shutdown(this_data_caller=None) -> None:
    if this_data_caller is None:
        address = LiveDataCaller.default_address
    else:
        address = this_data_caller.address
    client = multiprocessing.connection.Client(address)
    client.send("shutdown")
    client.close()
    if this_data_caller is not None:
        while not this_data_caller.shutdown_complete:
            time.sleep(0.1)
    else:
        while active_live_data_caller is not None:
            time.sleep(0.1)


def main():
    current_env = env_detect()

    # Argument Parser
    parser = argparse.ArgumentParser(description="Starts the Live Data Caller")
    parser.add_argument(
        "-d", dest="date", type=str, default=datetime.today().strftime("%Y-%m-%d %H:%M:%S"),
        help="The date for which the live data caller should load data.")
    parser.add_argument(
        "-l", dest="live", type=str, default="True",
        help="Whether the live data caller should run live data.")
    args = parser.parse_args()

    # Argument value check
    run_date = datetime.strptime(args.date, "%Y-%m-%d %H:%M:%S")

    live = convert_to_bool(args.live)

    if live and (datetime.strptime(args.date, "%Y-%m-%d %H:%M:%S").date() != datetime.now().date()):
        raise ValueError("Cannot initiate a data caller with live data for past dates. Restart the live"
                         "data caller with live value set to False.")

    if not os.path.exists(os.path.join(file_dir, 'polling')):
        os.mkdir(os.path.join(file_dir, 'polling'))
    if not os.path.exists(os.path.join(file_dir, 'done')):
        os.mkdir(os.path.join(file_dir, 'done'))

    # Run live data caller
    if current_env == "DEV":  # TODO remove once GRIP is available
        original_grip_config = pODBC_GRIP.config
        pODBC_GRIP.config = {
            'GRIP DEV': {'src': 'DRIVER={Oracle in instantclient_19_5};DBQ=aactex03-test-scan.windmill.local:1521/I3UGU1_HA;UID=VOYR_PYTHOND_USR;PWD=Exwp*N[70Af3;SSL=1'},
            'old_config DEV': {'enabled': "True"}}
    data_caller = LiveDataCaller(current_env, run_date, live)
    data_caller.start()
    if current_env == "DEV":  # TODO remove once GRIP is available
        while not (data_caller.startup_complete or data_caller.shutdown_complete):
            time.sleep(0.1)

        pODBC_GRIP.config = original_grip_config  # noqa


if __name__ == "__main__":
    main()
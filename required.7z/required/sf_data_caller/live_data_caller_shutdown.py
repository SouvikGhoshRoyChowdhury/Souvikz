import live_data_caller

from aac.tsdos.sf_common.util import Logger
from aac.tsdos.sf_common.common_functions import env_detect


def live_data_caller_shutdown() -> None:
    log = Logger('tsdos.ldc', env=env_detect())
    try:
        live_data_caller.shutdown()
        log.debug("Live Data Caller succesfully shut down")
    except SystemExit:
        log.debug("Live Data Caller succesfully shut down")
    except ConnectionRefusedError:
        log.debug("No data caller could be given a shutdown command. Likely, no data caller is running.")


if __name__ == "__main__":
    live_data_caller_shutdown()

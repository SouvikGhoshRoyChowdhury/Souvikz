import os
import json

import requests
import configparser
from flask import Flask, Response, request

from aac.tsdos.sf_common.common_functions import env_detect
from aac.tsdos.sf_common.util import Logger

from aac.tsdos.sf_data_caller.live_data_caller_api_typing import(
    LDCAPIConfigPayload,
    LDCAPIConfig,
    LDCAPIConfigSection,
    LDCAPIConfigOption,
)
from aac.tsdos.sf_common.auth import (
    AUTH_URL_PROD,
    AUTH_URL_UAT
)

tsdos_api = Flask(__name__)
api_log = Logger('invmgr.live_data_caller', env_detect())


def authenticate_token(request_headers):
    iv_user = request_headers.get('iv-user')
    wp_authorization = request_headers.get('wp-authorization')
    api_log.debug(f"Received request from {iv_user}.")

    env = env_detect()
    verify = '/etc/ssl/certs/ca-bundle.crt' if env != 'DEV' else False
    auth_url = AUTH_URL_PROD if env == "PROD" else AUTH_URL_UAT

    token_reply = requests.get(
        url=auth_url,
        headers={
            'Content-Type': 'application/x-www-form-urlencoded',
            'cache-control': 'no-cache',
            'iv-user': iv_user,
            'wp-authorization': wp_authorization},
        verify=verify)
    token_reply_json: dict = token_reply.json()
    token_status_code = token_reply_json['status']
    token_message = token_reply_json.get('message')
    token_data = token_reply_json.get('data')

    return token_status_code, token_message, token_data


def build_cors_preflight_response() -> Response:
    api_log.debug("Replying to pre-flight request")
    preflight_response = Response()
    preflight_response.headers.add("Access-Control-Allow-Origin", "*")
    preflight_response.headers.add('Access-Control-Allow-Headers', "*")
    preflight_response.headers.add('Access-Control-Allow-Methods', "*")
    return preflight_response


@tsdos_api.route('/status/config/', methods=['GET', 'OPTIONS'], strict_slashes=False)
def get_config() -> Response:
    if request.method == "OPTIONS":
        return build_cors_preflight_response()
    request_headers = request.headers
    token_status_code, token_message, token_data = authenticate_token(request_headers)

    if token_status_code == 200:
        # Config data is env-sensitive
        env = env_detect()

        # Load config data
        config = configparser.ConfigParser()
        config.read(os.path.join(os.path.dirname(__file__), '..', 'sf_config', 'sf_data_caller_config', 'env.cfg'))
        use_prd_alternatives = config["IMPALA " + env]['use_prd_alternatives']
        accept_empty_results = config["IMPALA " + env]['accept_empty_results']

        # Put the data in a dict
        reply_dict = LDCAPIConfigPayload(
            config_section=[
                LDCAPIConfigSection(
                    name="Database Settings",
                    option=[
                        LDCAPIConfigOption(
                            name="use_prd_alternatives",
                            value=use_prd_alternatives,
                            description="If True, will look at the Production-copy tables. If False, will look at the "
                                        "true UAT tables"),
                        LDCAPIConfigOption(
                            name="accept_empty_results",
                            value=accept_empty_results,
                            description="If True, will prevent TSDOS from looking at older entries or raising errors "
                                        "if data is not present for a day.")])])
        # Put the dict in a message
        return_message = LDCAPIConfig(okay=False, data=reply_dict, message=token_message)
    else:
        api_log.debug(f"Received request with invalid token on unknown environment")
        return_message = LDCAPIConfig(okay=False, data=LDCAPIConfigPayload(config_section=[]), message=token_message)

    mddr_response = Response(
        json.dumps(return_message),
        status=token_status_code,
        headers={
            'Cache-Control': "no-cache, no-store, must-revalidate, public, max-age=0",
            'Expires': '0',
            'Pragma': 'no-cache'})

    return mddr_response


@tsdos_api.after_request
def after_request(response):
    # response.headers.add('Access-Control-Allow-Origin', 'http://localhost:8080')
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

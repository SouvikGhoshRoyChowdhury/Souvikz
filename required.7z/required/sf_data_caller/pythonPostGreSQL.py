import psycopg2
from aac.tsdos.sf_common.common_functions import format_exception
from aac.tsdos.sf_common.common_functions import Configuration
import pandas as pd
import numpy as np
from datetime import datetime, date, timedelta
from typing import List, Optional, Tuple
import logging


class PostGreSqlConnector:
    pass


class PostGreSqlConnector:
    def __init__(self, config: Configuration, section: str, user: str, password: str, log=logging.Logger):
        self.config: Configuration = config
        self.section: str = section
        self.connection = None
        self.log = log

        try:
            # if not params:
            # params = config.dataMap[section]
            params = {
                "host": config.dataMap[section]["host"],
                "port": config.dataMap[section]["port"],
                "database": config.dataMap[section]["database"],
                "user": user,
                "password": password,
            }
            params["user"] = user
            params["password"] = password
            if not user:
                params["user"] = config.dataMap[section]["user"]

            if not password:
                params["password"] = config.dataMap[section]["password"]

            self.connection = psycopg2.connect(**params)
            # self.connection = SQLiteDatabase(self.connection, is_cursor=is_cursor)
        except Exception as ex:
            self.log.error(format_exception(ex))
            raise ex
        pass

    def __del__(self):
        if self.connection:
            self.connection.close()
        pass

    def execute(self, sql: str):
        cursor = self.connection.cursor()
        cursor.execute(sql)
        self.connection.commit()
        cursor.close()
        pass

    def table_exists(self, schema: str, tablename: str):
        """
        Checks if a tablename exists in the database

        :return:
        """

        result = False
        query = """select * from information_schema.tables
                   where table_schema = '<schema>'
                   and table_name = '<tablename>'
        """
        try:
            query = query.replace("<schema>", schema.lower())
            query = query.replace("<tablename>", tablename.lower())
            df = pd.read_sql(query, self.connection)

            if len(df) > 0:
                result = True
        except Exception as ex:
            self.log.error("PostGreSqlConnector::table_exists at: ", datetime.now())
            self.log.error(ex)
            raise ex
        return result

    def set_current_value(self, table: str):
        # query = """select currval('<table>_id_seq')"""
        query = """select max(id) from <table>"""
        query = query.replace("<table>", table)
        df = pd.read_sql(query, self.connection)
        max_id = df["max"].iloc[0]
        if max_id:
            table_parts = table.split(".")
            query_seq_id = """select distinct relname from pg_catalog.pg_class where relkind = 'S' 
               and relname like ('{}_id%')
            """.format(
                table_parts[1]
            )
            df_seq_id = pd.read_sql(query_seq_id, self.connection)
            if df_seq_id.empty:
                seq_id = "{}_id_seq".format(table_parts[1])
            else:
                seq_id = df_seq_id["relname"].iloc[0]

            query = """select setval('{}.{}', {})""".format(table_parts[0], seq_id, str(max_id))
            # query = query.replace('<table>', table)
            # query = query.replace('<value>', str(max_id))
            self.execute(query)
        pass

    def upload_df(self, table: str, df: pd.DataFrame, use_serial_key: bool = True):
        """
        uplaod_df takes a pandas dataframe and uploads it automatically with the columns that corresponds to the
        database table column names. So it is one to one mapping of the data frame columns and the table columns.
        Other columns in the dataframe are ignored. Also it ensures that the insert statements will be done with
        the correct data type format.
        :param table:   The database table
        :param df:      The pandas dataframe
        :param use_serial_key: When true the current value of the table will be set to the max serial value.
        :return:
        """
        df.columns = df.columns.str.lower()
        df_meta, constraint, constraint_fields = self.get_meta_data(table.lower())
        df_max_length = df_meta.copy()
        df_meta = df_meta.drop(["character_maximum_length"], axis=1)
        df_meta = df_meta.set_index("column_name").T
        columns = df_meta.columns.values.tolist()
        upload_columns = df.columns.values.tolist()
        columns = [x for x in columns if x in upload_columns]

        query_insert_template = """INSERT INTO <table> (<columns>)
                            VALUES<values>
        """
        # if constraint and len(df) == 1:
        #     df_update = df.drop (columns=constraint_fields, axis=1)
        #     query_insert_template += """on conflict on constraint <constraint>
        #         do update set
        #     """
        #     query_insert_template = query_insert_template.replace('<constraint>', constraint)
        #     values = self.get_formatted_key_values(df_update, df_meta, columns)
        #     query_insert_template += values
        if constraint:
            df_update = df.drop(columns=constraint_fields, axis=1)
            query_insert_template += """on conflict on constraint <constraint>
                do {}
            """
            if len(df) > 1:
                query_insert_template = query_insert_template.format("nothing")
            else:
                values = self.get_formatted_key_values(df_update, df_meta, df_max_length, columns)
                query_insert_template = query_insert_template.format("update set " + values)
            query_insert_template = query_insert_template.replace("<constraint>", constraint)

        if use_serial_key:
            self.set_current_value(table)
        query_insert_template = query_insert_template.replace("<table>", table)
        query_insert_template = query_insert_template.replace("<columns>", ",".join(columns))
        chunk_size = 5000
        list_of_df = PostGreSqlConnector.splitDataFrameIntoSmaller(df, chunk_size)
        count = 0

        for df_chunk in list_of_df:
            values = ""
            for row in df_chunk.itertuples():
                # count += 1
                # if count % chunk_size == 0:
                #     values = ')'
                #     query_insert = query_insert_template.replace('<values>', values)
                #     self.execute(query_insert)
                #     values = ''

                for column in columns:
                    if column.lower() not in df_chunk.columns:
                        continue

                    if not values:
                        values += "("
                    elif values[-1:] == ")":
                        values += ",("
                    elif values:
                        values += ","
                    value = getattr(row, column)
                    data_type = df_meta[column.lower()].iloc[0]
                    if pd.isnull(value):
                        value = "null"
                    elif "timestamp" in data_type:
                        if isinstance(value, datetime):
                            value = value.strftime("%Y-%m-%d %H:%M:%S")
                        value = "'" + value.strip() + "'"
                    elif data_type == "date" or data_type == "character varying":
                        if isinstance(value, datetime) or isinstance(value, date):
                            value = value.strftime("%Y-%m-%d")
                        value = str(value).replace("'", "''")
                        if value.strip():
                            value = "'" + value.strip() + "'"
                        else:
                            value = "null"
                        max_length = df_max_length[df_max_length.column_name == column]["character_maximum_length"].iloc[
                            0
                        ]
                        if len(value) - 2 > max_length and value != "null":
                            text = 'column {} has max length {} but value "{}" has length {}'.format(
                                column, max_length, value, len(value)
                            )
                            raise ValueError(text)
                    elif "interval" in data_type:
                        if isinstance(value, timedelta):
                            value = str(value)
                        value = "'" + value.strip() + "'"
                    elif data_type == "integer":
                        if value is None or value == "":
                            value = "null"
                        else:
                            if isinstance(value, str) and value.startswith("."):
                                value = "0" + value
                            try:
                                value = str(int(float(value)))
                            except Exception as ex:
                                self.log.error(column, value)
                    elif data_type == "boolean":
                        if isinstance(value, bool):
                            value = str(value)
                        elif isinstance(value, str) and value.lower() in ["true", "false"]:
                            value = value.lower()
                        elif isinstance(value, int) and value > 0:
                            value = "true"
                        elif isinstance(value, int) and value < 0:
                            value = "false"
                        elif value or value == False:
                            value = str(value)
                        else:
                            value = "null"
                    elif data_type == "double precision":
                        if value is None or value == "":
                            value = "null"
                        else:
                            value = str(np.float(value))
                    elif data_type.lower() == "user-defined":
                        if value is None or value == "":
                            value = "null"
                        else:
                            value = "'" + value.strip() + "'"
                    else:
                        value = str(value)
                    values += value
                if values:
                    values += ")"
            # values = values[:-1]
            # values += ')'
            query_insert = query_insert_template.replace("<values>", values)
            try:
                self.execute(query_insert)
            except Exception as ex:
                self.log.error(format_exception(ex))
                self.log.error(query_insert)
                raise ex
        pass

    def get_meta_data(self, table: str):
        """
        Gets the meta data from a database table, i.e. name, data type and size
        :param table:   The database table
        """
        query = """select column_name, data_type, character_maximum_length
                from INFORMATION_SCHEMA.COLUMNS where table_name = '<table>'
        """
        if table.find(".") < 0:
            query = query.replace("<table>", table)
            schema = ""
        else:
            fields = table.split(".")
            schema = fields[0].lower()
            table = fields[1].lower()
            query = query.replace("<table>", table)
            query += " and table_schema = '<schema>'"
            query = query.replace("<schema>", schema)

        query_constraint = """SELECT conname, conkey, contype
                                FROM pg_constraint
                                WHERE conrelid =
                                    (SELECT oid 
                                    FROM pg_class
                                    WHERE relname LIKE '<table>');
                                """
        query_constraint = query_constraint.replace("<table>", table)

        df = pd.read_sql(query, self.connection)
        df_constraint = pd.read_sql(query_constraint, self.connection)
        # df_constraint = df_constraint[~df_constraint.conname.isin([table + '_pkey'])]
        constraint_fields = []
        constraint = None
        df_constraint = df_constraint[df_constraint.contype.isin(["u"])]  # the unique type
        if not df_constraint.empty:
            constraint = df_constraint["conname"].iloc[0] if len(df_constraint) > 0 else ""
            if constraint:
                constraint_field_numbers = df_constraint[["conkey"]].iloc[0]
                for constraint_field_number in constraint_field_numbers[0]:
                    constraint_field = df["column_name"].iloc[constraint_field_number - 1]
                    constraint_fields.append(constraint_field)
        return (df, constraint, constraint_fields)

    def get_formatted_key_values(
        self, df: pd.DataFrame, df_meta: pd.DataFrame, df_max_length: pd.DataFrame, columns: list
    ):
        pairs = ""
        for row in df.itertuples():
            for column in columns:
                if column.lower() not in df.columns:
                    continue

                # if not values:
                #     values += '('
                # elif values [-1:] == ')':
                #     values += ',('
                if pairs:
                    pairs += ","
                value = getattr(row, column)
                data_type = df_meta[column.lower()].iloc[0]
                if pd.isnull(value):
                    value = "null"
                elif "timestamp" in data_type:
                    if isinstance(value, datetime):
                        value = value.strftime("%Y-%m-%d %H:%M:%S")
                    value = "'" + value.strip() + "'"
                elif data_type == "date" or data_type == "character varying":
                    if isinstance(value, datetime) or isinstance(value, date):
                        value = value.strftime("%Y-%m-%d")
                    try:
                        value = str(value).replace("'", "''")
                    except Exception as ex:
                        text = format_exception(ex)
                        text += "\n" + "value = " + str(value) + ", column = " + str(column)
                        raise AttributeError(text)
                    if value.strip():
                        value = "'" + value.strip() + "'"
                    else:
                        value = "null"
                    max_length = df_max_length[df_max_length.column_name == column]["character_maximum_length"].iloc[0]
                    if "''" in value:
                        max_length += value.count("''")
                    if len(value) - 2 > max_length and value != "null":
                        text = 'column {} has max length {} but value "{}" has length {}'.format(
                            column, max_length, value, len(value)
                        )
                        raise ValueError(text)
                elif "interval" in data_type:
                    if isinstance(value, timedelta):
                        value = str(value)
                    value = "'" + value.strip() + "'"
                elif data_type == "integer":
                    if value is None or value == "":
                        value = "null"
                    else:
                        value = str(int(value))
                elif data_type == "boolean":
                    if isinstance(value, bool):
                        value = str(value)
                    elif isinstance(value, str) and value.lower() in ["true", "false"]:
                        value = value.lower()
                    elif isinstance(value, int) and value > 0:
                        value = "true"
                    elif isinstance(value, int) and value < 0:
                        value = "false"
                    else:
                        value = str(value)
                elif data_type == "double precision":
                    if value is None or value == "":
                        value = "null"
                    else:
                        value = str(np.float(value))
                elif data_type.lower() == "user-defined":
                    if value is None or value == "":
                        value = "null"
                    else:
                        value = "'" + value.strip() + "'"
                else:
                    value = str(value)
                pairs += column + " = " + value
        return pairs

    @staticmethod
    def splitDataFrameIntoSmaller(df: pd.DataFrame, chunkSize: int = 10000):
        listOfDf = list()
        numberChunks = len(df) // chunkSize + 1
        for i in range(numberChunks):
            listOfDf.append(df[i * chunkSize : (i + 1) * chunkSize])
        return listOfDf

    @staticmethod
    def create_connection(
        config: Configuration, section: str, user: str, passwd: str, log: logging.Logger
    ) -> Tuple[PostGreSqlConnector, str]:
        """
        Creates an impala connection
        :param config - the configuration object containing connection variables for different environment

        :return connection - the created impala connection
        """
        retries = 3
        schema: str = config.dataMap[section]["schema"]
        database: str = config.dataMap[section]["database"]
        postgres: Optional[PostGreSqlConnector] = None
        while retries > 0:
            try:
                retries -= 1
                postgres = PostGreSqlConnector(config, section, user=user, password=passwd)
                retries = 0
            except Exception as ex:
                log.error(format_exception(ex))

        return postgres, schema

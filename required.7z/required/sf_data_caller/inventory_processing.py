from typing import List, Dict, Tuple, Union, NamedTuple, Optional
from typing_extensions import TypedDict
from datetime import timedelta, datetime

from aac.tsdos.sf_common.util import Logger
from aac.tsdos.sf_refdata.mnemonics import Mnemonics
from aac.tsdos.sf_funger.funger import Funger, FungerPacketDict
from aac.tsdos.sf_inventory_manager.transactions import SFContract, ORTransaction
from aac.tsdos.sf_inventory_manager.inventory_manager import InventoryManager


class PositionIdentifier(NamedTuple):
    isin: str
    market: str
    country: str
    settlement_depot: str
    settlement_account: Optional[str]
    date: str
    status: str
    client: Optional[int]
    depot: Optional[str]
    safe_keeping: Optional[str]
    account_type: Optional[str]
    account: Optional[int]
    subaccount: Optional[int]
    trade_type: str
    counterparty: Optional[Tuple[str, str]]
    mnemonic: str


class PositionValues(TypedDict):
    quantityOR: float
    quantitySF: float
    quantity_absolute: float
    total_longs: float
    total_shorts: float
    total_external_borrows: float
    total_internal_borrows: float
    total_external_borrow_fees: float
    total_external_loans: float
    total_internal_loans: float
    total_external_loan_fees: float
    total_pledges: float
    value_per_asset: float


class PositionValuesExposureRisk(PositionValues):
    total_external_borrow_returns: float
    total_internal_borrow_returns: float
    total_external_loan_returns: float
    total_internal_loan_returns: float


class FungedPositionValues(PositionValues):
    contributing_isin: str
    contributing_country: str


class FungedPositionValuesExposureRisk(PositionValuesExposureRisk, FungedPositionValues):
    pass


class ViewDict(TypedDict, total=False):
    flags: List[str]
    up_to_date: str  # optional


UnfungedPositionDict = Union[PositionValues, PositionValuesExposureRisk]
FungedPositionDict = Union[FungedPositionValues, FungedPositionValuesExposureRisk]
PositionDict = Union[UnfungedPositionDict, FungedPositionDict]

AggregateInventory = Dict[str, Union['AggregateInventory', PositionValues]]
FungedInventory = Dict[str, Union['AggregateInventory', FungedPositionValues]]


class InventoryProcessor:
    def __init__(
            self, log: Logger, inventory_manager: InventoryManager, refdata_mnemonics: Mnemonics, fungers: Funger,
            day: datetime
    ):
        """
        This class represents a mechanism for adding together lists of transactions into inventories (or, using the
        exposure_risk flag, exposure risks).
        :param log: The object to which to write log statements.
        :param inventory_manager: The object from which to retrieve transactions
        :param refdata_mnemonics: The object from which to analyze whether counterparties are external.
        :param fungers: the object which will perform funging.
        :param day: The day for which to run
        """
        self.cache = {}
        self.log = log
        self.inventory_manager = inventory_manager
        self.refdata_mnemonics = refdata_mnemonics
        self.fungers = fungers
        self.day = day

    def get_aggregate_inventory(
            self, projected_days: int, view: ViewDict, aggregate_order: List[str], funge: bool,
            isin: Optional[List[str]],
            counterparty: Optional[List[Tuple[str, str]]], client: Optional[List[str]]
    ) -> Union[AggregateInventory, FungedInventory]:
        """
        Retrieves a single aggregated inventory (or risk exposure, depending on the flag) for a given list of isins,
        counterparties or clients.
        :param projected_days: How many days to generate projected inventories for. Note that the first projected day
        is the end-of-day of this inventory processor's date, rather than the day afterwards.
        :param view: The view to apply to this inventory generation.
        :param aggregate_order: The order of attributes on which to aggregate the transactions. Resulting dictionary
        will have a depth equal to the length of the aggregate order, with the keys of each level being the value
        corresponding to the attribute at the same level of the aggregate order.
        :param funge: The Funger object, which carries out the process of funging.
        :param isin: The isin or list of isins for which to gather transactions to construct this inventory or risk
        exposure.
        :param counterparty: The counterparty or list of counterparties for which to gather transactions to construct
        this inventory or risk exposure.
        :param client: The client or list of clients for which to gather transactions to construct this inventory or
        risk exposure.
        :return: The aggregated inventory or risk exposure.
        """
        cache_tuple = (
            projected_days, funge, str(isin), str(counterparty), str(client), str(view), str(aggregate_order))

        # Get least update time
        update_time = None
        if isin is not None:
            for single_isin in isin:
                single_update_time = self.inventory_manager.transaction_cache.get_last_update_time(
                    single_isin, None, None)
                if update_time is None or single_update_time < update_time:
                    update_time = single_update_time
        if client is not None:
            for single_client in client:
                single_update_time = self.inventory_manager.transaction_cache.get_last_update_time(
                    None, single_client, None)
                if update_time is None or single_update_time < update_time:
                    update_time = single_update_time
        if counterparty is not None:
            for single_counterparty in counterparty:
                single_update_time = self.inventory_manager.transaction_cache.get_last_update_time(
                    None, None, single_counterparty)
                if update_time is None or single_update_time < update_time:
                    update_time = single_update_time

        if cache_tuple not in self.cache or update_time is None or self.cache[cache_tuple][0] < update_time:
            inv_transactions = self.inventory_manager.get_transactions(
                isin=isin, client=client, counterparty=counterparty)
            exposure_risk = 'flags' in view and 'exposure_risk' in view['flags']
            aggregate_inventory = self.translate_inventory_to_dictionary(
                inv_transactions, funge, aggregate_order, view, self.day,
                projected_days, exposure_risk)

            self.cache[cache_tuple] = (update_time, aggregate_inventory)
        else:
            return self.cache[cache_tuple][1]

    def translate_inventory_to_dictionary(
            self, inv_transactions: List[Union[ORTransaction, SFContract]], funge: bool, aggregate_order: List[str],
            view: dict, run_day: datetime, projected_days: int, exposure_risk: bool
    ) -> Union[AggregateInventory, FungedInventory]:
        """
        Aggregates a list of transactions into an inventory, applying a certain view filter.
        :param inv_transactions: List of transactions to translate into a dictionary.
        :param funge: Whether or not to 'funge' (combine fungible positions) the resulting dictionary. Last two items
        in the aggregate order must be 'isin' and 'country' for this to work.
        :param aggregate_order: The order of attributes on which to aggregate the transactions. Resulting dictionary
        will have a depth equal to the length of the aggregate order, with the keys of each level being the value
        corresponding to the attribute at the same level of the aggregate order.
        :param view: The view by which to filter the list of transactions.
        :param run_day: The day for which the inventory is generated. Used in combination for projected days to enrich
        the dates when that is set in the aggregate order.
        :param projected_days: The number of projected days for which to create an inventory
        :param exposure_risk: if False, will subtract, receipts, returned borrows and returned loans, thus subtracting
        them from absolute quantity. If True, will track returns separately, and thus add them to absolute quantity.
        :return:
        """
        if not inv_transactions:
            return {}
        inv_transactions = self.apply_view(inv_transactions, view, projected_days, run_day)
        aggregated_inventory = self.aggregate_inventory(
            inv_transactions, aggregate_order, run_day.strftime("%Y%m%d"), exposure_risk)
        if funge:
            if 'isin' not in aggregate_order or 'country' not in aggregate_order:
                raise ValueError(
                    "This aggregate order does not support funging. Funging must include 'isin' and 'country' "
                    "in the aggregate order.")
            else:
                aggregated_inventory = self.funge_aggregated_inventory(
                    aggregate_order, aggregated_inventory, exposure_risk)
        if 'date' in aggregate_order:
            self.enrich_dates(run_day, aggregated_inventory, projected_days, aggregate_order, exposure_risk)
        return aggregated_inventory

    @staticmethod
    def apply_view(
            inv_transactions: List[Union[ORTransaction, SFContract]], view: dict, projected_days: int,
            run_day: datetime
    ) -> List[Union[ORTransaction, SFContract]]:
        """
        Filters the given list of transactions by the given view.
        :param inv_transactions: The given list of transactions
        :param view: The given view.
        :param projected_days: The number of projected days. Transactions with settlement dates after this will be
        filtered. Note that the first projected day is the run day itself, rather than the day afterwards.
        :param run_day: The day for which the program is run.
        :return: The input list, except for those transactions filtered away by views.
        """
        unfiltered_transactions = []
        max_day = (run_day + timedelta(days=projected_days - 1)).strftime("%Y%m%d")
        run_day_str = run_day.strftime("%Y%m%d")

        for transaction in inv_transactions:
            if (
                    transaction.quantity == 0 or
                    transaction.status in {"CANCELLED", "CLOSED"} or
                    (projected_days == 0 and transaction.status != "SETTLED") or
                    (projected_days > 0 and transaction.value_date > max_day)
            ):
                continue

            elif view.get('flags') is not None:
                if "no_collateral" in view['flags']:  # Excludes all collateral transactions
                    if transaction.trade_type == "RECEIPT" or transaction.trade_type == "PLEDGE":
                        continue
                if "no_old_settled" in view['flags']:
                    if transaction.status == "SETTLED" and transaction.value_date < run_day_str:
                        continue
                if "only_collateral" in view['flags']:   # Excludes all non-collateral transactions
                    if not (transaction.trade_type == "RECEIPT" or transaction.trade_type == "PLEDGE"):
                        continue
                if "collateral_up_to" in view['flags']:  # Only includes collateral transactions up to a certain date
                    up_to_date: str = view.get('up_to_date')
                    if up_to_date is not None:
                        if (
                                not (transaction.trade_type == "RECEIPT" or transaction.trade_type == "PLEDGE") or
                                transaction.value_date > up_to_date
                        ):
                            continue
                if "no_intraday" in view['flags']:  # Only includes End-Of-Day transactions
                    if transaction.intraday:
                        continue
                if "only_intraday" in view['flags']:  # Only includes Intraday transactions
                    if not transaction.intraday:
                        continue
                if "only_sbl" in view['flags']:  # Excludes all non-SBL transactions
                    if not (
                            transaction.trade_type == "BORROW" or transaction.trade_type == "LOAN" or
                            transaction.trade_type == "BORROW RETURN" or transaction.trade_type == "LOAN RETURN"
                    ):
                        continue
                if "no_sbl" in view['flags']:  # Excludes all SBL transactions
                    if (
                            transaction.trade_type == "BORROW" or transaction.trade_type == "LOAN" or
                            transaction.trade_type == "BORROW RETURN" or transaction.trade_type == "LOAN RETURN"
                    ):
                        continue
                if 'include_custodian' not in view['flags']:  # Includes custodian transactions (usually left out)
                    if transaction.custody_transaction:
                        continue
                if 'ignore_triparty' in view['flags']:
                    if (
                            (type(transaction.ref) is str and transaction.ref.endswith('5')) or  # noqa
                            (transaction.trade_type in {'BORROW RETURN', 'LOAN RETURN'} and
                             transaction.ref.split('/')[0].endswith('5'))  # noqa
                    ):  # noqa
                        continue
                if transaction.isin is None or transaction.isin.startswith('DBV'):
                    continue
            unfiltered_transactions.append(transaction)

        return unfiltered_transactions

    def aggregate_inventory(
            self, inv_transactions: List[Union[ORTransaction, SFContract]], aggregate_order: List[str], run_day: str,
            exposure_risk: bool
    ) -> AggregateInventory:
        """
        Aggregates the given list of transactions into an inventory.
        :param inv_transactions: The list of transactions to aggregate
        :param aggregate_order: The order of attributes on which to attribute
        :param run_day: The day for which the inventory is aggregated (used to determine which transactions are OVERDUE)
        :param exposure_risk: if False, will subtract, receipts, returned borrows and returned loans, thus subtracting
        them from absolute quantity. If True, will track returns separately, and thus add them to absolute quantity.
        :return: the aggregated inventory
        """
        aggregated_inventory = {}

        for transaction in sorted(inv_transactions, key=lambda x: x.trade_type):
            aggregation_identifiers = []
            if transaction.status == "SETTLED":
                transaction_date = "SETTLED"
            elif transaction.status == "PENDING":
                if transaction.value_date < run_day:
                    transaction_date = "OVERDUE"
                else:
                    transaction_date = transaction.value_date
            elif transaction.status == "PROPOSED":
                transaction_date = "PROPOSED"
            else:
                self.log.error(
                    str(transaction.ref) + " has status '" + str(transaction.status) +
                    "', which can not be reconciled.")
                continue
            if transaction.quantity is None:
                self.log.error(
                    str(transaction.ref) + " has quantity None.")
                continue
            elif transaction.eur_value is None:
                self.log.error(
                    str(transaction.ref) + " has eur value None.")
                continue

            if type(transaction) is ORTransaction:
                transaction: ORTransaction
                identifier = PositionIdentifier(
                    isin=transaction.isin, market=transaction.market, country=transaction.market_country_code,
                    settlement_depot=transaction.settlement_depot, settlement_account=transaction.settlement_account,
                    date=transaction_date, status=transaction.status, client=transaction.client_number,
                    depot=transaction.depot_id, safe_keeping=transaction.safe_keeping_id,
                    account_type=transaction.account_type, account=transaction.account_number,
                    subaccount=transaction.subaccount_number, trade_type=transaction.trade_type, counterparty=None,
                    mnemonic=transaction.mnemonic)
            else:
                transaction: SFContract
                identifier = PositionIdentifier(
                    isin=transaction.isin, market=transaction.market, country=transaction.market_country_code,
                    settlement_depot=transaction.settlement_depot, settlement_account=transaction.settlement_account,
                    date=transaction_date, status=transaction.status, client=None, depot=None, safe_keeping=None,
                    account_type=None, account=None, subaccount=None, trade_type=transaction.trade_type,
                    counterparty=transaction.counterparty, mnemonic=transaction.mnemonic)
            for aggregation_point in aggregate_order:
                aggregation_identifiers.append(getattr(identifier, aggregation_point))
            self.add_to_aggregate_inventory_recursive(
                transaction, aggregated_inventory, aggregation_identifiers, exposure_risk)
        return aggregated_inventory

    def add_to_aggregate_inventory_recursive(
            self, item: Union[ORTransaction, SFContract], aggregated_inventory: AggregateInventory,
            aggregation_identifiers: List[str], exposure_risk: bool
    ) -> None:
        """
        Places the given item in the given aggregated inventory, using the given aggregation_identifiers to find the
        location where to add the item.
        :param item: The given item
        :param aggregated_inventory: The given aggregated inventory (or subinventory)
        :param aggregation_identifiers: The list of identifiers
        :param exposure_risk: if False, will subtract, receipts, returned borrows and returned loans, thus subtracting
        them from absolute quantity. If True, will track returns separately, and thus add them to absolute quantity.
        """
        if len(aggregation_identifiers) == 0:
            self.add_to_aggregate_inventory(item, aggregated_inventory, exposure_risk)
        else:
            current_identifier = aggregation_identifiers.pop(0)
            if aggregated_inventory.get(current_identifier) is None:
                aggregated_inventory[current_identifier] = {}
            self.add_to_aggregate_inventory_recursive(
                item, aggregated_inventory[current_identifier], aggregation_identifiers, exposure_risk)

    def _is_external(self, counterparty: Optional[Tuple[str, str]]) -> bool:
        """
        :param counterparty: The counterparty.
        :return: Whether or not the counterparty is external.
        """
        return counterparty is not None and self.refdata_mnemonics.is_external(counterparty[0])

    def add_to_aggregate_inventory(
            self, item: Union[ORTransaction, SFContract], aggregated_subinventory: PositionValues,
            exposure_risk: bool
    ) -> None:
        """
        Places the given item in the given subdictionary of the aggregated_inventory
        :param item: The item to add.
        :param aggregated_subinventory: The given subdictionary of the aggregated_inventory
        :param exposure_risk: if False, will subtract, receipts, returned borrows and returned loans, thus subtracting
        them from absolute quantity. If True, will track returns separately, and thus add them to absolute quantity.
        """
        try:
            if aggregated_subinventory == {}:
                aggregated_subinventory = self._make_empty_position_values(
                    aggregated_subinventory, exposure_risk=exposure_risk)
                old_quantity = 0.0
            else:
                old_quantity = self.get_total_position_size(aggregated_subinventory)

            if item.trade_type == 'BORROW':
                aggregated_subinventory['quantitySF'] += item.quantity
                if self._is_external(item.counterparty):
                    aggregated_subinventory['total_external_borrows'] += item.quantity
                    aggregated_subinventory['total_external_borrow_fees'] += (item.fee_rate * item.quantity)
                else:
                    aggregated_subinventory['total_internal_borrows'] += item.quantity
            elif item.trade_type == 'BORROW RETURN':
                aggregated_subinventory['quantitySF'] -= item.quantity
                if self._is_external(item.counterparty):
                    if not exposure_risk:
                        aggregated_subinventory['total_external_borrows'] -= item.quantity
                    else:
                        aggregated_subinventory['total_external_borrow_returns'] += item.quantity
                    aggregated_subinventory['total_external_borrow_fees'] -= (item.fee_rate * item.quantity)
                elif not exposure_risk:
                    aggregated_subinventory['total_internal_borrows'] -= item.quantity
                else:
                    aggregated_subinventory['total_internal_borrow_returns'] += item.quantity
            elif item.trade_type == 'LOAN':
                aggregated_subinventory['quantitySF'] -= item.quantity
                if self._is_external(item.counterparty):
                    aggregated_subinventory['total_external_loans'] += item.quantity
                    aggregated_subinventory['total_external_loan_fees'] += (item.fee_rate * item.quantity)
                else:
                    aggregated_subinventory['total_internal_loans'] += item.quantity
            elif item.trade_type == 'LOAN RETURN':
                aggregated_subinventory['quantitySF'] += item.quantity
                if self._is_external(item.counterparty):
                    if not exposure_risk:
                        aggregated_subinventory['total_external_loans'] -= item.quantity
                    else:
                        aggregated_subinventory['total_external_loan_returns'] += item.quantity
                    aggregated_subinventory['total_external_loan_fees'] -= (item.fee_rate * item.quantity)
                elif not exposure_risk:
                    aggregated_subinventory['total_internal_loans'] -= item.quantity
                else:
                    aggregated_subinventory['total_internal_loan_returns'] += item.quantity
            elif item.trade_type == 'RECEIPT':
                aggregated_subinventory['quantitySF'] += item.quantity
                if not exposure_risk:
                    aggregated_subinventory['total_pledges'] -= item.quantity
                else:
                    aggregated_subinventory['total_pledges'] += item.quantity
            elif item.trade_type == 'PLEDGE':
                aggregated_subinventory['quantitySF'] -= item.quantity
                aggregated_subinventory['total_pledges'] += item.quantity
            elif item.trade_type == 'BUY':
                aggregated_subinventory['quantityOR'] += item.quantity
                aggregated_subinventory['total_longs'] += item.quantity
            elif item.trade_type == 'SELL':
                aggregated_subinventory['quantityOR'] -= item.quantity
                aggregated_subinventory['total_shorts'] += item.quantity
            else:
                raise RuntimeError("Unrecognized trade type", item.trade_type)

            new_quantity = self.get_total_position_size(aggregated_subinventory)
            aggregated_subinventory['quantity_absolute'] = new_quantity

            quantity_diff = new_quantity - old_quantity
            if item.quantity != 0 and (old_quantity + quantity_diff) != 0 and item.eur_value is not None:
                old_value = (aggregated_subinventory['value_per_asset'] * old_quantity)
                value_diff = ((item.eur_value / item.quantity) * quantity_diff)
                aggregated_subinventory['value_per_asset'] = (
                    (old_value + value_diff) / new_quantity)
        except TypeError as e:
            if type(item) is SFContract:
                stat_string = f'Ref: {item.ref}, Trade Type: {item.trade_type}, Quantity: {item.quantity}, ' \
                              f'Value: {item.value}, Fee Rate: {item.fee_rate}'
            else:
                stat_string = f'Ref: {item.ref}, Trade Type: {item.trade_type}, Quantity: {item.quantity}, ' \
                              f'Value: {item.value}'
            self.log.error(f"Encountered TypeError while trying to add item with {stat_string}.")
            raise e

    def funge_aggregated_inventory(
            self, aggregate_order: List[str], aggregated_inventory: AggregateInventory, exposure_risk: bool
    ) -> FungedInventory:
        """
        Funges the given inventory.
        :param aggregate_order: The aggregate order for the inventory. Used to determine the depth of the ISIN and
        Country attributes in the given inventory.
        :param aggregated_inventory: The given inventory.
        :param exposure_risk: if False, will subtract, receipts, returned borrows and returned loans, thus subtracting
        them from absolute quantity. If True, will track returns separately, and thus add them to absolute quantity.
        :return:
        """
        flattened_inventory = self.funge_aggregated_inventory_flatten(aggregated_inventory, [])
        values = self.funge_aggregated_inventory_get_values(aggregate_order, flattened_inventory)
        clustered_inventory = self.funge_aggregated_inventory_cluster(
            aggregate_order, flattened_inventory, exposure_risk)
        funged_inventory = self.funge_aggregated_inventory_funge(
            aggregate_order, clustered_inventory, values, exposure_risk)
        reconstructed_inventory = self.funge_aggregated_inventory_reconstruct(funged_inventory)
        return reconstructed_inventory

    def funge_aggregated_inventory_flatten(self, inventory: AggregateInventory, keys: list) -> Dict[tuple, dict]:
        """
        Flattens the given inventory, turning it into a dictionary of depth 1 with the keys being a tuple of all the
        keys leading up to the highest-depth values, and the values being said highest-depth values.
        :param inventory: The given inventory.
        :param keys: Keeps track of the list of keys. Pass an empty list when calling this function, it will add to it
        when calling it recursively.
        :return:
        """
        if _get_dictionary_depth(inventory) == 0:
            return {tuple(keys): inventory}
        else:
            flat_inventory = {}
            for key, sub_inventory in inventory.items():
                new_keys = keys.copy()
                new_keys.append(key)
                flat_inventory = {**flat_inventory, **self.funge_aggregated_inventory_flatten(sub_inventory, new_keys)}
            return flat_inventory

    @staticmethod
    def funge_aggregated_inventory_get_values(
            aggregate_order: List[str], flattened_inventory: Dict[tuple, dict]
    ) -> Dict[str, Dict[str, float]]:
        """
        Generates a list of values for instruments from a flattened inventory.
        :param aggregate_order: The aggregate order for the flattened inventory. Used to determine the indexes of the
        isin and country attributes in the key tuples.
        :param flattened_inventory: The given flattened inventory.
        :return: A dictionary of values for instruments. Dictionary has a depth of 2, with the first layer of keys
        being the isins, and the second layer being the countries.
        """
        values = {}
        isin_index, country_index = aggregate_order.index('isin'), aggregate_order.index('country')

        for inventory_key, position in flattened_inventory.items():
            isin, country = inventory_key[isin_index], inventory_key[country_index]

            if isin not in values:
                values[isin] = {}
            values[isin][country] = abs(position['value_per_asset'])
        return values

    @staticmethod
    def funge_aggregated_inventory_cluster(
            aggregate_order: List[str], flattened_inventory: Dict[tuple, dict], exposure_risk: bool
    ) -> Dict[tuple, List[FungerPacketDict]]:
        """
        Clusters entries in a flattened inventory by the traits in the tuples that are not isin or country, thus
        creating a dictionary of lists to send to the funger object.
        :param aggregate_order: The aggregate order for the flattened inventory. Used to determine the indexes of the
        isin and country attributes in the key tuples.
        :param flattened_inventory: The given flattened inventory.
        :param exposure_risk: if False, will subtract, receipts, returned borrows and returned loans, thus subtracting
        them from absolute quantity. If True, will track returns separately, and thus add them to absolute quantity.
        :return:
        """
        isin_index, country_index = aggregate_order.index('isin'), aggregate_order.index('country')
        pop_indexes = [isin_index, country_index]
        pop_indexes.sort(reverse=True)

        clustered_dict = {}
        for inventory_key, position in flattened_inventory.items():
            other_ident_list = list(inventory_key)
            other_ident_list.pop(pop_indexes[0])
            other_ident_list.pop(pop_indexes[1])
            other_ident = tuple(other_ident_list)
            if other_ident not in clustered_dict:
                clustered_dict[other_ident] = []
            if not exposure_risk:
                clustered_dict[other_ident].append(
                    FungerPacketDict(
                        isin=inventory_key[isin_index], country=inventory_key[country_index], values=[
                            position['quantityOR'], position['quantitySF'], position['total_longs'],
                            position['total_shorts'], position['total_external_borrows'],
                            position['total_external_borrow_fees'], position['total_pledges'],
                            position['total_internal_borrows'], position['total_external_loans'],
                            position['total_external_loan_fees'], position['total_internal_loans']]))
            else:
                clustered_dict[other_ident].append(
                    FungerPacketDict(
                        isin=inventory_key[isin_index], country=inventory_key[country_index], values=[
                            position['quantityOR'], position['quantitySF'], position['total_longs'],
                            position['total_shorts'], position['total_external_borrows'],
                            position['total_external_borrow_fees'], position['total_pledges'],
                            position['total_internal_borrows'], position['total_external_loans'],
                            position['total_external_loan_fees'], position['total_internal_loans'],
                            position['total_internal_borrow_returns'], position['total_external_borrow_returns'],
                            position['total_internal_loan_returns'], position['total_external_loan_returns']]))
        return clustered_dict

    @staticmethod
    def funge_aggregated_inventory_get_value(
            values: Dict[str, Dict[str, float]], isins: List[str], countries: List[str]
    ) -> Optional[float]:
        """
        Retrieves the first value for a certain set of isins and countries from the dictionary generated by the
        funge_aggregated_inventory_get_values function.
        :param values: The given dictionary generated by the funge_aggregated_inventory_get_values function.
        :param isins: The given list of isins
        :param countries: The given list of countries
        :return: The first value for the list if isins and countries. None if no such value is available.
        """
        for isin in isins:
            for country in countries:
                if country == "Na":
                    country = None
                if values.get(isin) is not None and values[isin].get(country) is not None:
                    return values[isin][country]  # TODO SBTR-72

    def funge_aggregated_inventory_funge(
            self, aggregate_order: List[str], clustered_inventory: Dict[tuple, List[FungerPacketDict]],
            values: Dict[str, Dict[str, float]], exposure_risk: bool
    ) -> Dict[tuple, FungedPositionDict]:
        """
        Sends the clustered list of positions to the funger object, and returns the resulting list of funged positions.
        :param aggregate_order: The aggregate order for the inventory. Used to determine the indexes of the isin
        and country attributes in the key tuples.
        :param clustered_inventory: The given clustered inventory.
        :param values: The values dictionary generated by funge_aggregated_inventory_get_values
        :param exposure_risk: if False, will subtract, receipts, returned borrows and returned loans, thus subtracting
        them from absolute quantity. If True, will track returns separately, and thus add them to absolute quantity.
        :return: Structure of the returned inventory is same as the flattened inventory was, but with funging on isin
        and country values.
        """
        isin_index, country_index = aggregate_order.index('isin'), aggregate_order.index('country')
        insert_indexes = [isin_index, country_index]
        insert_indexes.sort()

        funged_clustered_dict = {}
        for other_ident, packet_list in clustered_inventory.items():
            for funged_packet in self.fungers.fung(packet_list):
                value = InventoryProcessor.funge_aggregated_inventory_get_value(
                    values, funged_packet['isin'].split('/'), funged_packet['country'].split('/'))
                if not exposure_risk:
                    quantity_absolute = (
                            funged_packet['values'][2] + funged_packet['values'][3] + funged_packet['values'][4] +
                            funged_packet['values'][6] + funged_packet['values'][7] + funged_packet['values'][8] +
                            funged_packet['values'][10])
                    funged_position = {
                        "quantityOR": funged_packet['values'][0], "quantitySF": funged_packet['values'][1],
                        "total_longs": funged_packet['values'][2], "total_shorts": funged_packet['values'][3],
                        "total_external_borrows": funged_packet['values'][4],
                        "total_external_borrow_fees": funged_packet['values'][5],
                        "total_pledges": funged_packet['values'][6],
                        "total_internal_borrows": funged_packet['values'][7],
                        "total_external_loans": funged_packet['values'][8],
                        "total_external_loan_fees": funged_packet['values'][9],
                        "total_internal_loans": funged_packet['values'][10],
                        "quantity_absolute": quantity_absolute,
                        "value_per_asset": value,
                        "contributing_isin": funged_packet['contributing_isin'],
                        'contributing_country': funged_packet['contributing_country']}
                else:
                    quantity_absolute = (
                            funged_packet['values'][2] + funged_packet['values'][3] + funged_packet['values'][4] +
                            funged_packet['values'][6] + funged_packet['values'][7] + funged_packet['values'][8] +
                            funged_packet['values'][10] + funged_packet['values'][11] + funged_packet['values'][12] +
                            funged_packet['values'][13] + funged_packet['values'][14])
                    funged_position = {
                        "quantityOR": funged_packet['values'][0], "quantitySF": funged_packet['values'][1],
                        "total_longs": funged_packet['values'][2], "total_shorts": funged_packet['values'][3],
                        "total_external_borrows": funged_packet['values'][4],
                        "total_external_borrow_fees": funged_packet['values'][5],
                        "total_pledges": funged_packet['values'][6],
                        "total_internal_borrows": funged_packet['values'][7],
                        "total_external_loans": funged_packet['values'][8],
                        "total_external_loan_fees": funged_packet['values'][9],
                        "total_internal_loans": funged_packet['values'][10],
                        "total_internal_borrow_returns": funged_packet['values'][11],
                        "total_external_borrow_returns": funged_packet['values'][12],
                        "total_internal_loan_returns": funged_packet['values'][13],
                        "total_external_loan_returns": funged_packet['values'][14],
                        "quantity_absolute": quantity_absolute,
                        "value_per_asset": value,
                        "contributing_isin": funged_packet['contributing_isin'],
                        'contributing_country': funged_packet['contributing_country']}

                # Insert the funged isin and country into the identifying tuple
                key_map = list(other_ident)
                key_map.insert(insert_indexes[0], "")
                key_map.insert(insert_indexes[1], "")
                key_map[isin_index] = funged_packet['isin']
                key_map[country_index] = funged_packet['country']
                funged_clustered_dict[tuple(key_map)] = funged_position

        return funged_clustered_dict

    @staticmethod
    def funge_aggregated_inventory_reconstruct(
            funged_inventory: Dict[tuple, FungedPositionValues]
    ) -> AggregateInventory:
        """
        Reconstructs the architecture of the original inventory inserted into the funging process from the funged
        inventory produced by funge_aggregated_inventory_funge
        :param funged_inventory: The given funged inventory produced by funge_aggregated_inventory_funge
        """
        aggregated_inventory = {}

        for key_tuple, funged_position in funged_inventory.items():
            key_map = list(key_tuple)
            sub_dictionary = aggregated_inventory
            while len(key_map) != 0:
                next_key = key_map.pop(0)
                if len(key_map) > 0:
                    if next_key not in sub_dictionary:
                        sub_dictionary[next_key] = {}
                    sub_dictionary = sub_dictionary[next_key]
                else:
                    sub_dictionary[next_key] = funged_position

        return aggregated_inventory

    @staticmethod
    def enrich_dates(
            run_day: datetime, aggregated_inventory: AggregateInventory, projected_days: int,
            aggregate_order: List[str], exposure_risk: bool
    ) -> None:
        """
        For the given aggregated inventory, copies data from previous days and adds it to following days, creating an
        inventory with the position on those days (rather than quantity changes for those days).
        :param run_day: The day for which the inventory is generated.
        :param aggregated_inventory: The given inventory.
        :param projected_days: The number of days for which the inventory projects into the future.
        :param aggregate_order: The aggregate order for the inventory. Used to determine the depth at which dates are in
        the inventory.
        :param exposure_risk: if False, will subtract, receipts, returned borrows and returned loans, thus subtracting
        them from absolute quantity. If True, will track returns separately, and thus add them to absolute quantity.
        :return:
        """
        aggregate_order = aggregate_order.copy()
        if aggregate_order[0] != 'date':
            aggregate_order.pop(0)
            for sub_inventory in aggregated_inventory.values():
                InventoryProcessor.enrich_dates(
                    run_day, sub_inventory, projected_days, aggregate_order, exposure_risk)
        else:
            if 'SETTLED' not in aggregated_inventory:
                if len(aggregate_order) != 1:
                    aggregated_inventory['SETTLED'] = {}
                else:
                    aggregated_inventory['SETTLED'] = PositionValues(
                        quantityOR=0.0, quantitySF=0.0, total_longs=0.0, total_shorts=0.0, total_external_borrows=0.0,
                        total_internal_borrows=0.0, total_external_borrow_fees=0.0, total_external_loans=0.0,
                        total_internal_loans=0.0, total_external_loan_fees=0.0, total_pledges=0.0, value_per_asset=0.0,
                        quantity_absolute=0.0)

            for x in range(projected_days):
                projected_day = (run_day + timedelta(days=x)).strftime('%Y%m%d')
                if x == 0:
                    previous_day = "SETTLED"
                else:
                    previous_day = (run_day + timedelta(days=x - 1)).strftime('%Y%m%d')

                if projected_day not in aggregated_inventory:
                    aggregated_inventory[projected_day] = aggregated_inventory[previous_day].copy()
                else:
                    InventoryProcessor.recursive_dictionary_addition(
                        aggregated_inventory[previous_day], aggregated_inventory[projected_day])

    @staticmethod
    def recursive_dictionary_addition(source_dict: dict, target_dict: dict) -> None:
        """
        Used by enrich_dates to add together the position values in inventories of arbitrary depth
        :param source_dict: The dictionary values are taken from.
        :param target_dict: The dictionary values are added to.
        """
        for key in source_dict:
            if type(source_dict[key]) is not dict:
                source_quantity = InventoryProcessor.get_total_position_size(source_dict)
                target_quantity = InventoryProcessor.get_total_position_size(target_dict)
                target_dict = InventoryProcessor.add_position_to_position(
                    target_pos=target_dict, source_pos=source_dict)

                source_value = source_quantity * source_dict['value_per_asset']
                target_value = target_quantity * target_dict['value_per_asset']

                if (source_quantity + target_quantity) != 0:
                    target_dict['value_per_asset'] = (source_value + target_value) / (source_quantity + target_quantity)
                else:
                    target_dict['value_per_asset'] = 0.0

                return
            elif key not in target_dict:
                target_dict[key] = source_dict[key].copy()
            else:
                InventoryProcessor.recursive_dictionary_addition(source_dict[key], target_dict[key])

    @staticmethod
    def get_total_position_size(position: PositionDict) -> float:
        """
        Returns the total quantity of the given position
        :param position: The given position
        :return: The total position size.
        """
        return (
                position.get('total_longs', 0.0) +
                position.get('total_shorts', 0.0) +
                position.get('total_external_borrows', 0.0) +
                position.get('total_external_borrow_returns', 0.0) +
                position.get('total_internal_borrows', 0.0) +
                position.get('total_internal_borrow_returns', 0.0) +
                position.get('total_external_loans', 0.0) +
                position.get('total_external_loan_returns', 0.0) +
                position.get('total_internal_loans', 0.0) +
                position.get('total_internal_loan_returns', 0.0) +
                position.get('total_pledges', 0.0))

    @staticmethod
    def add_position_to_position(target_pos: PositionDict, source_pos: PositionDict):
        """
        Adds one position dictionary to another dictionary.
        :param target_pos: The position dictionary to which the other position dictionary is added.
        :param source_pos: The position dictionary to add to the other position dictionary.
        :return: The target_pos, enriched with the data from the source_pos.
        """
        target_pos['quantityOR'] += source_pos['quantityOR']
        target_pos['quantitySF'] += source_pos['quantitySF']
        target_pos['total_longs'] += source_pos['total_longs']
        target_pos['total_shorts'] += source_pos['total_shorts']
        target_pos['total_internal_borrows'] += source_pos['total_internal_borrows']
        target_pos['total_external_borrows'] += source_pos['total_external_borrows']
        target_pos['total_pledges'] += source_pos['total_pledges']
        target_pos['total_external_borrow_fees'] += source_pos['total_external_borrow_fees']
        target_pos['total_internal_loans'] += source_pos['total_internal_loans']
        target_pos['total_external_loans'] += source_pos['total_external_loans']
        target_pos['total_external_loan_fees'] += source_pos['total_external_loan_fees']
        target_pos['quantity_absolute'] = InventoryProcessor.get_total_position_size(target_pos)
        return target_pos

    @staticmethod
    def _make_empty_position_values(empty_dict, exposure_risk) -> UnfungedPositionDict:
        """
        Enriches the given empty dictionary into an empty PositionValues or PositionValuesRiskExposure.
        :param empty_dict: The given empty dictionary
        :param exposure_risk: Whether to turn the dictionary into a PositionValues (if False) or
        PositionValuesRiskExposure (if True).
        :return: The enriched dictionary.
        """
        if not exposure_risk:
            empty_dict['quantityOR'] = 0.0
            empty_dict['quantitySF'] = 0.0
            empty_dict['quantity_absolute'] = 0.0
            empty_dict['total_longs'] = 0.0
            empty_dict['total_shorts'] = 0.0
            empty_dict['total_external_borrows'] = 0.0
            empty_dict['total_internal_borrows'] = 0.0
            empty_dict['total_external_borrow_fees'] = 0.0
            empty_dict['total_external_loans'] = 0.0
            empty_dict['total_internal_loans'] = 0.0
            empty_dict['total_external_loan_fees'] = 0.0
            empty_dict['total_pledges'] = 0.0
            empty_dict['value_per_asset'] = 0.0
            return empty_dict
        else:
            empty_dict['quantityOR'] = 0.0
            empty_dict['quantitySF'] = 0.0
            empty_dict['quantity_absolute'] = 0.0
            empty_dict['total_longs'] = 0.0
            empty_dict['total_shorts'] = 0.0
            empty_dict['total_external_borrows'] = 0.0
            empty_dict['total_internal_borrows'] = 0.0
            empty_dict['total_external_borrow_fees'] = 0.0
            empty_dict['total_external_loans'] = 0.0
            empty_dict['total_internal_loans'] = 0.0
            empty_dict['total_external_loan_fees'] = 0.0
            empty_dict['total_pledges'] = 0.0
            empty_dict['value_per_asset'] = 0.0
            empty_dict['total_external_borrow_returns'] = 0.0
            empty_dict['total_internal_borrow_returns'] = 0.0
            empty_dict['total_external_loan_returns'] = 0.0
            empty_dict['total_internal_loan_returns'] = 0.0
            return empty_dict


def _get_dictionary_depth(given_dictionary: dict) -> int:
    """
    Returns the depth of the given dictionary, which is the number of subdictionary layers. The dictionary {} has a
    depth of 0, the dictionary {'arbitrary': {}} has a depth of 1, {'arbitrary': {'arbitrary': {}} has a depth of 2,
    etc. Assumes that all subdictionaries have equal depth
    :param given_dictionary: The given dictionary
    :return: the depth of the given inventory
    """
    zero_depth = True
    for key in given_dictionary.keys():
        if type(given_dictionary[key]) is dict:
            zero_depth = False
        break
    if zero_depth:
        return 0
    else:
        sub_dictionary = {}
        for key in given_dictionary.keys():
            sub_dictionary = given_dictionary[key]
            break
        return _get_dictionary_depth(sub_dictionary) + 1

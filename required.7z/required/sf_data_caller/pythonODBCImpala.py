import os
from datetime import datetime, date, timedelta
import configparser
import pyodbc
from typing import List, Tuple, Dict, Union, NamedTuple, Optional, TypedDict
from typing_extensions import Literal

from aac.tsdos.sf_common.util import Logger
from aac.tsdos.sf_common.common_functions import (
    previous_business_day,
    translate_market_area_to_country,
    translate_country_to_market_area_prefix,
    convert_to_bool,
    get_previous_business_days,
)


# TODO can be removed after testing datalake access to spm table was successful
class SPMTestQResultTuple(NamedTuple):
    isin: str
    quantity: float
    settlement_date: int
    trade_date: int


# TODO can be removed after testing datalake access to swift payments table was successful
class SwiftPaymentsTestQResultTuple(NamedTuple):
    destinationaddress: str
    rawmessage: str
    receiverdate: str
    senderaddress: str


class MnmcsQresult(NamedTuple):
    mnemonics_code: str
    type: str
    name: str
    borrow_is_supply_boolean: bool
    lender_boolean: bool
    short_coverage_boolean: bool


class MicsQresult(NamedTuple):
    mnemonics_code: str
    mics_client_number: int
    mics_client_depot: str
    mics_client_safekeep: str


class FoursQresult(NamedTuple):
    mnemonics_code: str
    client_code: str
    fours_client_entity: str


class InstrumentQResultTuple(NamedTuple):
    isin: str
    market_code: str
    ref_description: str
    ref_country_code: str
    ref_market_country_code: str
    currency_code: str
    value: float
    ref_category: str


class SPMConversionQResultTuple(NamedTuple):
    isin_from: str
    depot_id_from: str
    safekeeping_id_from: str
    isin_to: str
    depot_id_to: str
    safekeeping_id_to: str


class SPMDepotSwitchQResultTuple(NamedTuple):
    isin: str
    depot_id_from: str
    safekeeping_id_from: str
    depot_id_to: str
    safekeeping_id_to: str


class CurrencyEntry(NamedTuple):
    ccy_code: str
    ref_eur_fx_rate: float
    day_basis: int
    decimal_places: int
    name: str
    ref_fx_rate: float
    ref_fx_rate_date: str


class MarketIndexEntry(NamedTuple):
    market_index_code: str
    name: str
    rate: float
    rate_date: str


class MicsSettledEntry(NamedTuple):
    isin: str
    last_movement_date: datetime
    currency_code_price: str
    depot_id: str
    safe_keeping_id: str
    product_group_code: str
    client_number: int
    account_type: str
    account_number: int
    subaccount_number: int
    quantity_long_prim_prod: float
    quantity_short_prim_prod: float
    transaction_value: float  # is mark_to_market_value data attribute in datalake
    effective_value_d_c: str  # str equals C or D for credit/debit  # is mark_to_market_value_d_c data attribute in datalake  # noqa
    symbol: str


class MicsPendingEntry(NamedTuple):
    isin: str
    settlement_date: datetime
    currency_code: str
    quantity: float
    buy_sell_code: str
    depot_id: str
    safe_keeping_id: str
    product_group_code: str
    client_number: int
    account_type: str
    account_number: int
    subaccount_number: int
    transaction_value: float  # is mark_to_market_value data attribute in datalake
    effective_value_d_c: str  # str equals C or D for credit/debit  # is mark_to_market_value_d_c data attribute in datalake  # noqa
    opposite_party_code: str
    exchange_code_trade: str
    transaction_date: datetime
    symbol: str


class FoursCollateralEntry(NamedTuple):
    ref: str
    trade_type: str
    value_date: str
    quantity: float
    status: str
    book_code: str
    book_entity: str
    ccy_code: str
    counterparty_code: str
    counterparty_entity: str
    market_code: str
    isin: str
    settlement_depot: str
    settlement_account: str
    transaction_value: float
    trader_id: str
    settlement_date: str
    trade_date: str


class FoursSBLEntry(NamedTuple):
    ref: str
    updated_date_time: str
    trade_type: str
    value_date: str
    quantity: float
    status: str
    book_code: str
    book_entity: str
    ccy_code: str
    counterparty_code: str
    counterparty_entity: str
    fee_rate: str
    market_code: str
    isin: str
    settlement_depot: str
    settlement_account: str
    termed_date: str
    collateral_margin: float
    transaction_value: float
    trader_id: str
    trade_date: str
    settlement_date: str


class BenchmarkRate(NamedTuple):
    ref: str
    isin: str
    market_area: str
    tradable_fee: float
    year: int
    month: int
    day: int
    datefromfilename: datetime
    isin_type: str
    timing: Literal["early", "final"]

    @property
    def market_country_code(self):
        return translate_market_area_to_country(self.market_area)


class ClientEntry(NamedTuple):
    client_number: int
    client_name: str
    holding_number: int
    active_ind: str


class HoldingEntry(NamedTuple):
    holding_number: int
    holding_name: str


class SBLContractEntry(NamedTuple):
    ref: str
    updated_date_time: str
    trade_type: str
    value_date: str
    trade_date: str
    quantity: float
    status: str
    book_code: str
    book_entity: str
    ccy_code: str
    ccy_eur_fx_rate: float
    counterparty_code: str
    counterparty_entity: str
    counterparty_name: str
    counterparty_country_code: str
    counterparty_ref_type: str
    fee_rate: float
    isin_market_code: str
    isin_market_country_code: str
    isin: str
    isin_description: str
    isin_category: str
    settlement_depot: str
    settlement_account: str
    termed_date: Optional[str]
    collateral_margin: float
    trader: str
    market_value: float
    market_value_ccy: str
    req_dividend_rate: float
    settlement_date: Optional[str]
    original_ref: str


class CollateralTransactionEntry(NamedTuple):
    ref: str
    trade_type: str
    date_from_filename: str
    business_date: str
    value_date: str
    trade_date: str
    quantity: float
    status: str
    book_code: str
    book_entity: str
    ccy_code: str
    ccy_ref_eur_fx_rate: float
    counterparty_code: str
    counterparty_entity: str
    counterparty_refname: str
    security_market_code: str
    security_isin: str
    security_ref_description: str
    security_ref_category: str
    settlement_account: str
    settlement_depot: str
    calc_market_value_amount: float
    calc_market_value_ccy_code: str
    req_dividend_rate: float
    ticker: str
    haircut: float
    fours_mnemonic: str
    mics_depot: Optional[str]
    mics_safekeep: Optional[str]


class FoursSBLReturnExtendedEntry(NamedTuple):
    ref: str
    original_ref: str
    updated_date_time: str
    return_ref: str
    return_original_ref: str
    quantity: float
    value_date: str
    recall: bool
    calc_market_value_amount: float
    trader_id: str
    trade_date: str


class FoursSBLReturnEntry(NamedTuple):
    ref: str
    updated_date_time: str
    return_ref: str
    quantity: float
    value_date: str
    recall: bool
    calc_market_value_amount: float
    trade_date: str


class PriceCheckerSFEntry(NamedTuple):
    isin: str
    market_code: str
    transaction_value: float
    ccy_code: str
    quantity: float
    status: str


class PriceCheckerOREntry(NamedTuple):
    isin: str
    safe_keeping: str
    transaction_value: float
    ccy_code: str
    quantity: float


class IsinCountryPair(NamedTuple):
    isin: str
    country: str


class RateTuple(NamedTuple):
    isincountrytuple: IsinCountryPair
    rate: Optional[float]


class MarketTuple(NamedTuple):
    isin: str
    market: str


class CashTitlePosition(NamedTuple):
    client_number: int
    cash_title_position: float
    cash_title_position_d_c: str
    currency_code: str
    journal_code: int


class CashProductValuation(NamedTuple):
    symbol: str
    valuation_price: float
    pricing_unit: int


class HoldingPosition(NamedTuple):
    holding_nr: int
    holding_name: str


class JournalCodeTuple(NamedTuple):
    journal_code: int
    description: str
    code_grossity: str


class IMMarginTuple(NamedTuple):
    counterparty_code: str
    amount: float
    ccy: str


class CommodityRepoTuple(NamedTuple):
    client_code: str
    client_name: str
    client_xref: str
    ccy_code: str
    all_in_rate: float
    agreed_settlement_date: str
    actual_settlement_date: Optional[str]
    trader_id: str
    country_code: str
    repo_type: str
    trade_date: str
    end_date: str
    external_ref: Optional[str]
    cash_start: float
    cash_end: float
    counterparty_code: str
    commodity_type: str


class SharkAPIFeedingTuple(NamedTuple):
    SecId: str
    RebateRate: str
    ZoneCode: str


class MarginGrossBalance(NamedTuple):
    client_number: int
    holding_number: int
    account_type: str
    account_number: int
    subaccount_number: int
    clearing_entity: str
    opposite_party_code: str
    gross_balance_amount: float
    d_c: str
    currency_code: str
    value_date: datetime
    last_movement_date: datetime


class UnsettledPosition(TypedDict):
    isin: str
    buy_sell_code: str
    settlement_date: datetime
    exchange: str
    currency_code: str
    opposite_party: str
    quantity: float
    client_number: int


class SyntheticData(TypedDict):
    ISIN: str
    COUNTRY_CODE: str
    MIC_CODE: str
    AVAILABILITY: str
    RATE: str
    AVERAGE: str


class DatahubConnectionService:
    """
    This class provides the service used to make connection with Datahub
    :param env - the database environment to access
    :param day - the date for which to access information
    """

    def __init__(self, env: str, day: Union[date, datetime], log: Logger) -> None:
        self.log = log
        self.env = env

        config = configparser.ConfigParser()
        config.read(
            os.path.join(
                os.path.dirname(__file__),
                "..",
                "sf_config",
                "sf_data_caller_config",
                "env.cfg",
            )
        )

        self.use_prd_clone = convert_to_bool(config["IMPALA " + self.env]["use_prd_alternatives"])
        self.accept_empty_results = convert_to_bool(config["IMPALA " + self.env]["accept_empty_results"])

        self.secfin_db = "secfin" if self.env == "PROD" or not self.use_prd_clone else "secfinprd"
        self.micsce_db = "micsce" if self.env == "PROD" or not self.use_prd_clone else "micsceprd"
        self.spm_db = "spm" if self.env == "PROD" or not self.use_prd_clone else "spmprd"
        self.payments_db = "payments" if self.env == "PROD" or not self.use_prd_clone else "paymentsprd"
        self.micsap_hk_db = "micsap_hk" if self.env == "PROD" or not self.use_prd_clone else "micsap_hkprd"
        self.date = day
        self.date_checker = False

        # Connecting to Impala Big Data hub
        self.connection = self.create_connection(config)
        self.log.debug("Impala connection open")

        # Sets the limits for data acquisition. In Production, refdata may be up to twenty business days old,
        # while position must be from the same day. In other environment, refdata may be up to a 200 business days old,
        # while position data may be up to forty days old.
        if self.env == "PROD":
            self.refdata_limit: int = 20
            self.position_limit: int = 1
            self.rates_limit: int = 1
            self.kafka_limit: int = 5
            self.shark_limit: int = 1
            self.hk_limit: int = 2
        else:
            self.refdata_limit: int = 200
            self.position_limit: int = 140
            self.rates_limit: int = 500
            self.kafka_limit: int = 5
            self.shark_limit: int = 1
            self.hk_limit: int = 2

    def _query_maker(self, query, datum):
        """
        This method is to use _run_query_with_lookback function for queries
        other than those where parameters provided day, month and year in order,
        and comparing to '%s',with no other WHERE parameter comparing to '%s'
        @param query: query to be executed
        @param datum: date object to modify
        @return:
        """
        date_modified = datum.strftime("%Y-%m-%d")
        return query.replace(
            "u.settlement_date = ''", f"""u.settlement_date = '{date_modified}' """
        )

    def create_connection(self, config: configparser.ConfigParser) -> pyodbc.Connection:
        """
        Creates an impala connection
        :param config - the configuration object containing connection variables for different environment

        :return connection - the created impala connection
        """
        try:
            connection_string: str = config["IMPALA " + self.env]["src"]
            connection: pyodbc.Connection = pyodbc.connect(
                connection_string, autocommit=True
            )
            return connection
        except pyodbc.Error as e:
            import traceback

            traceback.print_exc()
            self.log.error("POI-ERROR-001 " + "Impala connection error %s", e)

    def _run_query(self, query: str, query_name: str) -> List[pyodbc.Row]:
        """
        Executes the given sql query and returns the result
        :param query: the given query
        :return: the result of the query
        """
        count: int = 0
        result = None
        while True and count < 10:
            try:
                cursor = self.connection.cursor()
                cursor.execute(query)
                result = cursor.fetchall()
                break
            except Exception as e:
                self.log.warn(
                    f"POI-WARN-002 Encountered issue {e} while running {query_name}. This is warning "
                    f"#{count} while running this query."
                )
                count += 1
        if count > 10:
            raise ConnectionError(
                f"ERROR-001-A-podbc: Attempt run query {query_name} failed {count} times. "
                f"Discontinuing."
            )
        if result is None:
            self.log.error(
                f"POI-WARN-003 ODBC query returned {query_name} a result of None."
            )
        return result

    def _run_query_with_lookback(
            self, query_name: str, query: str, limit: int, special_query=False
    ) -> Tuple[List[pyodbc.Row], datetime]:
        """
        Executes a given query, and keeps running the query for earlier days until either a result has been found,
        or the limit for the amount of days has been reached.
        :param query_name: The name of the query to use in logs
        :param query: The given query. Should have a WHERE statement with parameters day, month and year in that order,
        and comparing to '%s' , with no other WHERE parameter comparing to '%s'.
        :param limit: The amount of days into the past for which to run the query.
        :param special_query: default value is False,any method can set this True
        and use it with _query_maker for custom date as query parameter
        :return:
        """
        result = []
        self_date = self.date
        count_empty = 0
        count_none = 0
        while (
                (result is None or len(result) == 0)
                and count_empty < limit
                and count_none < 10
        ):
            if special_query:
                date_specific_query = self._query_maker(query, self_date)
                print(date_specific_query)
                result = self._run_query(date_specific_query, query_name)
            else:
                date_specific_query = query % (
                    self_date.day,
                    self_date.month,
                    self_date.year,
                )
                result = self._run_query(date_specific_query, query_name)
            if result is None:
                count_none += 1
            elif len(result) == 0:
                if self.accept_empty_results:
                    return result, self_date
                else:
                    self_date = previous_business_day(self_date)
                    self.date_checker = True
                    count_empty += 1
            if count_empty == limit:
                self.log.error(
                    f"POI-ERROR-004 No {query_name} data could be found in the database for the last {limit}"
                    f" days, which is the limit for the {self.env} environment"
                )
                return result, self_date
            if count_none == 10:
                self.log.error(f"POI-ERROR-005 No {query_name} data could be found.")
                raise ConnectionError(
                    f"No {query_name} data could be found. A connection issue is the likely cause. "
                    f"Check the connection and the database availability."
                )
        if count_empty > 1:
            self.log.warn(
                f"The retrieved and utilized {query_name} data is more than one business day old. "
                f"Data was retrieved from {self_date.strftime('%Y-%m-%d')}."
            )
        return result, self_date

    def get_instruments(self, mics_only: bool = False) -> List[InstrumentQResultTuple]:
        """
        Requests data on financial instruments through the established connection
        :return - A list of tuples, each representing a row in the instrument table
        """
        query_name = "instruments"
        query = f"""
            SELECT
                isin,
                market_code,
                ref_description,
                ref_country_code,
                ref_market_country_code,
                market_price.ccy.code,
                market_price.amount,
                ref_category
            FROM
                {self.secfin_db}.instruments
            WHERE
                day = %s AND
                month = %s AND
                year = %s
        """
        if mics_only:
            query += """ 
                AND ref_category IN ('STOCK', 'BOND')
        """
        limit: int = self.refdata_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[InstrumentQResultTuple] = []
        for entry in result:
            named_result.append(InstrumentQResultTuple(*entry))
        result = named_result
        return result

    def get_spm_data_test(self) -> List[SPMTestQResultTuple]:
        """
        Requests data from spm table to check if access to this table has been granted
        :return - A list of tuples, each representing a row in the spm table
        """
        query_name = "spm depot_switch_leg"
        query = f"""
            SELECT
                isin, 
                quantity, 
                settlement_date, 
                trade_date
            FROM
                {self.spm_db}.depot_switch_leg
            WHERE
                day = %s AND
                month = %s AND
                year = %s
        """
        limit: int = self.refdata_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[SPMTestQResultTuple] = []
        for entry in result:
            named_result.append(SPMTestQResultTuple(*entry))
        result = named_result
        return result

    def get_mnemonics(self) -> List[MnmcsQresult]:
        query_name = "mnemonics"
        query = f"""
            SELECT
                imt_mnenomic.code,
                imt_mnenomic.type, 
                imt_mnenomic.name, 
                imt_mnenomic.borrow_is_supply, 
                imt_mnenomic.lender, 
                imt_mnenomic.short_coverage
            FROM 
                {self.secfin_db}.mnemonics, 
                mnemonics.`data`.imt_mnenomic
            WHERE 
                day = %s AND 
                month = %s AND 
                year = %s AND 
                imt_mnenomic.code IS NOT NULL 
        """
        limit: int = self.refdata_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[MnmcsQresult] = []
        for entry in result:
            named_result.append(MnmcsQresult(*entry))
        result = named_result

        return result

    def get_mnemonics_mics_clients(self) -> List[MicsQresult]:
        query_name = "mnemonics mics clients"
        query = f"""
            SELECT 
                imt_mnenomic.code,
                mics_outright_client.client_number, 
                mics_outright_client.depot, 
                mics_outright_client.safe_keep
            FROM
                {self.secfin_db}.mnemonics, 
                mnemonics.`data`.imt_mnenomic, 
                imt_mnenomic.mics_outright_client
            WHERE 
                day = %s AND 
                month = %s AND 
                year = %s AND 
                imt_mnenomic.code IS NOT NULL
        """
        limit: int = self.refdata_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[MicsQresult] = []
        for entry in result:
            named_result.append(MicsQresult(*entry))
        result = named_result

        return result

    def get_mnemonics_4s_clients(self) -> List[FoursQresult]:
        query_name = "mnemonics 4s clients"
        query = f"""
            SELECT
                imt_mnenomic.code, 
                `4s_sbl_client`.code, 
                `4s_sbl_client`.entity
            FROM 
                {self.secfin_db}.mnemonics, 
                mnemonics.`data`.imt_mnenomic, 
                imt_mnenomic.`4s_sbl_client`
            WHERE 
                day = %s AND 
                month = %s AND 
                year = %s AND 
                imt_mnenomic.code IS NOT NULL 
        """
        limit: int = self.refdata_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[FoursQresult] = []
        for entry in result:
            named_result.append(FoursQresult(*entry))
        result = named_result

        return result

    def get_currencies(self) -> List[CurrencyEntry]:
        query_name = "currencies"
        query = f"""
            SELECT
                code, 
                ref_eur_fx_rate, 
                day_basis, 
                decimal_places, 
                name, 
                ref_fx_rate, 
                ref_fx_rate_date 
            FROM
                {self.secfin_db}.currencydata 
            WHERE
                day = %s AND 
                month = %s AND 
                year = %s
        """
        limit: int = self.refdata_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[CurrencyEntry] = []
        for entry in result:
            named_result.append(CurrencyEntry(*entry))
        result = named_result
        return result

    def get_market_indexesdata(self) -> List[MarketIndexEntry]:
        query_name = "market indexes"
        query = f"""
            SELECT 
                code, 
                name, 
                ref_rate, 
                ref_rate_date
            FROM
                {self.secfin_db}.indexdata
            WHERE 
                day = %s AND 
                month = %s AND 
                year = %s
        """
        limit: int = self.refdata_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[MarketIndexEntry] = []
        for entry in result:
            named_result.append(MarketIndexEntry(*entry))
        result = named_result

        return result

    def get_mics_settled_all(self) -> List[MicsSettledEntry]:
        query_name = "mics settled all"
        query = f"""
            SELECT 
                isin,
                last_movement_date, 
                currency_code_price,
                depot_id,
                safe_keeping_id,
                product_group_code,
                client_number,
                account_type,
                account_number,
                subaccount_number,
                quantity_long_prim_prod,
                quantity_short_prim_prod,
                mark_to_market_value,
                mark_to_market_value_d_c,
                `symbol`
            FROM
                {self.micsce_db}.settled_position
            WHERE
                day = %s AND 
                month = %s AND 
                year = %s
        """
        limit: int = self.position_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[MicsSettledEntry] = []
        for entry in result:
            named_result.append(MicsSettledEntry(*entry))
        result = named_result

        return result

    def get_mics_pending_all(self) -> List[MicsPendingEntry]:
        query_name = "mics pending all"
        query = f"""
            SELECT 
                isin,
                settlement_date,
                currency_code,
                quantity,
                buy_sell_code,
                depot_id,
                safe_keeping_id,
                product_group_code,
                client_number,
                account_type,
                account_number,
                subaccount_number,
                effective_value,
                effective_value_d_c,
                opposite_party_code,
                exchange_code_trade,
                transaction_date,
                `symbol`
            FROM
                {self.micsce_db}.pending_position
            WHERE
                day = %s AND 
                month = %s AND 
                year = %s
        """
        limit: int = self.position_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[MicsPendingEntry] = []
        for entry in result:
            named_result.append(MicsPendingEntry(*entry))
        result = named_result

        return result

    def get_4s_collateral_all(self) -> List[FoursCollateralEntry]:
        query_name = "4s collateral all"
        query = f"""
            SELECT 
                `ref`,
                trade_type,
                value_date,
                quantity,
                status,
                book.code,
                book.entity,
                calc_market_value.ccy.code,
                counterparty.code,
                counterparty.entity,
                security.market_code,
                security.isin,
                settlement.depot,
                settlement.account,
                calc_market_value.amount,
                user.id,
                settlement.`date`,
                trade_date
            FROM
                {self.secfin_db}.collateralposition
            WHERE 
                day = %s AND 
                month = %s AND 
                year = %s  AND 
                NOT (trade_type = "BORROW" OR trade_type = "LOAN")
        """
        limit: int = self.position_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[FoursCollateralEntry] = []
        for entry in result:
            named_result.append(FoursCollateralEntry(*entry))
        result = named_result

        return result

    def get_4s_sbl_all(self) -> List[FoursSBLEntry]:
        query_name = "4s sbl all"
        query = f"""
            SELECT 
                `ref`,
                updated_date_time,
                trade_type,
                value_date,
                quantity,
                status,
                book.code,
                book.entity,
                ccy.code,
                counterparty.code,
                counterparty.entity,
                fee.rate,
                security.market_code,
                security.isin,
                settlement.depot,
                settlement.account,
                termed.`date`,
                collateral.margin,
                calc_market_value.amount,
                user.id,
                trade_date,
                settlement.`date`
            FROM
                {self.secfin_db}.sbl
            WHERE 
                day = %s AND 
                month = %s AND 
                year = %s AND 
                (trade_type = "BORROW" OR trade_type = "LOAN") AND 
                status != 'CLOSED'
        """
        limit: int = self.position_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result = []
        for entry in result:
            named_result.append(FoursSBLEntry(*entry))
        result = named_result

        latest_update_dict = _find_last_updates(result)
        result = _filter_on_updatetime(result, latest_update_dict)
        return result

    def get_ext_sbl_for_date(self) -> List[SBLContractEntry]:
        """SFCM ext SBL trades (i.e. borrows and loans) for specific day"""
        query_name = "get_ext_sbl_for_date"
        filter_date = str(self.date).replace("-", "")
        query = f""" 
                SELECT
                    `ref`,
                    updated_date_time,
                    trade_type,
                    value_date,
                    trade_date,
                    quantity,
                    status,
                    book.code,
                    book.entity,
                    ccy.code,
                    ccy.ref_eur_fx_rate,
                    counterparty.code,
                    counterparty.entity,
                    counterparty.ref_name,
                    counterparty.ref_country_code,
                    counterparty.ref_type,
                    fee.rate,
                    security.market_code,
                    security.isin,
                    security.ref_description,
                    security.ref_category,
                    settlement.depot,
                    settlement.account,
                    termed.`date`,
                    collateral.margin,
                    user.id,
                    calc_market_value.amount,
                    calc_market_value.ccy.code,
                    req_dividend_rate,
                    settlement.`date`,
                    original_ref,
                    security.ref_market_country_code
                FROM
                    {self.secfin_db}.sbl
                WHERE
                    (trade_type = "BORROW" OR trade_type = "LOAN")
                    AND (status = "PENDING" OR status = "SETTLED")
                    AND trade_date = "{filter_date}"
        """

        self.log.debug('Start running query "get_ext_sbl_for_date"')
        result = self._run_query(query, query_name)
        self.log.debug('Finished running query "get_ext_sbl_for_date"')

        named_result = []
        for entry in result:
            named_result.append(
                SBLContractEntry(
                    ref=entry[0],
                    updated_date_time=entry[1],
                    trade_type=entry[2],
                    value_date=entry[3],
                    trade_date=entry[4],
                    quantity=entry[5],
                    status=entry[6],
                    book_code=entry[7],
                    book_entity=entry[8],
                    ccy_code=entry[9],
                    ccy_eur_fx_rate=entry[10],
                    counterparty_code=entry[11],
                    counterparty_entity=entry[12],
                    counterparty_name=entry[13],
                    counterparty_country_code=entry[14],
                    counterparty_ref_type=entry[15],
                    fee_rate=float(entry[16]),
                    isin_market_code=entry[17],
                    isin=entry[18],
                    isin_description=entry[19],
                    isin_category=entry[20],
                    settlement_depot=entry[21],
                    settlement_account=entry[22],
                    termed_date=entry[23],
                    collateral_margin=entry[24],
                    trader=entry[25],
                    market_value=entry[26],
                    market_value_ccy=entry[27],
                    req_dividend_rate=entry[28],
                    settlement_date=entry[29],
                    original_ref=entry[30],
                    isin_market_country_code=entry[31],
                )
            )
        result = named_result

        return result

    def get_ext_sbl_by_date(self) -> List[SBLContractEntry]:
        """SFCM ext SBL trades (i.e. borrows and loans) until specific day"""
        query_name = "get_ext_sbl_by_date"
        query = f"""
                SELECT
                    `ref`,
                    updated_date_time,
                    trade_type,
                    value_date,
                    trade_date,
                    quantity,
                    status,
                    book.code,
                    book.entity,
                    ccy.code,
                    ccy.ref_eur_fx_rate,
                    counterparty.code,
                    counterparty.entity,
                    counterparty.ref_name,
                    counterparty.ref_country_code,
                    counterparty.ref_type,
                    fee.rate,
                    security.market_code,
                    security.isin,
                    security.ref_description,
                    security.ref_category,
                    settlement.depot,
                    settlement.account,
                    termed.`date`,
                    collateral.margin,
                    user.id,
                    calc_market_value.amount,
                    calc_market_value.ccy.code,
                    req_dividend_rate,
                    settlement.`date`,
                    original_ref,
                    security.ref_market_country_code
                FROM
                    {self.secfin_db}.sbl
                WHERE
                    (trade_type = "BORROW" OR trade_type = "LOAN")
                    AND day = %s
                    AND month = %s
                    AND year = %s
            """

        query = query % (self.date.day, self.date.month, self.date.year)

        self.log.debug('Start running query "get_ext_sbl_by_date"')
        result = self._run_query(query, query_name)
        self.log.debug('Finished running query "get_ext_sbl_by_date"')

        named_result = []
        for entry in result:
            named_result.append(
                SBLContractEntry(
                    ref=entry[0],
                    updated_date_time=entry[1],
                    trade_type=entry[2],
                    value_date=entry[3],
                    trade_date=entry[4],
                    quantity=entry[5],
                    status=entry[6],
                    book_code=entry[7],
                    book_entity=entry[8],
                    ccy_code=entry[9],
                    ccy_eur_fx_rate=entry[10],
                    counterparty_code=entry[11],
                    counterparty_entity=entry[12],
                    counterparty_name=entry[13],
                    counterparty_country_code=entry[14],
                    counterparty_ref_type=entry[15],
                    fee_rate=float(entry[16]),
                    isin_market_code=entry[17],
                    isin=entry[18],
                    isin_description=entry[19],
                    isin_category=entry[20],
                    settlement_depot=entry[21],
                    settlement_account=entry[22],
                    termed_date=entry[23],
                    collateral_margin=entry[24],
                    trader=entry[25],
                    market_value=entry[26],
                    market_value_ccy=entry[27],
                    req_dividend_rate=entry[28],
                    settlement_date=entry[29],
                    original_ref=entry[30],
                    isin_market_country_code=entry[31],
                )
            )
        result = named_result

        return result

    def get_non_cash_collateral_pos_by_date(self) -> List[CollateralTransactionEntry]:
        """
        This function presents a query to find all non cash collateral positions (pledges and receipts) for a specific
        date.
        """
        query_name = "get_non_cash_collateral_pos_by_date"
        query = f"""
            SELECT 
                `ref`,
                trade_type,
                datefromfilename,
                business_date,
                value_date,
                trade_date,
                quantity,
                status,
                book.code,
                book.entity,
                ccy.code,
                ccy.ref_eur_fx_rate,
                counterparty.code,
                counterparty.entity,
                counterparty.ref_name,
                security.market_code,
                security.isin,
                security.ref_description,
                security.ref_category,
                settlement.account,
                settlement.depot,
                calc_market_value.amount,
                calc_market_value.ccy.code,
                req_dividend_rate,
                security.ticker,
                haircut,
                security.ref_4s_mnemonic,
                settlement.mics_depot,
                settlement.mics_safe_keep
            FROM {self.secfin_db}.collateralposition
            WHERE (status = "PENDING" OR status = "SETTLED")
                AND day = %s
                AND month = %s
                AND year = %s
        """

        # Run query
        self_date = self.date
        self.log.debug(
            f"Start running query {query_name} on database/table {self.secfin_db}"
        )
        result = self._run_query(
            query % (self_date.day, self_date.month, self_date.year), query_name
        )
        self.log.debug(
            f"Finished running query {query_name} on database/table {self.secfin_db}"
        )

        # Format data: from query output (tuple format) create named tuple data
        named_result = []
        for entry in result:
            named_result.append(
                CollateralTransactionEntry(
                    ref=entry[0],
                    trade_type=entry[1],
                    date_from_filename=entry[2].strftime("%Y-%m-%d, %H:%M:%S"),
                    business_date=entry[3],
                    value_date=entry[4],
                    trade_date=entry[5],
                    quantity=entry[6],
                    status=entry[7],
                    book_code=entry[8],
                    book_entity=entry[9],
                    ccy_code=entry[10],
                    ccy_ref_eur_fx_rate=entry[11],
                    counterparty_code=entry[12],
                    counterparty_entity=entry[13],
                    counterparty_refname=entry[14],
                    security_market_code=entry[15],
                    security_isin=entry[16],
                    security_ref_description=entry[17],
                    security_ref_category=entry[18],
                    settlement_account=entry[19],
                    settlement_depot=entry[20],
                    calc_market_value_amount=entry[21],
                    calc_market_value_ccy_code=entry[22],
                    req_dividend_rate=entry[23],
                    ticker=entry[24],
                    haircut=entry[25],
                    fours_mnemonic=entry[26],
                    mics_depot=entry[27],
                    mics_safekeep=entry[28],
                )
            )

        result = named_result

        return result

    @staticmethod
    def get_market_area_string(market_country_code):
        market_area_prefixes = translate_country_to_market_area_prefix(
            market_country_code
        )

        query_segments = []
        for market_area_prefix in market_area_prefixes:
            query_segment = f"market_area like {market_area_prefix}"
            query_segments.append(query_segment)

        market_area_string = "(" + " OR ".join(query_segments) + ")"
        return market_area_string

    def get_all_rates(self) -> List[BenchmarkRate]:
        query_name = "get_all_rates"

        x = 0

        filter_date = self.date
        typed_results = []
        while x < self.rates_limit and len(typed_results) == 0:
            filter_date_str = filter_date.strftime("%Y-%m-%d")
            query = f"""
                SELECT
                    dxl_identifier,
                    isin,
                    market_area,
                    tradable_fee,
                    year,
                    month,
                    day,
                    datefromfilename,
                    'equity',
                    'early'
                FROM
                    {self.secfin_db}.markit_eqtyearly
                WHERE
                    tradable_fee is not NULL
                    AND datefromfilename = "{filter_date_str}" AND 
                    year = {filter_date.year} AND month = {filter_date.month} AND day = {filter_date.day}

                UNION ALL

                SELECT
                    dxl_identifier,
                    isin,
                    market_area,
                    tradable_fee,
                    year,
                    month,
                    day,
                    datefromfilename,
                    'bond',
                    'early'
                FROM
                    {self.secfin_db}.markit_bondearly
                WHERE
                    tradable_fee is not NULL
                    AND datefromfilename = "{filter_date_str}" AND 
                    year = {filter_date.year} AND month = {filter_date.month} AND day = {filter_date.day}

                UNION ALL

                SELECT
                    dxl_identifier,
                    isin,
                    market_area,
                    tradable_fee,
                    year,
                    month,
                    day,
                    datefromfilename,
                    'equity',
                    'final'
                FROM
                    {self.secfin_db}.markit_eqtyfinal
                WHERE
                    tradable_fee is not NULL
                    AND datefromfilename = "{filter_date_str}" AND 
                    year = {filter_date.year} AND month = {filter_date.month} AND day = {filter_date.day}

                UNION ALL

                SELECT
                    dxl_identifier,
                    isin,
                    market_area,
                    tradable_fee,
                    year,
                    month,
                    day,
                    datefromfilename,
                    'bond',
                    'final'
                FROM
                    {self.secfin_db}.markit_bondfinal
                WHERE
                    tradable_fee is not NULL
                    AND datefromfilename = "{filter_date_str}" AND 
                    year = {filter_date.year} AND month = {filter_date.month} AND day = {filter_date.day}
            """

            results = self._run_query(query, query_name)
            if results is None:
                filter_date = previous_business_day(filter_date)
                x += 1
                continue
            typed_results = []
            for result in results:
                typed_results.append(BenchmarkRate(*result))

            if self.accept_empty_results:
                break
            elif len(typed_results) == 0:
                filter_date = previous_business_day(filter_date)
                x += 1

        if x > 0:
            self.log.warn(
                f"The retrieved and utilized {query_name} data is more than one business day old. "
                f"Data was retrieved from {filter_date.strftime('%Y-%m-%d')}."
            )
        return typed_results

    def count_bond_rates_for_date(self) -> int:
        query_name = "count_bond_rates_for_date"
        query = f"""
                SELECT COUNT(*)
                FROM {self.secfin_db}.markit_bondearly
                WHERE datefromfilename = '{self.date.strftime("%Y-%m-%d")}'
            """

        result = self._run_query(query, query_name)
        if result is None:
            raise ConnectionError("Could not execute SQL command, check connection.")
        return result[0][0]

    def count_equity_rates_for_date(self) -> int:
        query_name = "count_equity_rates_for_date"
        query = f"""
                SELECT COUNT(*)
                FROM {self.secfin_db}.markit_eqtyearly
                WHERE datefromfilename = '{self.date.strftime("%Y-%m-%d")}'
            """

        result = self._run_query(query, query_name)
        if result is None:
            raise ConnectionError("Could not execute SQL command, check connection.")
        return result[0][0]

    def get_pending_sbl_returns(self) -> List[FoursSBLReturnExtendedEntry]:
        """Get SFCM pending sbl returns. Only check database for one specified date."""
        query_name = "get_pending_sbl_returns"
        query = f"""
            SELECT
                sbl.`ref`,
                sbl.original_ref,
                updated_date_time,
                pending_return.`ref`,
                pending_return.original_ref,
                pending_return.quantity,
                pending_return.value_date,
                pending_return.recall,
                pending_return.calc_market_value.amount,
                pending_return.user.id,
                pending_return.trade_date
            FROM
                {self.secfin_db}.sbl,
                sbl.pending_return
            WHERE
                day = %s AND 
                month = %s AND 
                year = %s AND 
                (trade_type = "BORROW" OR trade_type = "LOAN")
        """
        self_date = self.date
        self.log.debug('Start running query "get_pending_sbl_returns" ')
        result = self._run_query(
            query % (self_date.day, self_date.month, self_date.year), query_name
        )
        self.log.debug('Finished running query "get_pending_sbl_returns" ')

        named_result = []
        for entry in result:
            named_result.append(
                FoursSBLReturnExtendedEntry(
                    ref=entry[0],
                    original_ref=entry[1],
                    updated_date_time=entry[2],
                    return_ref=entry[3],
                    return_original_ref=entry[4],
                    quantity=entry[5],
                    value_date=entry[6],
                    recall=entry[7],
                    calc_market_value_amount=entry[8],
                    trader_id=entry[9],
                    trade_date=entry[10],
                )
            )
        result = named_result

        return result

    def get_4s_pending_sbl_returns_all(self) -> List[FoursSBLReturnEntry]:
        """Get SFCM pending returns. Search back option enabled: Executes a given query, and keeps running the query
        for earlier days until either a result has been found, or the limit for the amount of days has been reached."""
        query_name = "4s pending sbl returns all"
        query = f"""
            SELECT
                sbl.`ref`,
                updated_date_time,
                pending_return.`ref`,
                pending_return.quantity,
                pending_return.value_date,
                pending_return.recall,
                pending_return.calc_market_value.amount,
                pending_return.trade_date
            FROM
                {self.secfin_db}.sbl,
                sbl.pending_return
            WHERE
                day = %s AND 
                month = %s AND 
                year = %s AND 
                (trade_type = "BORROW" OR trade_type = "LOAN") AND 
                status != 'CLOSED'
        """
        limit: int = self.position_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result = []
        for entry in result:
            named_result.append(FoursSBLReturnEntry(*entry))
        result = named_result

        latest_update_dict = _find_last_updates(result, ref_variable="return_ref")
        result = _filter_on_updatetime(
            result, latest_update_dict, ref_variable="return_ref"
        )
        return result

    def get_isins_for_countries_all(self) -> List[IsinCountryPair]:
        query_name = "Instruments-country combinations"
        query = f"""
            SELECT
                isin,
                ref_market_country_code 
            FROM
                {self.secfin_db}.instruments
            WHERE 
                day = %s AND 
                month = %s AND 
                year = %s
        """
        limit: int = self.refdata_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result = []
        for entry in result:
            named_result.append(IsinCountryPair(*entry))
        result = named_result

        filtered_result = []
        for row in result:
            if row.isin is not None and row.country is not None:
                filtered_result.append(row)
        result: List[IsinCountryPair] = filtered_result
        return result

    def price_checker_get_sbl(self) -> List[PriceCheckerSFEntry]:
        query_name = "price checker sbl"
        query = f"""
            SELECT
                security.isin,
                security.market_code,
                calc_market_value.amount,
                calc_market_value.ccy.code,
                quantity, 
                status
            FROM
                {self.secfin_db}.sbl
            WHERE
                day = %s AND
                month = %s AND
                year = %s
        """
        limit: int = self.position_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[PriceCheckerSFEntry] = []
        for entry in result:
            named_result.append(PriceCheckerSFEntry(*entry))

        return named_result

    def price_checker_get_collateral(self) -> List[PriceCheckerSFEntry]:
        query_name = "price checker collateral"
        query = f"""
            SELECT
                security.isin,
                security.market_code,
                calc_market_value.amount,
                calc_market_value.ccy.code,
                quantity, 
                status
            FROM
                {self.secfin_db}.collateralposition
            WHERE
                day = %s AND
                month = %s AND
                year = %s
        """
        limit: int = self.position_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[PriceCheckerSFEntry] = []
        for entry in result:
            named_result.append(PriceCheckerSFEntry(*entry))

        return named_result

    def price_checker_get_mics_p(self) -> List[PriceCheckerOREntry]:
        query_name = "price checker mics pending"
        query = f"""
            SELECT
                isin,
                safe_keeping_id,
                effective_value,
                currency_code,
                quantity
            FROM
                {self.micsce_db}.pending_position
            WHERE
                day = %s AND
                month = %s AND
                year = %s
        """
        limit: int = self.position_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[PriceCheckerOREntry] = []
        for entry in result:
            named_result.append(PriceCheckerOREntry(*entry))

        return named_result

    def get_kafka_sbl_all(self) -> List[FoursSBLEntry]:
        query_name = "kafka sbl"
        query = f"""
            SELECT 
                kafkadetails.`timestamp`,
                `ref`,
                date_time,
                trade_type,
                value_date,
                quantity,
                status,
                book.code,
                book.entity,
                ccy.code,
                counterparty.code,
                counterparty.entity,
                fee.rate,
                security.market_code,
                security.isin,
                settlement.depot,
                settlement.account,
                termed.`date`,
                collateral.margin,
                calc_market_value.amount,
                user.id,
                trade_date,
                settlement.`date`
            FROM
                secfin.kafkaraw_sbltradeupdate
            WHERE 
                day = %s AND 
                month = %s AND 
                year = %s AND 
                (trade_type = "BORROW" OR trade_type = "LOAN")
        """
        limit: int = self.kafka_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result = []
        date_timestamp = self.date.timestamp() * 1000
        for entry in result:
            entry = [elem for elem in entry]  # convert to list
            timestamp = entry.pop(0)
            if timestamp < date_timestamp:
                named_result.append(FoursSBLEntry(*entry))
        result = named_result

        latest_update_dict = _find_last_updates(result)
        result = _filter_on_updatetime(result, latest_update_dict)
        return result

    def get_kafka_pending_sbl_returns_all(self) -> List[FoursSBLReturnEntry]:
        query_name = "kafka pending sbl returns"
        query = f"""
            SELECT
                kafkadetails.`timestamp`,
                kafkaraw_sbltradeupdate.`ref`,
                date_time,
                pending_return.`ref`,
                pending_return.quantity,
                pending_return.value_date,
                pending_return.recall,
                pending_return.calc_market_value.amount,
                pending_return.trade_date
            FROM
                secfin.kafkaraw_sbltradeupdate,
                kafkaraw_sbltradeupdate.pending_return
            WHERE
                day = %s AND 
                month = %s AND 
                year = %s AND 
                (trade_type = "BORROW" OR trade_type = "LOAN")
        """
        limit: int = self.kafka_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result = []
        date_timestamp = self.date.timestamp() * 1000
        for entry in result:
            entry = [elem for elem in entry]  # convert to list
            timestamp = entry.pop(0)
            if timestamp < date_timestamp:
                named_result.append(FoursSBLReturnEntry(*entry))
        result = named_result

        latest_update_dict = _find_last_updates(result, ref_variable="return_ref")
        result = _filter_on_updatetime(
            result, latest_update_dict, ref_variable="return_ref"
        )
        return result

    def get_kafka_collateral_all(self) -> List[FoursCollateralEntry]:
        query_name = "kafka collateral"
        query = f"""
            SELECT 
                kafkadetails.`timestamp`,
                `ref`,
                trade_type,
                value_date,
                quantity,
                status,
                book.code,
                book.entity,
                calc_market_value.ccy.code,
                counterparty.code,
                counterparty.entity,
                security.market_code,
                security.isin,
                settlement.depot,
                settlement.account,
                calc_market_value.amount,
                user.id,
                settlement.`date`,
                trade_date
            FROM
                secfin.kafkaraw_collateraltradeupdate
            WHERE 
                day = %s AND 
                month = %s AND 
                year = %s  AND 
                NOT (trade_type = "BORROW" OR trade_type = "LOAN")
        """
        limit: int = self.kafka_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[FoursCollateralEntry] = []
        date_timestamp = self.date.timestamp() * 1000
        for entry in result:
            entry = [elem for elem in entry]  # convert to list
            timestamp = entry.pop(0)
            if timestamp < date_timestamp:
                named_result.append(FoursCollateralEntry(*entry))
        result = named_result

        return result

    def get_client_holdings(self) -> List[HoldingPosition]:
        query_name = "Client holdings"
        query = f"""
            SELECT
                holding_number, 
                holding_name
            FROM
                {self.micsce_db}.holding
            WHERE
                day = %s AND 
                month = %s AND 
                year = %s
        """
        limit: int = self.refdata_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[HoldingPosition] = []
        for entry in result:
            named_result.append(HoldingPosition(*entry))

        return named_result

    def get_unvalued_cash_transactions(self) -> List[CashTitlePosition]:
        query_name = "get_unvalued_cash_transactions"
        year_limit = self.date.year - 2
        query = f"""
            SELECT
                client_number,
                journal_entry_amount,
                journal_entry_amount_d_c,
                currency_code,
                journal_account_code
            FROM
                {self.micsce_db}.yearly_proc_money_mov
            WHERE
                value_date > "{self.date.strftime("%Y-%m-%d")}" AND 
                business_date <= "{self.date.strftime("%Y-%m-%d")}" AND
                year > {year_limit} AND 
                "{self.date.strftime("%Y%m%d")}" <= concat(cast(year as STRING), cast(month as STRING), cast(day as STRING))
        """
        result = self._run_query(query, query_name)

        named_result: List[CashTitlePosition] = []
        for entry in result:
            named_result.append(CashTitlePosition(*entry))

        return named_result

    def get_journal_codes(self) -> List[JournalCodeTuple]:
        query_name = "Journal codes"
        query = f"""
            SELECT
                journal_account_code, 
                journal_account_descr,
                gross_position_indicator
            FROM
                {self.micsce_db}.journal_accounts
            WHERE
                day = %s AND 
                month = %s AND 
                year = %s
        """
        limit: int = self.refdata_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[JournalCodeTuple] = []
        for entry in result:
            named_result.append(JournalCodeTuple(*entry))

        return named_result

    def get_clients(self) -> List[ClientEntry]:
        # Database differs based on environment
        query_name = "client refdata"
        query = f"""
            SELECT
                client_number,
                client_name,
                holding_number,
                active_ind
            FROM
                {self.micsce_db}.client
            WHERE
                day = %s AND
                month = %s AND
                year = %s
        """
        limit = self.refdata_limit

        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[ClientEntry] = []
        for entry in result:
            named_result.append(ClientEntry(*entry))

        return named_result

    def get_holdings(self) -> List[HoldingEntry]:
        # Database differs based on environment
        query_name = "holding refdata"
        query = f"""
            SELECT
                holding_number, 
                holding_name
            FROM
                {self.micsce_db}.holding
            WHERE
                day = %s AND
                month = %s AND
                year = %s
        """
        limit = self.refdata_limit

        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[HoldingEntry] = []
        for entry in result:
            named_result.append(HoldingEntry(*entry))

        return named_result

    def get_cash_title_positions(self) -> List[CashTitlePosition]:
        # Database differs based on environment
        if self.env == "PROD":
            database = "micsce"
        else:
            database = "micsceprd"

        query_name = "cash title position"
        query = f"""
            SELECT
                client_number,
                cash_title_position,
                cash_title_position_d_c,
                currency_code,
                journal_account_code
            FROM
                {database}.subaccount_cash_title_position 
            WHERE
                day = %s AND
                month = %s AND
                year = %s
        """
        limit: int = self.position_limit

        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[CashTitlePosition] = []
        for entry in result:
            named_result.append(CashTitlePosition(*entry))

        return named_result

    def get_cash_title_validity_starting_date(self) -> Tuple[int, date]:
        # Database differs based on environment
        query_name = "get_cash_title_validity_starting_date"
        query = f"""
            SELECT 
                MAX(validity_starting_date)
            FROM
                {self.micsce_db}.price
            WHERE
                day = %s AND
                month = %s AND
                year = %s
        """
        result, result_date = self._run_query_with_lookback(
            query_name, query, self.refdata_limit
        )
        if len(result) > 0:
            return result[0][0], result_date
        else:
            raise ConnectionError(
                f"Could not retrieve the validity starting date for {self.date.year}-{self.date.month}-{self.date.day}"
            )

    def get_cash_product_valuations(self) -> List[CashProductValuation]:
        query_name = "get_cash_product_valuations"
        validity_starting_date, from_date = self.get_cash_title_validity_starting_date()

        if validity_starting_date is None:
            self.log.warn("No validity starting  date available")
            return []

        query = f"""
            SELECT
                DISTINCT {self.micsce_db}.price.`symbol`,
                {self.micsce_db}.price.valuation_price,
                {self.micsce_db}.product.pricing_unit
            FROM {self.micsce_db}.product 
                JOIN {self.micsce_db}.price 
                ON {self.micsce_db}.product.`symbol` = {self.micsce_db}.price.`symbol` AND
                    {self.micsce_db}.product.product_group_code = {self.micsce_db}.price.product_group_code
            WHERE
                product.product_group_code = 'CU' AND
                {self.micsce_db}.price.validity_starting_date = {validity_starting_date} AND
                {self.micsce_db}.price.day = {from_date.day} AND 
                {self.micsce_db}.product.day = {from_date.day} AND
                {self.micsce_db}.price.month = {from_date.month} AND 
                {self.micsce_db}.product.month = {from_date.month} AND
                {self.micsce_db}.price.year = {from_date.year} AND 
                {self.micsce_db}.product.year = {from_date.year}
        """
        result = self._run_query(query, query_name)
        if result is None:
            raise ConnectionError("Could not execute SQL command, check connection.")

        named_result: List[CashProductValuation] = []
        for entry in result:
            named_result.append(CashProductValuation(*entry))
        return named_result

    def get_kafka_con_transaction(self):
        query_name = "kafka con transaction"
        query = f"""
            SELECT
                header.`timestamp`,
                contransaction.cantransaction.investment.globalinstrumentid.instrumentidvalue,
                contransaction.cantransaction.contractualsettlementdate,
                contransaction.cantrade.tradevalue.`primary`.value,
                contransaction.cantrade.tradevalue.`primary`.currency,
                contransaction.cantransaction.quantitylong,
                contransaction.cantransaction.quantityshort,
                contransaction.cansettlement.party.counterparty.partyid,
                contransaction.cantransaction.party.placeofsafekeeping.partycountry,
                contransaction.cantransaction.clientaccinfo.clientlevel1,
                contransaction.cantransaction.clientaccinfo.clientlevel2,
                contransaction.cantransaction.clientaccinfo.clientlevel3,
                contransaction.cantransaction.clientaccinfo.account,
                contransaction.cantransaction.transactiontype
            FROM
                secfin.grip_contransaction
            WHERE
                contransaction.cantransaction.investment.globalinstrumentid.instrumentidtype = "ISIN" AND
                (contransaction.cantransaction.transactiontype = "TRADE" OR 
                 contransaction.cantransaction.transactiontype = "SETTLEMENT") AND
                day = %s AND
                month = %s AND
                year = %s
        """  # TODO find proper partyid reference, only set to cansettlement one to get it to run.
        limit: int = self.kafka_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        filtered_result = []
        date_timestamp = self.date.timestamp() * 1000
        for entry in result:
            entry = [elem for elem in entry]  # convert to list
            timestamp = entry.pop(0)
            if timestamp < date_timestamp:
                filtered_result.append(entry)

        return filtered_result

    def get_latest_position_date(self) -> date:
        """
        Checks all transaction tables for the date of latest available data. Returns the earliest of these.
        :return: the earliest date found
        """
        query_name = "latest position date"
        query1 = f"""SELECT DISTINCT year, month, day FROM {self.secfin_db}.sbl
                        ORDER BY year desc, month desc, day desc LIMIT 1"""
        query2 = f"""SELECT DISTINCT year, month, day FROM {self.secfin_db}.collateralposition 
                        ORDER BY year desc, month desc, day desc LIMIT 1"""
        query3 = f"""SELECT DISTINCT year, month, day FROM {self.micsce_db}.settled_position 
                        ORDER BY year desc, month desc, day desc LIMIT 1"""
        query4 = f"""SELECT DISTINCT year, month, day FROM {self.micsce_db}.pending_position
                        ORDER BY year desc, month desc, day desc LIMIT 1"""
        query_list = [query1, query2, query3, query4]
        furthest_date = None
        for query in query_list:
            result = self._run_query(query, query_name)
            if len(result) != 0:
                result_date = date(
                    year=result[0][0], month=result[0][1], day=result[0][2]
                )
                if furthest_date is None or furthest_date > result_date:
                    furthest_date = result_date
        return furthest_date

    def get_isin_conversion_data(self, rolling_window_period: int) -> List[SPMConversionQResultTuple]:
        """
        Requests data from spm table to retrieve the data from which isin conversions (etf only) can be retrieved.
        :param rolling_window_period the rolling window of historic data to be taken into account in weeks
        :return - A list of tuples, each representing a row in the spm table
        """
        if self.env == "PROD":
            database = "spm"
        else:
            database = "spmprd"

        rolling_window_start_date = int((self.date - timedelta(weeks=rolling_window_period)).strftime("%Y%m%d"))
        rolling_window_end_date = int(self.date.strftime("%Y%m%d"))
        query_name = "spm adr_con_parent get_isin_conversion_data"
        query = f'''
            SELECT
                isin_from,
                depot_id_from,
                safekeeping_id_from,
                isin_to,
                depot_id_to,
                safekeeping_id_to
            FROM
                {self.spm_db}.adr_con_parent
            WHERE
                {rolling_window_start_date} <= generation_date
                AND generation_date <= {rolling_window_end_date}
                AND bancs_status_description = "Settled" 
                AND mics_client_account_from = "7777-TRAD-1-1"
                AND broker = "SPCONV"            
        '''

        self.log.debug('Start running query "get_isin_conversion_data"')
        result = self._run_query(query=query, query_name=query_name)
        self.log.debug('Finished running query "get_isin_conversion_data"')

        named_result: List[SPMConversionQResultTuple] = []
        for entry in result:
            named_result.append(SPMConversionQResultTuple(*entry))
        result = named_result
        return result

    def get_depot_switches_data(self, rolling_window_period: int) -> List[SPMDepotSwitchQResultTuple]:
        """
        Requests data from spm table to retrieve the data from which depot switched can be retrieved.
        :param rolling_window_period the rolling window of historic data to be taken into account in weeks
        :return - A list of tuples, each representing a row in the spm table
        """
        rolling_window_start_date = int((self.date - timedelta(weeks=rolling_window_period)).strftime("%Y%m%d"))
        rolling_window_end_date = int(self.date.strftime("%Y%m%d"))
        query_name = "spm depot_switch_parent get_depot_switches_data"
        query = f'''
            SELECT
                isin,
                depot_id_from,
                safekeeping_id_from,
                depot_id_to,
                safekeeping_id_to
            FROM
                {self.spm_db}.depot_switch_parent
            WHERE
                {rolling_window_start_date} <= generation_date
                AND generation_date <= {rolling_window_end_date}
                AND bancs_status_description = "Settled" 
                AND mics_client_account_from = "7777-TRAD-1-1"
        '''

        self.log.debug('Start running query "get_depot_switches_data"')
        result = self._run_query(query=query, query_name=query_name)
        self.log.debug('Finished running query "get_depot_switches_data"')

        named_result: List[SPMDepotSwitchQResultTuple] = []
        for entry in result:
            named_result.append(SPMDepotSwitchQResultTuple(*entry))
        result = named_result
        return result

    def get_swift_payments_data_test(self) -> List[SwiftPaymentsTestQResultTuple]:
        """
        Requests data from swift payments table to check if access to this table has been granted.
        Once confirmed access has been granted this query can be removed.
        TODO: removing query after checking was successful
        :return - A list of tuples, each representing a row in the spm table
        """
        query_name = "payments table swift_payments_msgtype950"
        query = f"""
            SELECT
                destinationaddress, 
                rawmessage, 
                receiverdate, 
                senderaddress
            FROM
                {self.payments_db}.swift_payments_msgtype950
            WHERE
                day = %s AND
                month = %s AND
                year = %s
        """
        limit: int = self.refdata_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[SwiftPaymentsTestQResultTuple] = []
        for entry in result:
            named_result.append(SwiftPaymentsTestQResultTuple(*entry))
        result = named_result
        return result

    def get_margin_gross_balance(self) -> List[MarginGrossBalance]:
        # Database differs based on environment
        query_name = 'margin_gross'
        query = f'''
            SELECT
                client_number,
                holding_number,
                account_type, 
                account_number,
                subaccount_number, 
                clearing_entity, 
                opposite_party_code, 
                gross_balance_amount, 
                gross_balance_amount_d_c, 
                currency_code, 
                value_date,
                last_movement_date
            FROM
                {self.micsce_db}.margin_gross_balance 
            WHERE
                day = %s AND
                month = %s AND
                year = %s
        '''
        limit: int = self.refdata_limit

        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        named_result: List[MarginGrossBalance] = []
        for entry in result:
            named_result.append(MarginGrossBalance(*entry))

        return named_result

    def get_query_markit_early(self, isin, mic_code, country_code) -> List[SyntheticData]:
        """
        Requests synthetics data from markit_eqtyearly table
        :return - synthetics data
        """
        query_name = f"get_query_markit_early with ISIN:{isin},MIC_CODE:{mic_code},COUNTRY_CODE:{country_code}"
        query = f"""
                   SELECT isin as ISIN, substring(market_area,1,2) as COUNTRY_CODE,
                   '{mic_code}' as MIC_CODE,
                   active_available_quantity as AVAILABILITY,tradable_fee as RATE,
                   '{self.get_average_for_particular_isin(isin, country_code)}' as AVERAGE
                   FROM {self.secfin_db}.markit_eqtyearly 
                   WHERE
                       day = %s AND
                       month = %s AND
                       year = %s
                       and isin = '{isin}'
                       and substring(market_area,1,2) = '{country_code}'
                       AND record_type =1          
               """
        print(f"running {query}")
        limit: int = 1
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        synthetics_data: List[SyntheticData] = []
        if result is None or len(result)==0:
            synthetics_data.append(
                SyntheticData(
                    ISIN=isin,
                    COUNTRY_CODE=country_code,
                    MIC_CODE=mic_code,
                    AVAILABILITY='',
                    RATE='',
                    AVERAGE=''
                ))
            result = synthetics_data
            return result[0]

        for rows in result:
            synthetics_data.append(
                SyntheticData(
                    ISIN=rows[0],
                    COUNTRY_CODE=rows[1],
                    MIC_CODE=rows[2],
                    AVAILABILITY=rows[3],
                    RATE=rows[4],
                    AVERAGE=rows[5]
                )
            )
        result = synthetics_data
        return result[0]

    def get_average_for_particular_isin(self, isin: str, country_code: str) -> any:
        """
        This method is to populate our SHARK market rates, using the IHS benchmark rate (With adjustments)
        :param - isin for which average would be calculated
        :param - country code against which isin is specified
        :return - A list of tuples, each representing a row in the spm table
        """
        start_date = (self.date - timedelta(days=1)).strftime("%Y-%m-%d")
        end_date = get_previous_business_days(10, self.date).strftime("%Y-%m-%d")
        query_name = "get_average_for_particular_isin"
        query = f"""
                    SELECT
                     sum(t.active_available_quantity)/10
                    FROM
                     (SELECT  isin, tradable_fee, active_available_quantity,datefromfilename 
                    FROM 
                     {self.secfin_db}.markit_eqtyearly
                    WHERE
                     isin = '{isin}' and substring(market_area,1,2) = '{country_code}'
                     and record_type =1
                     and datefromfilename BETWEEN  '{end_date}' and '{start_date}'
                     ORDER BY datefromfilename DESC) as t;
                """
        print(query)
        result = self._run_query(query, query_name)
        if result is None:
            raise ConnectionError("Could not execute SQL command, check connection.")
        return result[0][0]

    def get_early_equity_market_rates(self) -> List[SharkAPIFeedingTuple]:
        """
        This method is to populate our SHARK market rates, using the IHS benchmark rate (With adjustments)
        :param -
        :return - A list of tuples, each representing a row in the spm table
        """
        query_name = "get_early_equity_market_rates"
        query = f"""
                       SELECT
                           isin as SecID,
                           tradable_fee as RebateRate,
                           substring(market_area,1,2) as ZoneCode

                       FROM
                           {self.secfin_db}.markit_eqtyearly
                       WHERE
                           day = %s AND
                           month = %s AND
                           year = %s AND
                           record_type = 1
                   """
        limit: int = self.shark_limit
        result, sel_date = self._run_query_with_lookback(query_name, query, limit)

        rate_items: List[SharkAPIFeedingTuple] = []
        for rows in result:
            rate_items.append(SharkAPIFeedingTuple(*rows))
        result = rate_items
        return result

    def get_hk_unsettled_positions(self) -> List[UnsettledPosition]:
        query_name = "get_hk_unsettled"
        query = f"""
            SELECT
                isin,
                buy_sell_code,
                settlement_date,
                exchange_code,
                currency_code,
                opposite_party_code,
                quantity,
                client_number
            FROM {self.micsap_hk_db}.unsettled_position_detail
            WHERE 
                day = %s AND
                month = %s AND
                year = %s AND
                effective_value <> 0 AND
                currency_code IN ('HKD','USD','CNH') AND
                settlement_date IS NOT NULL
        """

        result, result_date = self._run_query_with_lookback(query_name, query, self.hk_limit)
        if result is None:
            raise ConnectionError("Could not execute SQL command, check connection.")

        unsettled_equities: List[UnsettledPosition] = []
        for rows in result:
            unsettled_equities.append(
                UnsettledPosition(
                    isin=rows[0],
                    buy_sell_code=rows[1],
                    settlement_date=rows[2],
                    exchange=rows[3],
                    currency_code=rows[4],
                    opposite_party=rows[5],
                    quantity=rows[6],
                    client_number=rows[7]
                )
            )
        result = unsettled_equities
        return result


def _find_last_updates(
        sbl_trades: Union[
            List[FoursSBLEntry],
            List[FoursSBLReturnExtendedEntry],
            List[FoursSBLReturnEntry],
            List[SBLContractEntry],
        ],
        ref_variable: str = "ref",
) -> Dict[str, str]:
    """
    Finds the last update time for each transaction.
    :param sbl_trades - The list of trades to find update times for.
    :return latest_update_dict - A dictionary with the keys being the refs for transactions, and the value being the
    latest update time.
    """
    latest_update_dict = {}

    for sbl_trade in sbl_trades:
        ref = getattr(sbl_trade, ref_variable)
        update_time = sbl_trade.updated_date_time

        if latest_update_dict.get(ref) is None:
            latest_update_dict[ref] = update_time
        old_update_time = latest_update_dict[ref]
        latest_update_dict[ref] = max(old_update_time, update_time)

    return latest_update_dict


def _find_earliest_updates(
        sbl_trades: Union[
            List[FoursSBLEntry], List[FoursSBLReturnEntry], List[SBLContractEntry]
        ]
) -> Dict[str, str]:
    earliest_update_dict = {}

    for sbl_trade in sbl_trades:
        ref = sbl_trade[0]
        update_time = sbl_trade[1]

        if earliest_update_dict.get(ref) is None:
            earliest_update_dict[ref] = update_time
        old_update_time = earliest_update_dict[ref]
        earliest_update_dict[ref] = min(old_update_time, update_time)

    return earliest_update_dict


def _filter_on_updatetime(
        query_result: Union[
            List[FoursSBLEntry],
            List[FoursSBLReturnExtendedEntry],
            List[FoursSBLReturnEntry],
            List[SBLContractEntry],
        ],
        update_dict: Dict[str, str],
        ref_variable: str = "ref",
) -> Union[
    List[FoursSBLEntry],
    List[FoursSBLReturnExtendedEntry],
    List[FoursSBLReturnEntry],
    List[SBLContractEntry],
]:
    """
    Filters all transactions that are not the latest transaction with that ref.
    :param query_result - The list of transactions
    :param update_dict - A dictionary containing the latest update time for each ref.
    """
    filtered = []
    did_ref = (
        set()
    )  # For cases where you have multiple versions with the exact same update time. Happens on UAT,
    # occasionally.

    for row in query_result:
        ref = getattr(row, ref_variable)
        if ref not in did_ref and update_dict.get(ref) == row.updated_date_time:
            filtered.append(row)
            did_ref.add(ref)
    return filtered
import datetime
import os.path
import win32com.client as win32
import pandas as pd
import mifid.config as cfg
from alive_progress import alive_bar


def send_email(subject: str,content: str,attachment=None) -> any:
    """
    This is a function use to send error email with failure message
    @param subject: subject of email to send
    @param content: mail body
    @param attachment: if required attach attachment
    @return: send the email
    """
    recepient = "Souvik.Ghosh@abnamroclearing.com"
    connection_reference = win32.Dispatch('Outlook.Application')
    connection_reference_mail_item = 0x0
    newmail = connection_reference.CreateItem(connection_reference_mail_item)
    newmail.Subject = subject
    newmail.To = recepient
    newmail.Body = content
    # newmail.Attachments.Add(attachment)
    return newmail.Send()

def check_exchange(filename: str,dataframe: pd.DataFrame,exchange: any) -> bool:
    """
    Function to check whether all exchanges present in a file is same,
    if not send email with duplicates values
    @param filename:file to compare with
    @param dataframe:after reading the file in dataframe pass only the column for which unique value needed to confirm
    @param exchange:the value against which uniqueness will be measured
    @return:boolean
    """
    a = dataframe.to_numpy()
    if (exchange == a).all():
        print("True")
        return True
    else:
        all_exchanges = dataframe.unique()
        other_exchanges = [i for i in all_exchanges if i!= exchange]
        subject = f"{filename} is not eligible for further processing"
        content = f"This file contains other exchanges like {other_exchanges} other than {exchange}"
        print(f"This file contains other exchanges like {other_exchanges} other than {exchange}")
        send_email(subject, content)
        return False

def check_participants_code(filename: str,dataframe:pd.DataFrame,participant_code: any) -> bool:
    """
      Function to check whether all participant code present in a file is same,
      if not send email with duplicates values
      @param filename:file to compare with
      @param dataframe:after reading the file in dataframe pass only the column for which unique value needed to confirm
      @param participant_code:the value against which uniqueness will be measured
      @return:boolean
      """
    a = dataframe.to_numpy()
    if (participant_code == a).all():
        print("True")
        return True
    else:
        all_participants_code = dataframe.unique()
        other_participants_code = [i for i in all_participants_code if i != participant_code]
        subject = f"{filename} is not eligible for further processing"
        content = f"This file contains other participant_code like {other_participants_code} other than {participant_code}"
        print(f"This file contains other participant_code like {other_participants_code} other than {participant_code}")
        send_email(subject, content)
        return False

def control_transaction_type(dataframe,transaction_type):
    """
    Function to check whether all transaction type present in a file is same,
    if not send email with duplicates values
    @param dataframe:after reading the file in dataframe pass only the column for which unique value needed to confirm
    @param transaction_type:the value against which uniqueness will be measured
    @return:boolean value with error content
    """
    a = dataframe.to_numpy()
    if (transaction_type == a).all():
        return {'bool':'True','error':''}
    else:
        all_transaction_type = dataframe.unique()
        other_transaction_type= [i for i in all_transaction_type if i!= transaction_type]
        subject = "Trade file contains value other than 'Trades'"
        content = f"This file contains other transaction_type like {other_transaction_type} other than {transaction_type}"
        send_email(subject, content)
        return {'bool':'False','error':content}

def mifid_XTKS(input_trade_source_file: str,input_fixed_width_file: str)-> any:
    """
    Script to produce trade file
    @param input_trade_source_file: input source trade file
    @param input_fixed_width_file: input combined fixed width file
    @return: output trade file
    """

    # Reading Source Trade File Which is in csv format to Dataframe
    source_trade_file_dataframe = pd.read_csv(input_trade_source_file)
    print (f"{input_trade_source_file} has {len(source_trade_file_dataframe)} records")

    # Validate the Input Source Trade file if that contains Exchange 1 and Participant 12479
    # If not Report the new value and exit
    if check_exchange(input_trade_source_file,source_trade_file_dataframe['Exchange|S:1'],1) and \
            check_participants_code(input_trade_source_file,source_trade_file_dataframe['Participant|S:5'],12479):
        print("*****************************")
        print("This file is eligible for further processing as it has all exchanges and participants 1 and 12479 respectively")
        source_trade_file_dataframe['Side|C:1'] = source_trade_file_dataframe['Side|C:1'].apply( lambda x: 'S' if x == 1 else ('B' if x == 3 else x))

        # Filter desired columns from Source file to build output Trade file
        source_trade_file_dataframe_with_desired_column = source_trade_file_dataframe[['Exchange|S:1','Participant|S:5','ExecNo|S:8','IssueCode|S:12','Side|C:1','DataType|S','TransactDate|D','ExecPrice|N:8.4','ExecQty|N:13','TransactTime(UTC)|T']].copy()

        # Renaming the column names
        source_trade_file_dataframe_with_desired_column.rename(columns={'Participant|S:5':'Membership code','ExecNo|S:8':'External Id 1','IssueCode|S:12':'Instrument','Side|C:1':'Buy/sell','DataType|S':'Transaction type','TransactDate|D':'Trade date','ExecPrice|N:8.4':'Price','ExecQty|N:13':'Quantity','TransactTime(UTC)|T':'Execution timestamp'},inplace = True)

        # The execution timestamp needs to be converted to this format: YYYY-MM-DDThh:mm:ss.ddddddZ
        source_trade_file_dataframe_with_desired_column['Execution timestamp'] = pd.to_datetime(source_trade_file_dataframe_with_desired_column['Execution timestamp'],format='%Y%m%d-%H:%M:%S:%f').dt.strftime('%Y-%m-%dT%H:%M:%S.%fZ')

        # Add static columns with proper values in it
        source_trade_file_dataframe_with_desired_column[['Exchange','Region']] = 'XTKS','FCJ'

        # Converting datatype of entire dataframe to object i.e string for further calculation
        source_trade_file_dataframe_with_desired_column = source_trade_file_dataframe_with_desired_column.astype(str)

        # Getting Source Trade Unique Id by combining columns
        source_trade_file_dataframe_with_desired_column['Source_Trade_Unique_Id'] = source_trade_file_dataframe_with_desired_column['Buy/sell'] + source_trade_file_dataframe_with_desired_column['External Id 1'] + \
                                                   source_trade_file_dataframe_with_desired_column['Instrument'] + source_trade_file_dataframe_with_desired_column['Transaction type']
        flag = True
        # Checking if pairing column for source trade file is unique
        if len(source_trade_file_dataframe_with_desired_column[source_trade_file_dataframe_with_desired_column.duplicated('Source_Trade_Unique_Id')]) != 0:
            subject = f"Above files do not contain unique pairing columns for source trade file"
            print(f"Above files do not contain unique pairing columns for source trade file")
            duplicate_source_trade_dataframe = source_trade_file_dataframe_with_desired_column[source_trade_file_dataframe_with_desired_column.duplicated('Source_Trade_Unique_Id')]
            content = f"Above files do not contain unique pairing columns for source trade file \n{duplicate_source_trade_dataframe}"
            attachment_file_name = f"{input_trade_source_file}_duplicate.csv"
            duplicate_source_trade_dataframe.to_csv(attachment_file_name)
            print(source_trade_file_dataframe_with_desired_column[source_trade_file_dataframe_with_desired_column.duplicated('Source_Trade_Unique_Id')])
            send_email(subject, content)
            flag = False

        if control_transaction_type(source_trade_file_dataframe_with_desired_column['Transaction type'],'Trades')['bool'] == 'False':
            print(control_transaction_type(source_trade_file_dataframe_with_desired_column['Transaction type'],'Trades')['error'])
            flag = False

        print("**************this is source trade file***************")
        print(source_trade_file_dataframe_with_desired_column)

        # Reading contents from Fixed Width File Striping it based on position and Converting data of Fixed Width File into Dataframe
        fixed_width_file_dataframe = pd.DataFrame(cfg.fixed_width_file_mapping_config(input_fixed_width_file), columns =['MICS_product_identification','MICS_external_number','MICS_spark_id'])
        print(f"{input_fixed_width_file} has {len(fixed_width_file_dataframe)} records")

        # Renaming the column names
        fixed_width_file_dataframe.rename(
            columns={'MICS_product_identification': 'Instrument', 'MICS_external_number': 'External Id 1'},
            inplace=True)
        # Replacing blank leading and trailing spaces
        fixed_width_file_dataframe = fixed_width_file_dataframe.replace(r"^ +| +$",r"",regex= True)

        # Getting Fixed Width File Unique Id by combining columns
        fixed_width_file_dataframe['Fixed_Width_Unique_Id'] = fixed_width_file_dataframe['External Id 1'] + \
                                                  fixed_width_file_dataframe['Instrument']
        # Checking if pairing column for fixed width file is unique
        if len(fixed_width_file_dataframe[fixed_width_file_dataframe.duplicated('Fixed_Width_Unique_Id')]) != 0:
            subject = f"Above files do not contain unique pairing columns for fixed width file"
            print(f"Above files do not contain unique pairing columns for fixed width file")
            content = f"Above files do not contain unique pairing columns for fixed width file"
            duplicate_fixed_width_file_dataframe = fixed_width_file_dataframe[fixed_width_file_dataframe.duplicated('Fixed_Width_Unique_Id')]
            attachment_file_name = f"{input_fixed_width_file}_duplicate.csv"
            duplicate_fixed_width_file_dataframe.to_csv(attachment_file_name)
            print(fixed_width_file_dataframe[fixed_width_file_dataframe.duplicated('Fixed_Width_Unique_Id')])
            send_email(subject, content)
            flag = False

        print("**************this is fixed width file***************")
        print(fixed_width_file_dataframe)

        # Merging Two DataFrames and applying changes to get Desired output
        left_joined_df = pd.merge(source_trade_file_dataframe_with_desired_column,fixed_width_file_dataframe,on=['Instrument','External Id 1'],how ='left')
        left_joined_df.rename(columns={'MICS_spark_id':'External Id 3'},inplace=True)
        # Apply post controls logic if any one of them fails then will not prepare trade file
        print("**************this is merged dataframe***************")
        print(left_joined_df)

        if len(left_joined_df) < 100 :
            subject = f"Too small trade file"
            print(f"Too small trade file")
            content = f"This file does not have more records as required"
            send_email(subject, content)
            flag = False

        if flag:
            left_joined_df['External Id 2'] = ''
            sequence_of_columns = ['Exchange','Region','External Id 1','External Id 2','External Id 3','Trade date','Buy/sell','Transaction type','Membership code','Instrument','Execution timestamp','Price','Quantity']
            left_joined_df = left_joined_df.reindex(columns = sequence_of_columns)

            print("**************this is output trade dataframe***************")
            print(left_joined_df)
            present_date = datetime.date.today().strftime("%Y%m%d")

            # Saving trade output dataframe in csv format in desired loaction
            trade_date = left_joined_df['Trade date'].iloc[0]
            execution_version = 1
            filename = f"M2APACRECON_XTKS_{trade_date}_{execution_version}.csv"
            parent_directory = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            output_path = os.path.join(parent_directory,"actual_outputs",filename)

            if os.path.exists(output_path):
                execution_version += 1
                filename = f"M2APACRECON_XTKS_{trade_date}_{execution_version}.csv"
                output_path = os.path.join(parent_directory, "actual_outputs", filename)
            else:
                filename = filename
                output_path = os.path.join(parent_directory, "actual_outputs", filename)

            left_joined_df.to_csv(output_path,index =False)
            return f"please check output directory for generated trade file"
        else:
            print(f"for above reasons can not produce output trade file")
            return f"for above reasons can not produce output trade file"

    else:
        print("file not passed")


if __name__ == "__main__":
    """
    Main Function need to provide absolute location of input trade and fixed width files and
    call mifid_XTKS with those parameters
    """
    input_trade_source_file = "H:/python_code/sf_trading_analytics/mifid/actual_inputs/20230314 FF.trades.csv"
    input_fixed_width_file = "H:/python_code/sf_trading_analytics/mifid/actual_inputs/XTKS - Fix Width - FF - TC 3;4;5;6;7;8.sent"
    with alive_bar() as bar:
        mifid_XTKS(input_trade_source_file, input_fixed_width_file)
        bar()



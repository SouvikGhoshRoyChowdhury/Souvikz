import pandas as pd

def fixed_width_file_mapping_config(fixed_width_file_name: str) -> pd.DataFrame():
    """
    This function will take fixed width file rows as input,parse them based 
    on position and map them back to MICS fields
    @param fixed_width_file_name: name of the fixed width file present inside actual input folder
    @return: dataframe object to be used by exchanges
    """
    fixed_width_data = []
    with open(fixed_width_file_name) as fp:
        non_duplicate_entry = set(fp.readlines())
        for line in non_duplicate_entry:
            each_row = line.rstrip()
            MICS_product_identification = each_row[76:117]
            MICS_external_number = each_row[117:134]
            MICS_spark_id = each_row[562:599]
            fixed_width_data.append({'MICS_product_identification': MICS_product_identification,
                                 'MICS_external_number': MICS_external_number,
                                 'MICS_spark_id': MICS_spark_id})
    return fixed_width_data
    # fixed_width_file_dataframe = pd.DataFrame.from_dict(fixed_width_data, orient='columns')
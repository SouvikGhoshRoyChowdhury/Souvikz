from string import Template
from smtplib import SMTP
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
import os
import configparser
from typing import List, Tuple
import re

from aac.tsdos.sf_common.util import Logger

config = configparser.ConfigParser()
config.read(os.path.join(os.path.dirname(__file__), '..', 'sf_config', 'sf_execution_config', 'executioners.cfg'))


MY_ADDRESS = 'sbl.treasury.block.eu@abnamroclearing.com'


class ReportEmailService:
    def __init__(self, log):
        self.log: Logger = log
        self.log.debug("Email Service object initiated")

    def main_emailing(self, contacts: str, message: str, message_subject: str, attachments: List[str], env: str,
                      day: str, sender_email: str = MY_ADDRESS, dcr_entitled_today: float = None) -> None:
        """"
        Function that takes contact list, the text for the email message and attachment files as input, makes connection
        to the smtp server and sends the message to the input contact list with the input attachments
        :param contacts: text file path where each line gives contact details of one person/contact
        :param message: text file path with the message to be send in the mail
        :param message_subject: string with the subject of the mail
        :param attachments: list with attachment(s) path strings to be attached to the mail
        :param env: temporarily added argument to find out from which servers test emails originate
        :param day: the date corresponding to the attachments to be send
        :param sender_email: specifies the sender mail address, default is 'sbl.treasury.block.eu@abnamroclearing.com'
        :param dcr_entitled_today: the number of dcr report entries that are entitled today (i.e. having ex-date
        tomorrow)
        """
        if not sender_email:
            self.log.error(f"EMA-ERROR-003: No sender email specified.")
            raise ValueError(f"EMA-ERROR-003: No sender email specified.")
        if not re.match(r"[^@]+@[^@]+\.[^@]+", sender_email):
            self.log.error(f"EMA-ERROR-004: Sender email {sender_email} does not have the correct format.")
            raise ValueError(f"EMA-ERROR-004: Sender email {sender_email} does not have the correct format.")
        if sender_email[-20:] != "@abnamroclearing.com":
            self.log.warn(f"Sender email {sender_email} ends with {sender_email[-20:]}. It does not end with "
                          f"@abnamroclearing.com.")

        if not message_subject:
            self.log.error("EMA-ERROR-005: No message subject specified.")
            raise ValueError("EMA-ERROR-005: No message subject specified.")

        """ fetch the contact information and the message template """
        names, emails = self.get_contacts(contacts)
        message_template = self.read_template(message)

        if not names:
            self.log.error("EMA-ERROR-006: No contact names to send mail to.")
            raise ValueError("EMA-ERROR-006: No contact names to send mail to.")
        if not emails:
            self.log.error("EMA-ERROR-007: No contact emails to send mail to.")
            raise ValueError("EMA-ERROR-007: No contact emails to send mail to.")

        """ set up the SMTP server """
        server = SMTP(host='smtp-gb.abnamroclearing.com', port=25, timeout=30)

        self.send_emails(names, emails, message_template, day, sender_email, env, message_subject, attachments, server,
                         dcr_entitled_today)

        """ Terminate the SMTP session and close the connection """
        server.quit()

        self.log.debug("Email Service run completed")

    def get_contacts(self, contacts_file: str) -> Tuple[List[str], List[str]]:
        """
        Function to read the contacts from a given contact file and return a list of names and email addresses
        :param contacts_file: the input file path with contacts, where each line gives the name and the email
        (separated with a space) of a contact
        :return names: list of names in str format
        :return list of email addresses in str format
        """
        if not os.path.exists(contacts_file):
            self.log.error(f"EMA-ERROR-001: No contacts_file available.")
            raise ValueError(f"EMA-ERROR-001: No contacts_file available.")
        names = []
        emails = []
        with open(contacts_file, mode='r', encoding='utf-8') as contacts_file:
            contacts_text = contacts_file.read()
            contacts_list = contacts_text.split("\n")
            for a_contact in contacts_list:
                """ Delete newline character"""
                a_contact = a_contact.strip("\n")

                contact_details = a_contact.split("|")
                if len(contact_details) != 2:
                    self.log.warn(f"Invalid contact string: {a_contact}")
                    continue

                contact_name: str = contact_details[0]
                contact_mail: str = contact_details[1]

                if not re.match(r"[^@]+@[^@]+\.[^@]+", contact_mail):
                    self.log.warn(f"Contact email {contact_mail} does not does not have a valid email address format.")
                    continue
                if contact_mail[-20:] != "@abnamroclearing.com":
                    self.log.warn(f"Contact email {contact_mail} ends with {contact_mail[-20:]}. It does not end with "
                                  f"@abnamroclearing.com.")
                names.append(contact_name)
                emails.append(contact_mail)
        return names, emails

    def read_template(self, message_file: str) -> Template:
        """
        Function that reads in a template file (the email message) and returns a Template object made from its
        contents
        :param message_file: path to message file
        :return Template object with message
        """
        if not os.path.exists(message_file):
            self.log.error(f"EMA-ERROR-002: No message_file available.")
            raise ValueError(f"EMA-ERROR-002: No message_file available.")

        with open(message_file, 'r', encoding='utf-8') as template_file:
            template_file_content = template_file.read()
        return Template(template_file_content)

    def send_emails(self, names: List[str], emails: List[str], message_template: Template, day: str, sender_email: str,
                    env: str, message_subject: str, attachments: List[str], server: SMTP,
                    dcr_entitled_today: float = None):
        """ For each contact, send the email.
        :param names: contact names to send emails to
        :param emails: contact email addresses to send emails to
        :param message_template: template object with message body
        :param day: the date corresponding to the attachments to be send
        :param sender_email: specifies the sender mail address, default is 'sbl.treasury.block.eu@abnamroclearing.com'
        :param env: temporarily added argument to find out from which servers test emails originate
        :param message_subject: string with the subject of the mail
        :param attachments: list with attachment(s) path strings to be attached to the mail
        :param server: SMTP server object
        :param dcr_entitled_today: the number of DCR report entries that are entitled today (i.e. having ex-date
        tomorrow)
        """
        for name, email in zip(names, emails):
            """ Create a message """
            msg = MIMEMultipart()

            """ Add in the actual person name and the correct date to the message template """
            message = message_template.substitute(PERSON_NAME=name, DATE=day, DCR_ENTITLED_TODAY=dcr_entitled_today)

            """ Update message object with message parameters"""
            self.set_mail_parameters(msg, sender_email, email, env, message_subject)

            """ Add in the message text body """
            msg.attach(MIMEText(message, 'plain'))

            self.attach_attachments(attachments, msg)

            """ Send the message via the server set up earlier. """
            self.log.debug("Start send email to: " + msg['To'])
            try:
                server.send_message(msg)
                self.log.debug("Completed send email to: " + msg['To'])
            except Exception as e:
                self.log.error(f"The following exception occurred during sending message to {msg['To']}: {type(e)}: "
                               f"{e.args}")
            del msg

    def set_mail_parameters(self, msg: MIMEMultipart, sender_email: str, email: str, env: str, message_subject: str):
        """
        Setup the parameters of the message.
        :param msg: message object
        :param sender_email: specifies the sender mail address, default is 'sbl.treasury.block.eu@abnamroclearing.com'
        :param email: single email address to send email to
        :param env: temporarily added argument to find out from which servers test emails originate
        :param message_subject: string with the subject of the mail
        """
        self.log.debug("Start setting msg parameters")
        msg['From'] = sender_email
        msg['To'] = email
        msg['Subject'] = env + ": " + message_subject
        self.log.debug("Completed setting msg parameters")

    def attach_attachments(self, attachments: List[str], msg: MIMEMultipart):
        """
        Attach attachments to the message object
        :param attachments: list with attachments to be send
        :param msg: message object
        """
        for attachment in attachments:
            """ if attachment variable exists the path / file should be available, raise error otherwise """
            if os.path.exists(attachment):
                folder_name, file_name = os.path.split(attachment)
                with open(attachment, "rb") as f:
                    attach = MIMEApplication(f.read(), _subtype="pdf")
                attach.add_header('Content-Disposition', 'attachment', filename=file_name)
                msg.attach(attach)
            else:
                self.log.error(f"EMA-ERROR-008: Attachment {attachment} not available.")
                raise ValueError(f"EMA-ERROR-008: Attachment {attachment} not available.")


# TODO add flexibility run for specific day (backlog)
# TODO add try except statement to guarantee file in folder
# TODO check if/where env should be added


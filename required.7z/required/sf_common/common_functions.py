import platform
import datetime as dt
import holidays
import socket
import os
import sys
from os.path import dirname, abspath, join, isdir
from typing import List, Union, NamedTuple, Optional
from datetime import datetime, timedelta
import configparser
import json
from subprocess import PIPE, run
import traceback
from pandas import ExcelWriter

this_file = __file__

# Reads configuration
config = configparser.ConfigParser()
config.read(
    os.path.join(
        os.path.dirname(__file__),
        "..",
        "sf_config",
        "sf_common_config",
        "common_functions.cfg",
    )
)

# Loads holidays
holidays = []
for holiday_name in config["holidays"]:
    holidays.append(datetime.strptime(config["holidays"][holiday_name], "%d-%m-%Y"))


class Answer(NamedTuple):
    do_abort: bool
    reason: str


def guarantee_folder(*folders: str) -> str:
    """
    Guarantee folder allows you to guarantee that a folder exists. It accepts absolute addresses, relative addresses,
    and series of nested folders.
    :param folders: the absolute address, relative address or series of nested folder names that point to a single
    folder.

    :return target_folder: The absolute path of the guaranteed folder.
    """
    target_folder = ""

    """Splits up paths into individual layers of folders to be checked and created."""
    per_layer: List[str] = []

    for added_folder in folders:
        if added_folder[0] == "/":
            target_folder = "/"

        added_folder = added_folder.replace("\\", "/")
        for single_layer in added_folder.split("/"):
            if single_layer != "" and single_layer != "<USER>" and single_layer != "<FILE>":
                per_layer.append(single_layer)
            elif single_layer == "<USER>":
                per_layer.append(os.path.expanduser("~"))
            elif single_layer == "<FILE>":
                per_layer.append(abspath(dirname(this_file)))
                per_layer.append("..")
                per_layer.append("sf_execution")

    for added_folder in per_layer:
        target_folder = join(target_folder, added_folder)
        if not isdir(target_folder):
            os.mkdir(target_folder)
            os.chmod(target_folder, 0o755)
    return target_folder


def env_detect() -> str:
    """
    This method detects the environment and hostname of the system and returns a string
    with the code for the system, 'DEV', 'SIT', 'UAT', 'PROD'
    """
    if platform.system() == "Windows":
        return "DEV"
    elif platform.system() == "Linux":
        if socket.gethostname() == "gbvleuaactgim01.windmill.local":
            return "SIT"
        if socket.gethostname() == "gbvleuaacugim01.windmill.local":
            return "UAT"
        if socket.gethostname() == "gbvleuaacpgim01.windmill.local":
            return "PROD"
    return "unknown"


def convert_to_json(python_format: Union[list, dict]) -> Union[list, dict]:
    """Converts attribute names from python format (with underscores instead of spaces) to the desired json format
    (with dashes instead of spaces). Used to allow for using typed dictionaries, while not altering the format
    of our overall output.
    :param python_format - The object that is to be converted.
    :return - The converted object."""

    if type(python_format) is list:
        json_format = []
        for entry in python_format:
            json_format.append(convert_to_json(entry))

    elif type(python_format) is dict:
        json_format = {}
        for key in python_format:
            """Replace underscore with dash, and _und_ with underscore"""
            translated_key = key.replace("_und_", "/////").replace("_", "-").replace("/////", "_")
            json_format[translated_key] = convert_to_json(python_format[key])

    else:
        json_format = python_format

    return json_format


def previous_business_day(business_day: datetime) -> datetime:
    """
    Returns the weekday prior to the given original day.
    """
    while True:
        business_day -= timedelta(days=1)

        # Checks if the day is a weekend or holiday
        day_of_the_week = business_day.isoweekday()
        if day_of_the_week == 6 or day_of_the_week == 7 or business_day in holidays:
            continue

        # Returns a business day
        return business_day


def convert_to_python(json_format: Union[list, dict]) -> Union[list, dict]:
    """Converts attribute names from json format (with dashes instead of spaces) to the desired python format (with
    underscores instead of spaces). Used to allow for using typed dictionaries, while not altering the format
    of our overall output.
    :param json_format - The object that is to be converted.
    :return - The converted object."""

    if type(json_format) is list:
        python_format = []
        for entry in json_format:
            python_format.append(convert_to_python(entry))

    elif type(json_format) is dict:
        python_format = {}
        for key in json_format:
            """Replace dash with underscore, and underscore with _und_"""
            translated_key = key.replace("_", "/////").replace("-", "_").replace("/////", "_und_")
            python_format[translated_key] = convert_to_python(json_format[key])

    else:
        python_format = json_format
    return python_format


def convert_to_bool(bool_str: Union[bool, str]) -> bool:
    if type(bool_str) is bool:
        return bool_str
    else:
        bool_str = bool_str.lower()
        if bool_str in ["true", "1", "yes", "on", "enabled", "y"]:
            return True
        elif bool_str in ["false", "0", "no", "off", "disabled", "n"]:
            return False
        else:
            raise ValueError(f"Could not transalate {bool_str} to boolean. Please enter 'True' of 'False'.")


def translate_market_area_to_country(market_area: str) -> str:
    market_area = market_area.split(" ")[0]
    if market_area == "ADR":
        return "US"
    elif market_area == "UK":
        return "GB"
    elif len(market_area) == 2 and market_area != "EM":
        return market_area
    return "ZZ"


def translate_country_to_market_area_prefix(country: Optional[str]) -> List[str]:
    if country == "US":
        return ["'US%'", "'ADR%'"]
    elif country == "GB":
        return ["'GB%'", "'UK%'", "'IE%'"]
    elif country is None:
        return ["'%'"]  # matches everything, primarily used for ETFs
    else:
        return [f"'{country}%'"]


def get_future_business_days(
    future_days: int, present_day=dt.date.today(), holiday_list=None
) -> datetime:
    """
    This is generic function to get future business days to be added with present business days
    :param future_days - how many future days you want add with present day and type will integer only
    :param present_day [Default] - by default it will take today's date but can be extended by supplied
     with custom start date
    :param holiday_list [Optional] - this holiday list can be provided in order get next date excluding holidays
     alternatively can also be provided in get_present_and_next_business_day_after_holidays
    :return : next future date as per parameters provided
    """
    if holiday_list is None:
        present_day = present_day
    else:
        present_day = get_present_and_next_business_day_after_holidays(holiday_list)
    i = 1
    while i <= future_days:
        if present_day.weekday() == 4:
            present_day = present_day + dt.timedelta(days=2)
        present_day = present_day + dt.timedelta(days=1)
        i += 1
    return present_day


def get_present_and_next_business_day_after_holidays(holiday_list=None) -> datetime:
    """
    This is generic function to get present date or next business date after holidays of particular region or country
    :param [Optional] - holiday list based on region or country based upon requirements
    format of dates in list should always in "YYYY-MM-DD" format
    :return - next business day if holiday list provided else present date
    """
    present_day = dt.date.today()
    if holiday_list is None:
        return present_day
    holiday_list_to_be_checked = holiday_list
    if present_day in holiday_list_to_be_checked:
        while present_day in holiday_list_to_be_checked:
            next_business_day = present_day + dt.timedelta(days=1)
            present_day = next_business_day
        return present_day
    else:
        return present_day


def get_previous_business_days(
    previous_days: int, present_day=dt.date.today(), holiday_list=None
) -> datetime:
    """
    This is generic function to get future business days to be added with present business days
    :param previous_days - how many previous days you want add with present day and type will integer only
    :param present_day [Default] - by default it will take today's date but can be extended by supplied
     with custom start date
    :param holiday_list [Optional] - this holiday list can be provided in order get next date excluding holidays
     alternatively can also be provided in get_present_and_next_business_day_after_holidays
    :return : next future date as per parameters provided
    """
    if holiday_list is None:
        present_day = present_day
    else:
        present_day = get_present_and_previous_business_day_before_holidays(
            holiday_list
        )
    i = 1
    while i <= previous_days:
        if present_day.isoweekday() == 7:
            present_day = present_day - dt.timedelta(days=2)
        elif present_day.isoweekday() == 1:
            present_day = present_day - dt.timedelta(days=3)
        else:
            present_day = present_day - dt.timedelta(days=1)
        i += 1
    return present_day


def get_present_and_previous_business_day_before_holidays(
    holiday_list=None,
) -> datetime:
    """
    This is generic function to get present date or next business date after holidays of particular region or country
    :param [Optional] - holiday list based on region or country based upon requirements
    format of dates in list should always in "YYYY-MM-DD" format
    :return - next business day if holiday list provided else present date
    """
    present_day = dt.date.today()
    if holiday_list is None:
        return present_day
    holiday_list_to_be_checked = holiday_list
    if present_day in holiday_list_to_be_checked:
        while present_day in holiday_list_to_be_checked:
            next_business_day = present_day - dt.timedelta(days=1)
            present_day = next_business_day
        return present_day
    else:
        return present_day


def format_exception(ex: Exception):
    exception_list = traceback.format_stack()
    exception_list = exception_list[:-2]
    exception_list.extend(traceback.format_tb(sys.exc_info()[2]))
    exception_list.extend(traceback.format_exception_only(sys.exc_info()[0], sys.exc_info()[1]))

    exception_str = "Traceback (most recent call last):\n"
    exception_str += "".join(exception_list)
    # Removing the last \n
    exception_str = exception_str[:-1]

    return exception_str


class Configuration:
    def __init__(
        self,
        fullpath: str,
        is_encrypted_zip: bool = False,
        password: str = "",
        zip_filename: str = "",
        case_sensitive: bool = False,
        is_json: bool = False,
    ):
        self.fullpath: str = fullpath
        self.dataMap = configparser.ConfigParser()
        self.is_encrypted_zip = is_encrypted_zip
        self.zip_filename = zip_filename
        self.password = str.encode(password)
        self.case_sensitive = case_sensitive

        if self.case_sensitive:
            self.dataMap.optionxform = str
        if is_encrypted_zip:
            self.read_encrypted_zipped_file()
        elif is_json:
            self.dataMap = json.loads(fullpath)
        else:
            self.dataMap.read(fullpath)
        pass

    def read_encrypted_zipped_file(self):
        import pyzipper
        import io

        with pyzipper.AESZipFile(self.zip_filename, "r") as zf:
            zf.setpassword(self.password)
            file_text = zf.read(self.fullpath)
            # self.dataMap.read_file(io.StringIO(file_text.decode(encoding='utf-8')))
            self.dataMap.read_file(io.StringIO(file_text.decode(encoding="ISO-8859-1")))
        pass

    def refresh(self):
        self.dataMap = configparser.ConfigParser()
        if self.case_sensitive:
            self.dataMap.optionxform = str
        if self.is_encrypted_zip:
            self.read_encrypted_zipped_file()
        else:
            self.dataMap.read(self.fullpath)


def export_to_excel(frames: list, fullpath: str, index=False, header_row_format: dict = None):
    writer = ExcelWriter(fullpath, engine="xlsxwriter")
    row_format = None
    if header_row_format:
        workbook = writer.book
        row_format = workbook.add_format(header_row_format)

    for frame in frames:
        df = frame[0]
        sheetname = frame[1]
        df.to_excel(writer, sheetname, index=index, header=False)
        worksheet = writer.sheets[sheetname]
        if header_row_format:
            worksheet.set_row(0, None, row_format)
        for col_num, data in enumerate(df.columns):
            worksheet.write(0, col_num, data)
    writer.close()

AUTH_URL_PROD = "https://cp-gateway-wizard-portal-prod.apps.ocp-eu.windmill.local/api/validate/"
AUTH_URL_UAT = "https://cp-gateway-wizard-portal-uat.apps.ocp-eu.windmill.local/api/validate/"

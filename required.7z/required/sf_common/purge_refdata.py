import os
import pathlib
import argparse
from datetime import datetime, timedelta

file_path = os.path.dirname(__file__)


def purge_refdata(cutoff_date):
    folder = os.path.join(file_path, '..', 'sf_execution', 'ref_data')

    for file_name in os.listdir(folder):
        file_name = os.path.join(folder, file_name)
        fname = pathlib.Path(file_name)
        creation_time = datetime.fromtimestamp(fname.stat().st_mtime)
        if creation_time < cutoff_date:
            os.remove(file_name)


def main():
    parser = argparse.ArgumentParser(description="Runs the refdata purger for a specific date.")
    parser.add_argument(
        "-d", dest="cutoff_date", type=str, default=(datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d"),
        help="The cutoff date, from before which lines are cut.")
    args = parser.parse_args()

    purge_refdata(datetime.strptime(args.cutoff_date, "%Y-%m-%d"))


if __name__ == "__main__":
    main()

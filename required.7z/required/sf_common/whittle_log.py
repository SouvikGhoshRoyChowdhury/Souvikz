from datetime import datetime, timedelta
import argparse

from aac.tsdos.sf_common.util import Logger
from aac.tsdos.sf_common.common_functions import env_detect


log = Logger('tsdos.admin', env=env_detect())


def whittle_log(file_path, cutoff_date):
    log.debug(f"Opening {file_path} for whittling")
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()
    except FileNotFoundError:
        log.warn(f"log {file_path} does not exist.")
        return

    with open(file_path, 'w') as file:
        write_undated = False  # Only start keeping undated lines after you encounter a dated line after cutoff.
        for line in lines:
            try:
                line_date = datetime.strptime(line.split(' ')[0], '%Y-%m-%d')
                line_is_dated = True
            except:
                line_is_dated = False

            if line_is_dated and line_date >= cutoff_date:
                file.write(line)
                write_undated = True
            elif line_is_dated:
                write_undated = False
            elif not line_is_dated and write_undated:
                file.write(line)


def main():
    parser = argparse.ArgumentParser(description="Runs the best executioner for a specific date.")
    # use_old_benchmarks
    parser.add_argument(
        "-d", dest="cutoff_date", type=str, default=(datetime.now() - timedelta(days=10)).strftime("%Y-%m-%d"),
        help="The cutoff date, from before which lines are cut.")
    parser.add_argument(
        "-f", dest="file_path", type=str,
        help="Full file path of the log file")
    args = parser.parse_args()

    if args.file_path is None:
        raise RuntimeError("whittle_log.py requires a file path to function. Use -f to provide a link to the log file.")

    whittle_log(args.file_path, datetime.strptime(args.cutoff_date, "%Y-%m-%d"))


if __name__ == "__main__":
    main()

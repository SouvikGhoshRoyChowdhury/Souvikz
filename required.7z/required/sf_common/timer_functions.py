from datetime import datetime


def how_many_seconds_until_midnight() -> int:
    """Get the number of seconds until midnight."""
    n = datetime.now()
    remaining_hours = 24 - n.hour - 1
    remaining_minutes = (60 * remaining_hours) + (60 - n.minute - 1)
    return (remaining_minutes * 60) + (60 - n.second)

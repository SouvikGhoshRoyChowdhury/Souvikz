import os
import sys
import subprocess
import pyodbc
import configparser
import traceback
from smtplib import SMTP
from typing import Optional

from aac.tsdos.sf_common.common_functions import env_detect
from aac.tsdos.sf_common.util import Logger


class SanityChecker:
    def __init__(self, env: str, log: Logger):
        self.env = env
        self.log = log

        self.config = configparser.ConfigParser()
        self.config.read(os.path.join(os.path.dirname(__file__), "..", "sf_config", "sf_data_caller_config", "env.cfg"))

    def execute_sanity_check(self):
        abort_reason = self._check_python_version()
        if abort_reason is not None:
            self.log.error(f"Sanity check error: {abort_reason}")
            raise RuntimeError(f"Sanity check error: {abort_reason}")

        abort_reason = self._check_user()
        if abort_reason is not None:
            self.log.error(f"Sanity check error: {abort_reason}")
            raise RuntimeError(f"Sanity check error: {abort_reason}")

        abort_reason = self._check_gpfs_share()
        if abort_reason is not None:
            self.log.error(f"Sanity check error: {abort_reason}")
            raise RuntimeError(f"Sanity check error: {abort_reason}")

        abort_reason = self._check_kerberos_ticket()
        if abort_reason is not None:
            self.log.error(f"Sanity check error: {abort_reason}")
            raise RuntimeError(f"Sanity check error: {abort_reason}")

        abort_reason = self._check_datalake_connection()
        if abort_reason is not None:
            self.log.error(f"Sanity check error: {abort_reason}")
            raise RuntimeError(f"Sanity check error: {abort_reason}")

        abort_reason = self._check_smtp_instantiation()
        if abort_reason is not None:
            self.log.error(f"Sanity check error: {abort_reason}")
            raise RuntimeError(f"Sanity check error: {abort_reason}")

    @staticmethod
    def _check_python_version() -> Optional[str]:
        """
        Do not allow the application to run on a python version below 3.6
        """
        if sys.version_info.major < 3:
            return "Python 2.x is not supported"
        if sys.version_info.major == 3 and sys.version_info.minor < 6:
            return \
                f"Python version < 3.6 not supported. You are using {sys.version_info.major}.{sys.version_info.minor}"

    def _check_user(self) -> Optional[str]:
        """
        On windows all user are allowed,
        on linux systems only user 'sfgim' is allowed
        """
        if self.env != "DEV":
            effective_user = os.environ.get("USER")
            if effective_user != "sfgim" and effective_user != "sa-sfgim":
                return f"User should be 'sfgim' or 'sa-sfgim' but is '{effective_user}'"

    def _check_gpfs_share(self) -> Optional[str]:
        """
        Checks whether the refdata and rps folders are present
        """
        if self.env == "SIT":
            if not os.path.exists("/share/sit/refdata/") or not os.path.exists("/share/sit/rps"):
                return f"Appropriate share folders for TSDOS are not present, check for GPFS mounting"
        elif self.env == "UAT":
            if not os.path.exists("/share/uat/refdata/") or not os.path.exists("/share/uat/rps"):
                return f"Appropriate share folders for TSDOS are not present, check for GPFS mounting"
        elif self.env == "PROD":
            if not os.path.exists("/share/prd/refdata/") or not os.path.exists("/share/prd/rps"):
                return f"Appropriate share folders for TSDOS are not present, check for GPFS mounting"

    def _check_kerberos_ticket(self) -> Optional[str]:
        """
        Checks whether a valid kerberos ticket currently exists
        """
        if self.env != "DEV":
            if not subprocess.call(['klist', '-s']) == 0:
                return "No valid Kerberos ticket is present."

    def _check_datalake_connection(self) -> Optional[str]:
        """
        Checks whether a datalake connection can be made and a cursor object be instantiated.
        """
        try:
            connection_string: str = self.config["IMPALA " + self.env]["src"]
            connection: pyodbc.Connection = pyodbc.connect(connection_string, autocommit=True)
            connection.cursor()
        except:  # noqa
            traceback.print_exc()
            return f"Could not instantiate test datalake connection and create a cursor."

    def _check_smtp_instantiation(self) -> Optional[str]:
        """
        Checks whether the SMTP server can be instantiated.
        """
        if self.env != "DEV":
            try:
                server = SMTP(host='smtp-gb.abnamroclearing.com', port=25, timeout=30)
                server.quit()
            except:  # noqa
                traceback.print_exc()
                return f"Could not instantiate SMTP server for the purposes of sending out report."


def sanity_check():
    run_env = env_detect()

    log = Logger('invmgr.live_data_caller', run_env)

    sanity_checker = SanityChecker(run_env, log)
    sanity_checker.execute_sanity_check()


if __name__ == "__main__":
    sanity_check()

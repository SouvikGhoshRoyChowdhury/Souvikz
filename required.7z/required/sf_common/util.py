import logging.config
import os
from logging import Logger


class Logger:
    """
    The Logger class serves to provide a logbook, displaying various things that come up in other parts of
    sf_trading analytics
    """
    init = False

    def __init__(self, name, env, padding=500):
        self.name = name
        self.__padding = padding
        if not Logger.init:
            logging.config.fileConfig(
                os.path.join(os.path.dirname(__file__), '..', 'sf_config', 'sf_common_config', f'log {env}.cfg'),
                defaults=None, disable_existing_loggers=True)
            Logger.init = True

    def info(self, msg, data=None):
        """
        Information display with the given message and data.
        """
        logger = logging.getLogger(self.name)
        logger.propagate = False
        logger.info(self.__get_msg(msg, data))

    def debug(self, msg, data=None):
        """
        Debug display with the given message and data.
        """
        logger = logging.getLogger(self.name)
        logger.propagate = False
        logger.debug(self.__get_msg(msg, data))

    def warn(self, msg, data=None):
        """
        Warning display with the given message and data.
        """
        logger = logging.getLogger(self.name)
        logger.propagate = False
        logger.warning(self.__get_msg(msg, data))

    def error(self, msg, data=None):
        """
        Error display with the given message and data.
        """
        logger = logging.getLogger(self.name)
        logger.propagate = False
        logger.error(self.__get_msg(msg, data))

    def __get_msg(self, msg, data=None):
        """
        Formats the messages used in the other functions
        """
        msg = ('{:<%d}' % + min(len(msg), self.__padding)).format(msg[:min(len(msg), self.__padding)])
        if data is not None:
            msg = '{} [{}]'.format(msg, data)
        return msg

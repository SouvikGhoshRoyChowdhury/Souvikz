./sfgim_run_umr_data.sh  &&
./sfgim_run_umr_excel.sh  &&
./sfgim_run_umr_mail.sh
./sfgim_comp_initialsbls.sh &&
./sfgim_run_best_execution_data.sh &&
./sfgim_run_best_execution_report.sh &&
./sfgim_run_best_execution_excel.sh &&
./sfgim_run_best_execution_pdf.sh &&
./sfgim_run_best_execution_mail.sh

# Set global server variables
env_string=$(hostnamectl | grep 'hostname')
hostname=${env_string:20:30}
sit_hostname="gbvleuaactgim01.windmill.local"
uat_hostname="gbvleuaacugim01.windmill.local"
prd_hostname="gbvleuaacpgim01.windmill.local"

# Find env (as string)
if [ $hostname = $sit_hostname ]; then
  env="sit"
elif [ $hostname = $uat_hostname ]; then
  env="uat"
elif [ $hostname = $prd_hostname ]; then
  env="prd"
fi

# How many days to look back for previous business day
DAY_OF_WEEK=`date +%w`
if [ $DAY_OF_WEEK = 0 ]; then
  LOOK_BACK=2
elif [ $DAY_OF_WEEK = 1 ]; then
  LOOK_BACK=3
  # Set extra date variables for Monday runs
  tday_minus_one=$(date -d "-1 day" +'%Y%m%d')
  tday_minus_two=$(date -d "-2 day" +'%Y%m%d')
else
  LOOK_BACK=1
fi

# Set global date variables
tday=$(date +'%Y%m%d')
yday=$(date -d "$LOOK_BACK day ago" +'%Y%m%d')

# Execute
if [ "$env" = "sit" ] || [ "$env" = "uat" ]; then
  echo "In the "$env" environment, TSDOS uses the static input data for 2021-09-30 for sfgim_comp_dividend_actions.sh due to lack of some daily files on test servers."
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_compdata/dividend_actions.py -s "/opt/sfgim/aac/tsdos/sf_execution/static_inputs/"$env"/CA_20210930_sfgim.out" -o "/share/"$env"/rps/sfgim/imt/polling/dividend_action/"$tday"/default/Dividend_Action_EU_"$yday".json"
elif [ "$env" = "prd" ]; then
  # For Monday run's sequentially check if CA file is generated on lookback day (Fri), today (Mon), today -1 (Sun), or today -2 (Sat)
  if [ "$DAY_OF_WEEK" = 1 ]; then
    if [ -f "/share/"$env"/refdata/ail/sfgim/polling/CA_"$yday"_sfgim.out" ]; then
      ca_eu_filename="/share/"$env"/refdata/ail/sfgim/polling/CA_"$yday"_sfgim.out"
    elif [ -f "/share/"$env"/refdata/ail/sfgim/polling/CA_"$tday"_sfgim.out" ]; then
      ca_eu_filename="/share/"$env"/refdata/ail/sfgim/polling/CA_"$tday"_sfgim.out"
    elif [ -f "/share/"$env"/refdata/ail/sfgim/polling/CA_"$tday_minus_one"_sfgim.out" ]; then
      ca_eu_filename="/share/"$env"/refdata/ail/sfgim/polling/CA_"$tday_minus_one"_sfgim.out"
    else
      ca_eu_filename="/share/"$env"/refdata/ail/sfgim/polling/CA_"$tday_minus_two"_sfgim.out"
    fi
  # For non-Monday run's sequentially check if CA file is generated on lookback day or today
  else
    if [ -f "/share/"$env"/refdata/ail/sfgim/polling/CA_"$yday"_sfgim.out" ]; then
      ca_eu_filename="/share/"$env"/refdata/ail/sfgim/polling/CA_"$yday"_sfgim.out"
    else
      ca_eu_filename="/share/"$env"/refdata/ail/sfgim/polling/CA_"$tday"_sfgim.out"
    fi
  fi
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_compdata/dividend_actions.py -s "$ca_eu_filename" -o "/share/"$env"/rps/sfgim/imt/polling/dividend_action/"$tday"/default/Dividend_Action_EU_"$yday".json"
fi

./sfgim_comp_latestsbls.sh  &&
./sfgim_comp_latestcollaterals.sh  &&
./sfgim_comp_dividend_actions_eu.sh  &&
./sfgim_run_dcr_eu_data.sh  &&
./sfgim_run_dcr_eu_report.sh  &&
./sfgim_run_dcr_eu_excel.sh  &&
./sfgim_run_dcr_eu_mail.sh

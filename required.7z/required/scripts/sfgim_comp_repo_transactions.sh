# Set global server variables
env_string=$(hostnamectl | grep 'hostname')
hostname=${env_string:20:30}
sit_hostname="gbvleuaactgim01.windmill.local"
uat_hostname="gbvleuaacugim01.windmill.local"
prd_hostname="gbvleuaacpgim01.windmill.local"

# Find env (as string)
if [ $hostname = $sit_hostname ]; then
  env="sit"
elif [ $hostname = $uat_hostname ]; then
  env="uat"
elif [ $hostname = $prd_hostname ]; then
  env="prd"
fi

# How many days to look back for previous business day
DAY_OF_WEEK=`date +%w`
if [ $DAY_OF_WEEK = 0 ]; then
  LOOK_BACK=2
elif [ $DAY_OF_WEEK = 1 ]; then
  LOOK_BACK=3
else
  LOOK_BACK=1
fi

# Set global date variables
tday=$(date +'%Y%m%d')
yday=$(date -d "$LOOK_BACK day ago" +'%Y%m%d')
yday_dash=$(date -d "$LOOK_BACK day ago" +'%Y-%m-%d')

# Use static data if no daily data is available
if [ "$env" = "sit" ]; then
  source_file="/opt/sfgim/aac/tsdos/sf_execution/static_inputs/"$env"/SF_RepoPositionRecon_20230223.json"
else
  source_file="/share/"$env"/rps/ail/sfgim/polling/SF_RepoPositionRecon_"$yday".json"
fi

# Execute
if [ "$env" = "sit" ];  then
  echo "In the "$env" environment, TSDOS uses the static input data for 2023-02-23 for sfgim_comp_repo_transactions.sh due to lack of some daily files on test servers."
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_compdata/repo_transactions.py -d "2023-02-23" -i $source_file -o "/share/"$env"/rps/sfgim/imt/polling/compdata/"$tday"/default/repo_transactions_compdata_"$yday".json"
elif [ "$env" = "uat" ] || [ "$env" = "prd" ]; then
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_compdata/repo_transactions.py -d $yday_dash -i $source_file -o "/share/"$env"/rps/sfgim/imt/polling/compdata/"$tday"/default/repo_transactions_compdata_"$yday".json"
fi

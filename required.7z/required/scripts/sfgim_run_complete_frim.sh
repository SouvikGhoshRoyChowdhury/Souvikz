./sfgim_comp_repo_transactions.sh &&
./sfgim_comp_cash_collateral_transactions.sh &&
./sfgim_comp_non_cash_collateral_transactions.sh &&
./sfgim_comp_latestsbls.sh &&
./sfgim_run_frim_report.sh

./sfgim_comp_client_cash_inventories.sh &&
./sfgim_run_cmm_data.sh &&
./sfgim_run_cmm_report.sh &&
./sfgim_run_cmm_excel.sh &&
./sfgim_run_cmm_mail.sh

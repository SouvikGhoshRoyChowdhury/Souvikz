# Note: Name is slightly inaccurate, kept this way for purposes of not messing with the $universe scripts. This
#  shell script actually does all the daily cleaning of files, from whittling logs to archiving old outputs, to
#  getting rid of old Architecture 2.0 refdata files.

env_string=$(hostnamectl | grep 'hostname')
hostname=${env_string:20:30}
sit_hostname="gbvleuaactgim01.windmill.local"
uat_hostname="gbvleuaacugim01.windmill.local"
prd_hostname="gbvleuaacpgim01.windmill.local"

# Log Whittling
# New-standard logs
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/whittle_log.py -f /opt/sfgim/logs/sf_execution.log
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/whittle_log.py -f /opt/sfgim/logs/sf_execution_nonlive.log
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/whittle_log.py -f /opt/sfgim/logs/sf_live_data_caller.log
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/whittle_log.py -f /opt/sfgim/logs/sf_live_data_caller_nonlive.log

# Old-standard logs
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/whittle_log.py -f  /opt/sfgim/logs/sfgim_run_balancer.log
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/whittle_log.py -f  /opt/sfgim/logs/sfgim_run_borrow_return_analysis.log
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/whittle_log.py -f  /opt/sfgim/logs/sfgim_run_collateral_metric.log
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/whittle_log.py -f  /opt/sfgim/logs/sfgim_run_pricer.log
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/whittle_log.py -f  /opt/sfgim/logs/sfgim_stop_data_caller.log
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/whittle_log.py -f  /opt/sfgim/logs/sfgim_run_best_execution.log
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/whittle_log.py -f  /opt/sfgim/logs/sfgim_run_client_analysis.log
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/whittle_log.py -f  /opt/sfgim/logs/sfgim_run_overdue.log
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/whittle_log.py -f  /opt/sfgim/logs/sfgim_start_data_caller.log

# Purging refdata
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/purge_refdata.py

# Archive old output
if [ "$hostname" = "$sit_hostname" ] ;  then  # sit
  env="sit"
elif [ "$hostname" = "$uat_hostname" ] ;  then  # uat
  env="uat"
elif [ "$hostname" = "$prd_hostname" ] ;  then  # prod
  env="prd"
else:
  exit 0
fi

day_limit=90

# Zips old output
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/balancer"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/best_execution"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/best_execution_report"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/borrow_analysis"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/cash_pool_collateral"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/client_analysis"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/client_cash_inventories"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/collateral_metric"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/collateral_transactions"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/non_cash_collateral_transactions"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/commodity_repo_services"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/currency_mismatch"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/dcr"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/dividend_action"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/initial_sbl"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/latest_collateral"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/latest_sbl"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/non_cash_collateral"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/outstanding_trades_report"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/overdue_overview"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/pricer"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/securities_finance_transaction_control"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/snapshot_sbls"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/tcr"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/umr"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/folder_zipper.py -n $day_limit -b "/share/$env/rps/sfgim/imt/polling/user"

# Move old input files to done
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/move_to_done.py -n $day_limit -b "/share/$env/refdata/ail/sfgim/polling/"
/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/move_to_done.py -n $day_limit -b "/share/$env/rps/ail/sfgim/polling/"
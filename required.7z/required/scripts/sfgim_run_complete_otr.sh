./sfgim_comp_snapshot_sbls.sh &&
./sfgim_run_otr_data.sh &&
./sfgim_run_otr_excel.sh &&
./sfgim_run_otr_mail.sh

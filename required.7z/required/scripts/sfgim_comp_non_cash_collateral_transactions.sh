# Set global server variables
env_string=$(hostnamectl | grep 'hostname')
hostname=${env_string:20:30}
sit_hostname="gbvleuaactgim01.windmill.local"
uat_hostname="gbvleuaacugim01.windmill.local"
prd_hostname="gbvleuaacpgim01.windmill.local"

# Find env (as string)
if [ $hostname = $sit_hostname ]; then
  env="sit"
elif [ $hostname = $uat_hostname ]; then
  env="uat"
elif [ $hostname = $prd_hostname ]; then
  env="prd"
fi

# How many days to look back for previous business day
DAY_OF_WEEK=`date +%w`
if [ $DAY_OF_WEEK = 0 ]; then
  LOOK_BACK=2
elif [ $DAY_OF_WEEK = 1 ]; then
  LOOK_BACK=3
else
  LOOK_BACK=1
fi

# Set global date variables
tday=$(date +'%Y%m%d')
yday=$(date -d "$LOOK_BACK day ago" +'%Y%m%d')
yday_dash=$(date -d "$LOOK_BACK day ago" +'%Y-%m-%d')

if [ "$env" = "sit" ] || [ "$env" = "uat" ] || [ "$env" = "prd" ]; then
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_compdata/non_cash_collateral_transactions.py -d $yday_dash -o "/share/"$env"/rps/sfgim/imt/polling/non_cash_collateral_transactions/"$tday"/default/Non_Cash_Collateral_Transactions_"$yday".json"
fi

./sfgim_comp_latestcollaterals.sh  &&
./sfgim_run_ncc_data.sh  &&
./sfgim_run_ncc_excel.sh  &&
./sfgim_run_ncc_mail.sh

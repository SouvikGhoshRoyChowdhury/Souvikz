nohup ~/runkinit.sh
nohup /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/secfin_script/get_synthetics_data_by_isin.py >> /opt/sfgim/logs/sf_synthetics.log &

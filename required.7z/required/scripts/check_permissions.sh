env_string=$(hostnamectl | grep 'hostname')
hostname=${env_string:20:30}
sit_hostname="gbvleuaactgim01.windmill.local"
uat_hostname="gbvleuaacugim01.windmill.local"
prd_hostname="gbvleuaacpgim01.windmill.local"

tday=$(date +'%Y%m%d')

if [ "$hostname" = "$sit_hostname" ] ;  then  # sit
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/check_permissions.py -p '/home/sfgim' -e 16832
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/check_permissions.py -p '/share/sit/refdata' -e 17407
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/check_permissions.py -p '/share/sit/rps' -e 17407
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/check_permissions.py -p '/opt/sfgim' -e 16893
elif [ "$hostname" = "$uat_hostname" ] ;  then  # uat
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/check_permissions.py -p '/home/sfgim' -e 16832
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/check_permissions.py -p '/share/uat/refdata' -e 17407
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/check_permissions.py -p '/share/uat/rps' -e 17407
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/check_permissions.py -p '/opt/sfgim' -e 16893
elif [ "$hostname" = "$prd_hostname" ] ;  then  # prod
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/check_permissions.py -p '/home/sfgim' -e 16832
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/check_permissions.py -p '/share/prd/refdata' -e 17407
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/check_permissions.py -p '/share/prd/rps' -e 17407
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/check_permissions.py -p '/opt/sfgim' -e 16893
fi
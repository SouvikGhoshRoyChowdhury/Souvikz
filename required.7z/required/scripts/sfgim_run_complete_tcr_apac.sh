./sfgim_comp_initialsbls.sh  &&
./sfgim_comp_users.sh  &&
./sfgim_run_tcr_data.sh  &&
./sfgim_run_tcr_json.sh &&
./sfgim_run_tcr_excel.sh  &&
./sfgim_run_tcr_mail.sh

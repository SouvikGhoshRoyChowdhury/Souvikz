./sfgim_run_sftc_data.sh  &&
./sfgim_run_sftc_report.sh  &&
./sfgim_run_sftc_excel.sh  &&
./sfgim_run_sftc_mail.sh
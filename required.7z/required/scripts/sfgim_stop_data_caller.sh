nohup /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_data_caller/live_data_caller_shutdown.py >> /opt/sfgim/logs/sfgim_stop_data_caller.log &
sleep 1s
./sfgim_run_crsr_data.sh  &&
./sfgim_run_crsr_report.sh  &&
./sfgim_run_crsr_excel.sh  &&
./sfgim_run_crsr_mail.sh

/opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_common/sanity_check.py

# Set global server variables
env_string=$(hostnamectl | grep 'hostname')
hostname=${env_string:20:30}
sit_hostname="gbvleuaactgim01.windmill.local"
uat_hostname="gbvleuaacugim01.windmill.local"
prd_hostname="gbvleuaacpgim01.windmill.local"

# Find env (as string)
if [ $hostname = $sit_hostname ]; then
  env="sit"
elif [ $hostname = $uat_hostname ]; then
  env="uat"
elif [ $hostname = $prd_hostname ]; then
  env="prd"
fi

# Set global date variables
tday=$(date +'%Y%m%d')

# Execute
if [ "$env" = "sit" ] || [ "$env" = "uat" ] || [ "$env" = "prd" ]; then
    /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/get_inventory_file.py -o "/share/"$env"/rps/sfgim/imt/polling/comparable_invs/"$tday"/default/EOD_inv_"$tday".json"
fi

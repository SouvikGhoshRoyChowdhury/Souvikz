# Set global server variables
env_string=$(hostnamectl | grep 'hostname')
hostname=${env_string:20:30}
sit_hostname="gbvleuaactgim01.windmill.local"
uat_hostname="gbvleuaacugim01.windmill.local"
prd_hostname="gbvleuaacpgim01.windmill.local"

# Find env (as string)
if [ $hostname = $sit_hostname ]; then
  env="sit"
elif [ $hostname = $uat_hostname ]; then
  env="uat"
elif [ $hostname = $prd_hostname ]; then
  env="prd"
fi

# How many days to look back for previous business day
DAY_OF_WEEK=`date +%w`
if [ $DAY_OF_WEEK = 0 ]; then
  LOOK_BACK=2
elif [ $DAY_OF_WEEK = 1 ]; then
  LOOK_BACK=3
else
  LOOK_BACK=1
fi

# Set global date variables
tday=$(date +'%Y%m%d')
yday=$(date -d "$LOOK_BACK day ago" +'%Y%m%d')
yday_dash=$(date -d "$LOOK_BACK day ago" +'%Y-%m-%d')

# Execute
if [ "$env" = "sit" ]; then
  echo "In the "$env" environment, TSDOS uses the static input data for 2022-10-03 for sfgim_run_cpc_data.sh due to lack of some daily files on test servers."
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_execution/cash_pool_collateral/cpc_data_gatherer.py -d "2022-10-03" -c "/opt/sfgim/aac/tsdos/sf_execution/static_inputs/"$env"/SFGIM_ActualPaymentsCashPool_20221003.json" -o "/share/"$env"/rps/sfgim/imt/polling/cash_pool_collateral/"$tday"/default/cpc_data_"$yday".json"
elif [ "$env" = "uat" ] || [ "$env" = "prd" ]; then
  if [ -f "/share/"$env"/rps/ail/sfgim/polling/SFGIM_ActualPaymentsCashPool_"$yday".json" ];  then
    filename="/share/"$env"/rps/ail/sfgim/polling/SFGIM_ActualPaymentsCashPool_"$yday".json"
  else
    filename="/share/"$env"/rps/ail/sfgim/polling/SFGIM_ActualPaymentsCashPool_"tday".json"
  fi
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_execution/cash_pool_collateral/cpc_data_gatherer.py -d $yday_dash -c $filename -o "/share/"$env"/rps/sfgim/imt/polling/cash_pool_collateral/"$tday"/default/cpc_data_"$yday".json"
fi

./sfgim_run_cpc_data.sh  &&
./sfgim_run_cpc_excel.sh  &&
./sfgim_run_cpc_mail.sh

./sfgim_comp_or_transactions.sh  &&
./sfgim_comp_collateral_transactions.sh  &&
./sfgim_comp_fungibility.sh  &&
./sfgim_comp_instrument_positions.sh  &&
./sfgim_comp_client_cash_inventories.sh  &&
./sfgim_run_eclfr_data.sh  &&
./sfgim_run_eclfr_report.sh  &&
./sfgim_run_eclfr_excel.sh  &&
./sfgim_run_eclfr_mail.sh

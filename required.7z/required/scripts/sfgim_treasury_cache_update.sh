nohup ~/runkinit.sh
nohup /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/treasury/in_memory/cache_updater.py >> /opt/sfgim/logs/sf_hk_cache.log

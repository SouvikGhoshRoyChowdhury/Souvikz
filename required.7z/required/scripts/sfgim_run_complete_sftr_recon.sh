./sfgim_run_sftr_recon_data.sh
./sfgim_run_sftr_recon_excel.sh
./sfgim_run_sftr_recon_mail.sh
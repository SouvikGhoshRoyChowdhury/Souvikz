./sfgim_comp_repo_transactions.sh &&
./sfgim_run_repo_report.sh

echo "Running OTR:"  &&
./sfgim_run_complete_otr.sh &&
echo ""  &&

echo "Running CPC:"  &&
./sfgim_run_complete_cpc.sh &&
echo ""  &&

echo "Running DCR EU:"  &&
./sfgim_run_complete_dcr_eu.sh &&
echo ""  &&

echo "Running SFTC:"  &&
./sfgim_run_complete_sftc.sh &&
echo ""  &&

echo "Running TCR:"  &&
./sfgim_run_complete_tcr_apac.sh &&
echo ""  &&

echo "Running CMM:"  &&
./sfgim_run_complete_cmm.sh &&
echo ""  &&

echo "Running NCC:"  &&
./sfgim_run_complete_ncc.sh &&
echo ""  &&

echo "Running UMR:"  &&
./sfgim_run_complete_umr.sh &&
echo ""  &&

echo "Running SFTR RECON:"  &&
./sfgim_run_complete_sftr_recon.sh &&
echo ""  &&

echo "Running CSDR Penalty Matches:"  &&
./sfgim_run_csdr_penalty_matches_report.sh &&
echo ""

echo "Running BER:"  &&
./sfgim_run_complete_ber.sh &&
echo ""  &&

echo "Running CRS:"  &&
./sfgim_run_complete_crsr.sh &&
echo ""


env_string=$(hostnamectl | grep 'hostname')
hostname=${env_string:20:30}
sit_hostname="gbvleuaactgim01.windmill.local"
uat_hostname="gbvleuaacugim01.windmill.local"
prd_hostname="gbvleuaacpgim01.windmill.local"


if [ "$hostname" = "$sit_hostname" ] ;  then  # sit
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/disk_use_check.py -p /opt/
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/disk_use_check.py -p /tmp/
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/disk_use_check.py -p /share/sit/rps/sfgim/imt/polling/
elif [ "$hostname" = "$uat_hostname" ] ;  then  # uat
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/disk_use_check.py -p /opt/
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/disk_use_check.py -p /tmp/
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/disk_use_check.py -p /share/uat/rps/sfgim/imt/polling/
elif [ "$hostname" = "$prd_hostname" ] ;  then  # prod
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/disk_use_check.py -p /opt/
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/disk_use_check.py -p /tmp/
  /opt/rh/rh-python38/root/usr/bin/python /opt/sfgim/aac/tsdos/sf_tools/disk_use_check.py -p /share/prd/rps/sfgim/imt/polling/
fi
